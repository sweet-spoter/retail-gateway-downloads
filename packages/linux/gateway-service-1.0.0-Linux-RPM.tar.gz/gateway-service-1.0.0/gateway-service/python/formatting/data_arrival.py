import asyncio
from .verifone import process_packet

async def data_interface(data):
    if data["device"] == 'verifone':
       await process_packet(data)
    elif data["device"] == 'infogenesis':
        print(data["data"])

