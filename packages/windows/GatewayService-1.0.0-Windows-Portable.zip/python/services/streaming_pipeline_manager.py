"""
Streaming pipeline manager for handling streaming pipeline integration.
"""

import asyncio
from typing import Dict, Any, Optional
from core.logging_config import get_logger
from core.interfaces import EventBusProtocol
from formatting.pipeline.tcp_pipeline import TCPPipeline

class StreamingPipelineManager:
    """Manages streaming pipeline connections and operations"""
    
    def __init__(self, config: Dict[str, Any], event_bus: EventBusProtocol):
        self.config = config
        self.event_bus = event_bus
        self.logger = get_logger(__name__)
        
        # Pipeline tracking
        self.pipelines: Dict[str, TCPPipeline] = {}
        self.pipeline_status: Dict[str, bool] = {}
        self.pipeline_metrics: Dict[str, Dict[str, Any]] = {}
        
        # Global configuration
        self.global_config = config.get('global_config', {})
        self.streaming_config = config.get('streaming_config', {})
        self.device_types = config.get('device_types', {})
        
        # Health monitoring
        self.health_check_interval = 30  # seconds
        self.health_check_task: Optional[asyncio.Task] = None
        self.running = False
    
    async def start(self):
        """Start the streaming pipeline manager"""
        try:
            self.logger.info("Starting streaming pipeline manager")
            
            # Initialize global pipeline
            await self._initialize_global_pipeline()
            
            # Start health monitoring
            self.health_check_task = asyncio.create_task(self._health_monitor())
            
            self.running = True
            self.logger.info("Streaming pipeline manager started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start streaming pipeline manager: {e}")
            raise
    
    async def shutdown(self):
        """Shutdown the streaming pipeline manager"""
        try:
            self.logger.info("Shutting down streaming pipeline manager")
            
            self.running = False
            
            # Stop health monitoring
            if self.health_check_task:
                self.health_check_task.cancel()
                try:
                    await self.health_check_task
                except asyncio.CancelledError:
                    pass
            
            # Close all pipelines
            await self._close_all_pipelines()
            
            self.logger.info("Streaming pipeline manager shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during streaming pipeline manager shutdown: {e}")
            raise
    
    async def _initialize_global_pipeline(self):
        """Initialize the global streaming pipeline"""
        try:
            host = self.global_config.get('tcp_pipeline_host', 'localhost')
            port = self.global_config.get('tcp_pipeline_port', 9000)
            timeout = self.global_config.get('connection_timeout', 5)
            
            pipeline_id = f"global_{host}_{port}"
            
            # Create TCP pipeline
            pipeline = TCPPipeline(host=host, port=port, timeout=timeout)
            
            # Set connection callback
            pipeline.set_connection_callback(self._on_pipeline_connection_change)
            
            # Store pipeline
            self.pipelines[pipeline_id] = pipeline
            self.pipeline_status[pipeline_id] = False
            self.pipeline_metrics[pipeline_id] = {
                "start_time": asyncio.get_event_loop().time(),
                "transactions_sent": 0,
                "bytes_sent": 0,
                "connection_attempts": 0,
                "reconnections": 0,
                "errors": 0
            }
            
            # Connect to pipeline
            success = pipeline.connect()
            if success:
                self.pipeline_status[pipeline_id] = True
                self.logger.info(f"Connected to global streaming pipeline: {host}:{port}")
            else:
                self.logger.warning(f"Failed to connect to global streaming pipeline: {host}:{port}")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize global pipeline: {e}")
            raise
    
    async def _close_all_pipelines(self):
        """Close all streaming pipelines"""
        try:
            for pipeline_id, pipeline in self.pipelines.items():
                try:
                    pipeline.disconnect()
                    self.pipeline_status[pipeline_id] = False
                    self.logger.info(f"Disconnected from pipeline: {pipeline_id}")
                except Exception as e:
                    self.logger.error(f"Error disconnecting from pipeline {pipeline_id}: {e}")
            
            self.pipelines.clear()
            self.pipeline_status.clear()
            self.pipeline_metrics.clear()
            
        except Exception as e:
            self.logger.error(f"Error closing pipelines: {e}")
    
    def _on_pipeline_connection_change(self, connected: bool):
        """Handle pipeline connection state changes"""
        try:
            if connected:
                self.logger.info("Streaming pipeline connected")
            else:
                self.logger.warning("Streaming pipeline disconnected")
                
        except Exception as e:
            self.logger.error(f"Error handling pipeline connection change: {e}")
    
    async def send_transaction_start(self, lane_id: str, device_id: str, transaction_id: str, 
                                   device_type: str, initial_data: bytes) -> bool:
        """Send transaction start to streaming pipeline"""
        try:
            pipeline_id = self._get_pipeline_id(lane_id)
            if not pipeline_id or pipeline_id not in self.pipelines:
                self.logger.error(f"No pipeline available for lane {lane_id}")
                return False
            
            pipeline = self.pipelines[pipeline_id]
            if not pipeline.is_connected():
                self.logger.warning(f"Pipeline {pipeline_id} not connected")
                return False
            
            # Send transaction start
            success = pipeline.send_transaction_start(
                transaction_id=transaction_id,
                device_type=device_type,
                device_id=device_id,
                initial_data=initial_data
            )
            
            if success:
                self.pipeline_metrics[pipeline_id]["transactions_sent"] += 1
                self.pipeline_metrics[pipeline_id]["bytes_sent"] += len(initial_data)
                self.logger.debug(f"Sent transaction start: {transaction_id}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error sending transaction start: {e}")
            if pipeline_id:
                self.pipeline_metrics[pipeline_id]["errors"] += 1
            return False
    
    async def send_transaction_data(self, lane_id: str, device_id: str, transaction_id: str,
                                  device_type: str, data: bytes) -> bool:
        """Send transaction data to streaming pipeline"""
        try:
            pipeline_id = self._get_pipeline_id(lane_id)
            if not pipeline_id or pipeline_id not in self.pipelines:
                self.logger.error(f"No pipeline available for lane {lane_id}")
                return False
            
            pipeline = self.pipelines[pipeline_id]
            if not pipeline.is_connected():
                self.logger.warning(f"Pipeline {pipeline_id} not connected")
                return False
            
            # Send transaction data
            success = pipeline.send_transaction_data(
                transaction_id=transaction_id,
                device_type=device_type,
                device_id=device_id,
                data=data
            )
            
            if success:
                self.pipeline_metrics[pipeline_id]["bytes_sent"] += len(data)
                self.logger.debug(f"Sent transaction data: {transaction_id}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error sending transaction data: {e}")
            if pipeline_id:
                self.pipeline_metrics[pipeline_id]["errors"] += 1
            return False
    
    async def send_transaction_end(self, lane_id: str, device_id: str, transaction_id: str,
                                 device_type: str, final_data: bytes, total_chunks: int) -> bool:
        """Send transaction end to streaming pipeline"""
        try:
            pipeline_id = self._get_pipeline_id(lane_id)
            if not pipeline_id or pipeline_id not in self.pipelines:
                self.logger.error(f"No pipeline available for lane {lane_id}")
                return False
            
            pipeline = self.pipelines[pipeline_id]
            if not pipeline.is_connected():
                self.logger.warning(f"Pipeline {pipeline_id} not connected")
                return False
            
            # Send transaction end
            success = pipeline.send_transaction_end(
                transaction_id=transaction_id,
                device_type=device_type,
                device_id=device_id,
                final_data=final_data,
                total_chunks=total_chunks
            )
            
            if success:
                self.pipeline_metrics[pipeline_id]["bytes_sent"] += len(final_data)
                self.logger.debug(f"Sent transaction end: {transaction_id}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error sending transaction end: {e}")
            if pipeline_id:
                self.pipeline_metrics[pipeline_id]["errors"] += 1
            return False
    
    def _get_pipeline_id(self, lane_id: str) -> Optional[str]:
        """Get pipeline ID for a specific lane"""
        # For now, use the global pipeline for all lanes
        # In the future, this could be lane-specific
        for pipeline_id in self.pipelines.keys():
            if pipeline_id.startswith("global_"):
                return pipeline_id
        return None
    
    def is_healthy(self) -> bool:
        """Check if streaming pipeline is healthy"""
        if not self.running:
            return False
        
        # Check if at least one pipeline is connected
        connected_pipelines = sum(1 for status in self.pipeline_status.values() if status)
        return connected_pipelines > 0
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get streaming pipeline metrics"""
        total_transactions = sum(
            metrics.get("transactions_sent", 0) 
            for metrics in self.pipeline_metrics.values()
        )
        total_bytes = sum(
            metrics.get("bytes_sent", 0) 
            for metrics in self.pipeline_metrics.values()
        )
        total_errors = sum(
            metrics.get("errors", 0) 
            for metrics in self.pipeline_metrics.values()
        )
        
        return {
            "running": self.running,
            "pipelines_connected": sum(1 for status in self.pipeline_status.values() if status),
            "total_pipelines": len(self.pipelines),
            "total_transactions_sent": total_transactions,
            "total_bytes_sent": total_bytes,
            "total_errors": total_errors,
            "pipeline_details": self.pipeline_metrics.copy()
        }
    
    async def _health_monitor(self):
        """Monitor streaming pipeline health"""
        while self.running:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                # Check pipeline status
                connected_pipelines = sum(1 for status in self.pipeline_status.values() if status)
                total_pipelines = len(self.pipelines)
                
                self.logger.info(f"Streaming pipeline health: {connected_pipelines}/{total_pipelines} connected")
                
                # Log disconnected pipelines
                disconnected_pipelines = [
                    pipeline_id for pipeline_id, status in self.pipeline_status.items() 
                    if not status
                ]
                
                if disconnected_pipelines:
                    self.logger.warning(f"Disconnected pipelines: {disconnected_pipelines}")
                
                # Attempt reconnection for disconnected pipelines
                for pipeline_id in disconnected_pipelines:
                    if pipeline_id in self.pipelines:
                        pipeline = self.pipelines[pipeline_id]
                        if pipeline.connect():
                            self.pipeline_status[pipeline_id] = True
                            self.pipeline_metrics[pipeline_id]["reconnections"] += 1
                            self.logger.info(f"Reconnected to pipeline: {pipeline_id}")
                        else:
                            self.pipeline_metrics[pipeline_id]["connection_attempts"] += 1
                
            except asyncio.CancelledError:
                self.logger.info("Streaming pipeline health monitor cancelled")
                break
            except Exception as e:
                self.logger.error(f"Streaming pipeline health monitor error: {e}")
    
    def get_pipeline_info(self, pipeline_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific pipeline"""
        if pipeline_id not in self.pipelines:
            return None
        
        pipeline = self.pipelines[pipeline_id]
        metrics = self.pipeline_metrics.get(pipeline_id, {})
        
        return {
            "id": pipeline_id,
            "connected": self.pipeline_status.get(pipeline_id, False),
            "connection_info": pipeline.get_connection_info(),
            "metrics": metrics
        }
    
    def get_all_pipelines(self) -> Dict[str, Dict[str, Any]]:
        """Get information about all pipelines"""
        return {
            pipeline_id: self.get_pipeline_info(pipeline_id)
            for pipeline_id in self.pipelines.keys()
        } 