import asyncio
import uuid

class TCPSocket:
    def __init__(self, host, port, mode):
        self.host = host
        self.port = port
        self.mode = mode
        self.id = str(uuid.uuid4())  # Generate unique ID for the socket
        self.reader = None
        self.writer = None
        self.heartbeat_task = None
        self.message_observers = []

        if mode not in ['connect', 'listen']:
            raise ValueError("Invalid mode. Mode must be 'connect' or 'listen'.")

    async def connect_or_listen(self):
        if self.mode == 'connect':
            await self.connect()
        elif self.mode == 'listen':
            await self.listen()

    async def connect(self):
        try:
            self.reader, self.writer = await asyncio.open_connection(self.host, self.port)
            print(f"Connected to {self.host}:{self.port}")

            # Start sending heartbeat messages
            self.heartbeat_task = asyncio.create_task(self.send_heartbeat())
        except Exception as e:
            print(f"Failed to connect to {self.host}:{self.port}: {e}")

    async def listen(self):
        try:
            server = await asyncio.start_server(self.handle_connection, self.host, self.port)
            print(f"Listening for connections on {self.host}:{self.port}")
            async with server:
                await server.serve_forever()
        except Exception as e:
            print(f"Failed to start listening on {self.host}:{self.port}: {e}")

    async def send(self, data):
        if self.mode == 'connect':
            try:
                self.writer.write(data.encode())
                await self.writer.drain()
                print(f"Message sent from socket {self.id}: {data}")
            except Exception as e:
                print(f"Error sending message from socket {self.id}: {e}")
        else:
            print("Cannot send data in listen mode.")

    async def receive(self):
        if self.mode == 'listen':
            try:
                data = await self.reader.read(1024)
                return data.decode(), self.id  # Return message along with socket ID
            except Exception as e:
                print(f"Error receiving data in listen mode from socket {self.id}: {e}")
                return None, self.id
        else:
            print("Cannot receive data in connect mode.")
            return None, self.id

    async def send_heartbeat(self):
        while True:
            try:
                self.writer.write("heartbeat\n".encode())
                await self.writer.drain()
                await asyncio.sleep(5)  # Send heartbeat every 5 seconds
            except asyncio.CancelledError:
                # Stop sending heartbeat when connection is closed
                break
            except Exception as e:
                print(f"Error sending heartbeat from socket {self.id}: {e}")

    async def close(self):
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
        if self.writer:
            try:
                self.writer.close()
                await self.writer.wait_closed()
                print(f"Connection with {self.host}:{self.port} closed")
            except Exception as e:
                print(f"Error closing connection for socket {self.id}: {e}")

    async def handle_connection(self, reader, writer):
        addr = writer.get_extra_info('peername')
        print(f"Connection established from {addr}")

        while True:
            try:
                data = await reader.readline()
                if not data:
                    break
                message = data.decode().strip()
                print(f"Received message from {addr} on socket {self.id}: {message}")
                
                # Notify observers with the received message and socket ID
                for observer in self.message_observers:
                    await observer(message, self.id)
            except Exception as e:
                print(f"Error handling connection for socket {self.id}: {e}")

        print(f"Connection with {addr} closed for socket {self.id}")
        writer.close()

    def add_message_observer(self, observer):
        self.message_observers.append(observer)
