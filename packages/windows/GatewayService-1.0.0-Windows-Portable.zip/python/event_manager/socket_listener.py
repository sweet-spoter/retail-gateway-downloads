

class SocketListener:
    def __init__(self, event_bus):
        self.event_bus = event_bus

    def receive_packet(self, evt_obs, device_id, packet):
        """Simulate receiving a packet from a socket and publishing it to the event bus."""
        print(f"Received packet from {evt_obs} {device_id}: {packet}")
        self.event_bus.publish("packet_received", (evt_obs, device_id, packet))