import asyncio

class TCPServerProtocol(asyncio.Protocol):
    connections = {}
    
    def __init__(self, register, direction, device_manager):
        self.transport = None
        self.register = register
        self.direction = direction
        self.device_manager = device_manager
        self.buffer = bytearray()

    def connection_made(self, transport):
        self.transport = transport
        peername = transport.get_extra_info('peername')
        TCPServerProtocol.connections[self.direction+self.register] = self
        self.device_manager.set_protocol( self.direction+self.register ,self.direction, self.register)
        self.device_manager.on_connection_made(self.direction+self.register)
        self.client_ip, self.client_port = peername

        print(f'Connection from {peername}')
        
    def data_received(self, data):
        self.buffer.extend(data)
        self.process_data()
            
        # print(f'Data received: {message}')
        # # Echo back the received message (or handle as needed)
        # self.send_message(f"Echo: {message}")
    def process_data(self):
        
        while b'\n' in self.buffer:
            line, _, self.buffer = self.buffer.partition(b'\n')
            self.handle_complete_message(line.decode())

    def handle_complete_message(self, message):
        print("Received complete message:", message)
        # Handle the complete message here
        result = {'register': self.register, 'data': message}
        self.device_manager.handle_data(self.direction+self.register, message, self.client_ip)

    def connection_lost(self, exc):
        if exc:
            print(f'Client disconnected due to error: {exc}')
        else:
            print('Client disconnected successfully.')
        self.transport = None
        self.device_manager.on_connection_lost(self.direction+self.register)

    def send_message(self, message):
        if self.transport:
            self.transport.write(message.encode())
            print(f"Sent: {message}")
        else:
            print("No transport available to send message.")
