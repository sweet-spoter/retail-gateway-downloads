from aiohttp import web
from typing import Dict, Any
import json
import time
from core.logging_config import get_logger
from core.health import HealthChecker
from core.metrics import get_metrics_registry

logger = get_logger(__name__)

class MonitoringAPI:
    """REST API for monitoring and health checks"""
    
    def __init__(self, app_service):
        self.app_service = app_service
        self.health_checker = HealthChecker()
        self.metrics_registry = get_metrics_registry()
        self.logger = logger
    
    async def health_check(self, request: web.Request) -> web.Response:
        """Health check endpoint"""
        try:
            health_status = await self.health_checker.run_health_checks(self.app_service)
            
            # Set appropriate HTTP status code
            if health_status["status"] == "healthy":
                status_code = 200
            elif health_status["status"] == "degraded":
                status_code = 200  # Still responding but degraded
            else:
                status_code = 503  # Service unavailable
            
            return web.json_response(
                health_status,
                status=status_code,
                headers={"Content-Type": "application/json"}
            )
        except Exception as e:
            self.logger.error(f"Health check failed: {e}")
            return web.json_response(
                {
                    "status": "unhealthy",
                    "message": f"Health check error: {str(e)}",
                    "timestamp": time.time()
                },
                status=503
            )
    
    async def metrics(self, request: web.Request) -> web.Response:
        """Metrics endpoint in Prometheus format"""
        try:
            metrics_data = self.metrics_registry.get_all_metrics()
            
            # Format as Prometheus metrics
            prometheus_metrics = []
            
            for metric_name, metric_summary in metrics_data.items():
                if metric_summary["latest"] is not None:
                    # Add metric with timestamp
                    prometheus_metrics.append(
                        f"# HELP {metric_name} {metric_summary['description']}\n"
                        f"# TYPE {metric_name} gauge\n"
                        f"{metric_name} {metric_summary['latest']} {int(metric_summary.get('timestamp', time.time()) * 1000)}"
                    )
            
            return web.Response(
                text="\n".join(prometheus_metrics),
                content_type="text/plain; version=0.0.4; charset=utf-8"
            )
        except Exception as e:
            self.logger.error(f"Metrics endpoint failed: {e}")
            return web.json_response(
                {"error": f"Metrics collection failed: {str(e)}"},
                status=500
            )
    
    async def metrics_json(self, request: web.Request) -> web.Response:
        """Metrics endpoint in JSON format"""
        try:
            metrics_data = self.metrics_registry.get_all_metrics()
            
            return web.json_response(
                {
                    "timestamp": time.time(),
                    "metrics": metrics_data
                },
                headers={"Content-Type": "application/json"}
            )
        except Exception as e:
            self.logger.error(f"Metrics JSON endpoint failed: {e}")
            return web.json_response(
                {"error": f"Metrics collection failed: {str(e)}"},
                status=500
            )
    
    async def status(self, request: web.Request) -> web.Response:
        """Detailed status endpoint"""
        try:
            service_status = self.app_service.get_status()
            health_status = self.health_checker.get_last_health_status()
            
            status_data = {
                "service": service_status,
                "health": health_status,
                "timestamp": time.time(),
                "version": "1.0.0"  # You can make this configurable
            }
            
            return web.json_response(
                status_data,
                headers={"Content-Type": "application/json"}
            )
        except Exception as e:
            self.logger.error(f"Status endpoint failed: {e}")
            return web.json_response(
                {"error": f"Status collection failed: {str(e)}"},
                status=500
            )
    
    async def info(self, request: web.Request) -> web.Response:
        """Service information endpoint"""
        try:
            info_data = {
                "name": "Gateway Service",
                "version": "1.0.0",
                "description": "Gateway service for device communication",
                "uptime": self.app_service.get_status().get("uptime", 0),
                "startup_time": self.app_service.startup_time,
                "running": self.app_service.running,
                "healthy": self.app_service.healthy,
                "timestamp": time.time()
            }
            
            return web.json_response(
                info_data,
                headers={"Content-Type": "application/json"}
            )
        except Exception as e:
            self.logger.error(f"Info endpoint failed: {e}")
            return web.json_response(
                {"error": f"Info collection failed: {str(e)}"},
                status=500
            )
    
    async def ready(self, request: web.Request) -> web.Response:
        """Readiness probe endpoint"""
        try:
            if self.app_service.running and self.app_service.is_healthy():
                return web.json_response(
                    {"status": "ready", "timestamp": time.time()},
                    status=200
                )
            else:
                return web.json_response(
                    {"status": "not_ready", "timestamp": time.time()},
                    status=503
                )
        except Exception as e:
            self.logger.error(f"Readiness probe failed: {e}")
            return web.json_response(
                {"status": "not_ready", "error": str(e), "timestamp": time.time()},
                status=503
            )
    
    async def live(self, request: web.Request) -> web.Response:
        """Liveness probe endpoint"""
        try:
            # Simple check if the service is running
            if self.app_service.running:
                return web.json_response(
                    {"status": "alive", "timestamp": time.time()},
                    status=200
                )
            else:
                return web.json_response(
                    {"status": "dead", "timestamp": time.time()},
                    status=503
                )
        except Exception as e:
            self.logger.error(f"Liveness probe failed: {e}")
            return web.json_response(
                {"status": "dead", "error": str(e), "timestamp": time.time()},
                status=503
            )

def create_monitoring_app(app_service, host: str = "0.0.0.0", port: int = 8080) -> web.Application:
    """Create monitoring web application"""
    app = web.Application()
    monitoring_api = MonitoringAPI(app_service)
    
    # Add routes
    app.router.add_get("/health", monitoring_api.health_check)
    app.router.add_get("/metrics", monitoring_api.metrics)
    app.router.add_get("/metrics/json", monitoring_api.metrics_json)
    app.router.add_get("/status", monitoring_api.status)
    app.router.add_get("/info", monitoring_api.info)
    app.router.add_get("/ready", monitoring_api.ready)
    app.router.add_get("/live", monitoring_api.live)
    
    # Add CORS middleware
    async def cors_middleware(request, handler):
        response = await handler(request)
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        return response
    
    app.middlewares.append(cors_middleware)
    
    return app

async def start_monitoring_server(app_service, host: str = "0.0.0.0", port: int = 8080):
    """Start the monitoring web server"""
    app = create_monitoring_app(app_service, host, port)
    runner = web.AppRunner(app)
    await runner.setup()
    
    site = web.TCPSite(runner, host, port)
    await site.start()
    
    logger.info(f"Monitoring server started on http://{host}:{port}")
    logger.info("Available endpoints:")
    logger.info("  GET /health     - Health check")
    logger.info("  GET /metrics    - Prometheus metrics")
    logger.info("  GET /metrics/json - JSON metrics")
    logger.info("  GET /status     - Detailed status")
    logger.info("  GET /info       - Service information")
    logger.info("  GET /ready      - Readiness probe")
    logger.info("  GET /live       - Liveness probe")
    
    return runner 