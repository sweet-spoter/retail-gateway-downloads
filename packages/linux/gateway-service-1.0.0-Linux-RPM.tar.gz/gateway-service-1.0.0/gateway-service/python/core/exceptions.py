class GatewayException(Exception):
    """Base exception for gateway service"""
    pass


class ConfigurationError(GatewayException):
    """Configuration related errors"""
    pass


class ConnectionError(GatewayException):
    """Connection related errors"""
    pass


class DeviceError(GatewayException):
    """Device related errors"""
    pass


class ValidationError(GatewayException):
    """Data validation errors"""
    pass


class ServiceError(GatewayException):
    """Service related errors"""
    pass 