"""
Streaming wrapper implementation for transaction pipeline.
"""

import socket
import json
import uuid
from typing import Optional
from datetime import datetime
from ..base.streaming_pipeline import StreamingPipeline, TransactionState
from .data_detector import DataDetector

class StreamingWrapper(StreamingPipeline):
    """
    Streaming wrapper implementation for transaction pipeline.
    Connects to TCP pipeline (video system) and handles streaming data.
    """
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.socket: Optional[socket.socket] = None
        self.connected = False
        self.data_detector = DataDetector()
        self._connect_to_pipeline()
    
    def _connect_to_pipeline(self):
        """
        Connect to TCP pipeline (video system).
        """
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(5)  # 5 second timeout
            self.socket.connect((self.tcp_pipeline_host, self.tcp_pipeline_port))
            self.connected = True
            print(f"Connected to TCP pipeline at {self.tcp_pipeline_host}:{self.tcp_pipeline_port}")
        except Exception as e:
            print(f"Failed to connect to TCP pipeline: {e}")
            self.connected = False
    
    def _start_transaction_with_data(self, device_data: bytes, device_info: dict):
        """
        Send Start Transaction + Initial Device Data.
        
        Args:
            device_data: Raw device data
            device_info: Device information
        """
        if not self.connected:
            self._connect_to_pipeline()
        
        # Generate transaction ID
        self.current_transaction = str(uuid.uuid4())
        
        # Send Start Transaction + Initial Data
        start_message = {
            "type": "start_transaction",
            "transaction_id": self.current_transaction,
            "device_type": device_info.get("device_type"),
            "device_id": device_info.get("device_id"),
            "initial_data": device_data.hex(),
            "timestamp": self._get_timestamp()
        }
        
        self._send_to_pipeline(start_message)
        print(f"Started transaction {self.current_transaction} for {device_info.get('device_type')}")
    
    def _stream_data(self, device_data: bytes, device_info: dict):
        """
        Stream data as it arrives.
        
        Args:
            device_data: Raw device data
            device_info: Device information
        """
        if not self.connected:
            return
        
        # Add to streaming buffer
        self.streaming_buffer.append(device_data)
        
        # Send streaming data
        stream_message = {
            "type": "stream_data",
            "transaction_id": self.current_transaction,
            "device_type": device_info.get("device_type"),
            "device_id": device_info.get("device_id"),
            "data": device_data.hex(),
            "timestamp": self._get_timestamp()
        }
        
        self._send_to_pipeline(stream_message)
    
    def _end_transaction_with_data(self, device_data: bytes, device_info: dict):
        """
        Send End Data + End Transaction.
        
        Args:
            device_data: Raw device data
            device_info: Device information
        """
        if not self.connected:
            return
        
        # Send End Data
        end_data_message = {
            "type": "end_data",
            "transaction_id": self.current_transaction,
            "device_type": device_info.get("device_type"),
            "device_id": device_info.get("device_id"),
            "final_data": device_data.hex(),
            "timestamp": self._get_timestamp()
        }
        
        self._send_to_pipeline(end_data_message)
        
        # Send End Transaction
        end_transaction_message = {
            "type": "end_transaction",
            "transaction_id": self.current_transaction,
            "device_type": device_info.get("device_type"),
            "device_id": device_info.get("device_id"),
            "total_data_chunks": len(self.streaming_buffer),
            "timestamp": self._get_timestamp()
        }
        
        self._send_to_pipeline(end_transaction_message)
        
        print(f"Completed transaction {self.current_transaction} for {device_info.get('device_type')}")
        
        # Clear buffer for next transaction
        self.streaming_buffer.clear()
    
    def _is_end_of_data_detected(self, device_data: bytes, device_info: dict) -> bool:
        """
        Detect end of data stream.
        
        Args:
            device_data: Raw device data
            device_info: Device information
            
        Returns:
            bool: True if end of data is detected
        """
        device_type = device_info.get("device_type", "generic")
        return self.data_detector.is_end_of_data_detected(device_data, device_type, self.streaming_buffer)
    
    def _send_to_pipeline(self, message: dict):
        """
        Send message to TCP pipeline.
        
        Args:
            message: Message dictionary to send
        """
        try:
            if not self.connected:
                self._connect_to_pipeline()
                if not self.connected:
                    return
            
            message_str = json.dumps(message) + "\n"
            self.socket.send(message_str.encode('utf-8'))
        except Exception as e:
            print(f"Failed to send to pipeline: {e}")
            self.connected = False
            # Try to reconnect
            self._connect_to_pipeline()
    
    def _get_timestamp(self) -> str:
        """
        Get current timestamp.
        
        Returns:
            str: ISO formatted timestamp
        """
        return datetime.now().isoformat()
    
    def close(self):
        """
        Close the pipeline connection.
        """
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        self.connected = False 