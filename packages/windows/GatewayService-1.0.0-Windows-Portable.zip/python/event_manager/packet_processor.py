import asyncio

from collections import defaultdict, deque
from server.observer import post_event

class PacketProcessor:
    MAX_QUEUE_SIZE = 10  # Limit the number of packets per device
    PROCESSING_TIMEOUT = 3  # Timeout for processing a packet (in seconds)

    def __init__(self, event_bus):
        # Dictionary to map devices to their own packet queues
        self.device_queues = defaultdict(deque)
        # Track whether each device is processing or not
        self.is_processing_device = defaultdict(bool)
        # Event bus for message handling
        self.event_bus = event_bus

        self.event_bus.subscribe("packet_received", self.queue_packet)  # Subscribe to packet events

    def queue_packet(self, packet_data):
        """Add packet to the respective device's queue and trigger processing."""
        evt_obs, device_id, packet = packet_data  # Unpack the evt_obs, device_id, and packet

        # Enforce queue size limit per device
        if len(self.device_queues[device_id]) >= self.MAX_QUEUE_SIZE:
            print(f"Queue for {device_id} is full. Dropping oldest packet.")
            self.device_queues[device_id].popleft()  # Discard the oldest packet (FIFO)

        self.device_queues[device_id].append((evt_obs, packet))  # Store evt_obs and packet together
        print(f"Queued packet for {device_id}: {packet} with observer: {evt_obs}")

        # Only start processing if this device is not already processing
        if not self.is_processing_device[device_id]:
            asyncio.create_task(self.process_packets(device_id))

    async def process_packets(self, device_id):
        """Sequentially process packets for a specific device."""
        self.is_processing_device[device_id] = True
        while self.device_queues[device_id]:
            evt_obs, packet = self.device_queues[device_id].popleft()  # Get the next packet and evt_obs for this device
            try:
                await asyncio.wait_for(self.handle_packet(evt_obs, packet, device_id), timeout=self.PROCESSING_TIMEOUT)
            except asyncio.TimeoutError:
                print(f"Timeout while processing packet for {device_id}: {packet}")

        self.is_processing_device[device_id] = False

    async def handle_packet(self, evt_obs, packet, device_id):
        """Simulate packet processing."""
        print(f"Processing packet for {device_id}: {packet}")
        await asyncio.sleep(1)  # Simulating async processing
        print(f"Finished processing packet for {device_id}: {packet}")
        # Notify that the packet has been processed
        # Now, post the event with evt_obs and packet
        await post_event(evt_obs, packet)
        self.event_bus.publish("packet_processed", {'device_id': device_id, 'packet': packet})
