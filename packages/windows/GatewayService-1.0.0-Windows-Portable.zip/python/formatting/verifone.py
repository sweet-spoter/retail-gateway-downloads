import re
import asyncio
from config.config import input_configs
from server.observer import post_event

# Initialize a global state dictionary to hold the state across function calls
# Initialize the state dictionary with clearer state names
state = {
    "is_active": False,
    "post_total": False,
    "is_complete": False,
    "terminal": None,
    "trans_line": None,  # Ensure this is set correctly elsewhere in your code
}

def reset(state):
    state["in_transaction"] = False
    state["post_total"] = False
    state["terminal"] = None
    state["trans_line"] = None

async def process_packet(data_object):
    packet = data_object['data']
    register = data_object['register']
    
    index =next((index for index, config in enumerate(input_configs) if config.get('register') == register), None)
    print(index)  # Output: 1
    
    if index != -1:
        print(f"Index of configuration with register '{register}': {index}")
        filter_config = input_configs[index]['filter']
    else:
        print(f"No configuration found for register '{register}'.")
    

    print(f"Raw packet in {packet}")
    state["terminal"] = extract_terminal(packet)
    state["trans_line"] = extract_data_after_terminal(packet)
    
    # filter_config = config['filter']
    
    # Applying the configuration to parse the line
    # parsed_data = {
    #     'date': packet[slice(*filter_config['date'])].strip(),
    #     'time': packet[slice(*filter_config['time'])].strip(),
    #     'terminal': packet[slice(*filter_config['terminal'])].strip(),
    #     'description': packet[slice(*filter_config['description'])].strip(),
    #     'quantity': packet[slice(*filter_config['quantity'])].strip(),
    #     'price': packet[slice(*filter_config['price'])] if filter_config['price'][1] is not None else packet[filter_config['price'][0]:].strip()
    # }
    
    # Early return if terminal is not found
    if state["terminal"] is None:
        print(f"Not found terminal in {packet}")
        return
    
    print(f"Terminal: {state["terminal"]}")
    print(f"Clean data: { state["trans_line"]}")
    
    # Simplify result dictionary creation
    def create_result(data):
        return {'register': state["terminal"], 'device': data_object['device'], 'data': data + "\n\r"}
    
    # Helper function to post events, reducing repetition
    async def post_output_event(data):
        await post_event("output_register_" + state["terminal"], create_result(data))
    
    
    if not state["is_active"] and not state["is_complete"]:
        # Starting a new transaction
        state["is_active"] = True
        await  post_output_event("Start Transaction")
        await  post_output_event(state["trans_line"])
    elif state["is_active"]:
        # Transaction is already active, check for next steps
        if "TRAN#" in packet:
            state["post_total"] = True
            await  post_output_event(state["trans_line"])
        elif "CSH:" in packet and state["post_total"]:
            # Ending the transaction
            state["is_active"] = False
            state["post_total"] = False
            state["is_complete"] = True
            await  post_output_event(state["trans_line"])
            await post_output_event("End Transaction")
        else:
            # Post line as part of ongoing transaction
            await  post_output_event(state["trans_line"])
    elif state["is_complete"]:
        # Restarting the transaction after completion
        state["is_complete"] = False
        state["is_active"] = True
        await post_output_event("Start Transaction")
        await post_output_event(state["trans_line"])
    
    # if not state["in_transaction"] and state["terminal"]:
    #     state["in_transaction"] = True
    #     print("Start Transaction")
    #     # Consolidate the creation and posting of the "Start Transaction" message
    #     await post_output_event("Start Transaction")
    #     await post_output_event( state["trans_line"])
    # else:
    #     await post_output_event( state["trans_line"])
    
    # if "TRAN#" in packet:
    #     state["post_total"] = True
    # elif "CSH:" in packet and state["post_total"]:
    #     print("End Transaction\n\rStart Transaction")
    #     await post_output_event("End Transaction\n\rStart Transaction\n\r")
    #     state["post_total"] = False
    #     state["in_transaction"] = False
    #     reset(state)
    
def extract_terminal(packet):
    matches = re.findall(r'(?<!/)\b\d+\b', packet)
    for match in matches:
        if len(match) == 2 or len(match) == 4:
            continue
        return match
    return None

def extract_data_after_terminal(packet):
    if state["terminal"] is None:
        return None
    pattern = re.compile(r'\b{}\b\s*(.*)'.format(re.escape(state["terminal"])))
    match = pattern.search(packet)
    if match:
        return match.group(1).strip()
    return None
