import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CogIcon, KeyIcon, ShieldCheckIcon, ExclamationTriangleIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import { configAPI, licenseAPI } from '../../services/api';
import { toast } from 'react-hot-toast';

interface LaneConfig {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  license_required: boolean;
  license_status: 'active' | 'expired' | 'trial' | 'disabled';
  activation_date?: string;
  expiration_date?: string;
  grace_period_until?: string;
  devices: {
    [key: string]: {
      device_type: string;
      connection_type: 'sdk' | 'socket';
      sdk_config?: {
        sdk_type: 'python' | 'cpp' | 'csharp';
        module?: string;
        dll_path?: string;
        assembly?: string;
        runtime?: string;
      };
      socket_config?: {
        type: 'tcp' | 'udp' | 'multicast';
        host: string;
        port: number;
        mode: 'connect' | 'listen';
      };
    };
  };
  sessionizer: {
    enabled: boolean;
    timeout: number;
    expected_sequence: string[];
    correlation_window: number;
  };
  outputs: {
    live_events: {
      enabled: boolean;
      destinations: string[];
    };
    transaction_bundles: {
      enabled: boolean;
      destinations: string[];
    };
  };
}

interface LicenseInfo {
  license_key: string;
  license_type: 'trial' | 'basic' | 'professional' | 'enterprise';
  status: 'active' | 'expired' | 'disabled';
  activation_date: string;
  expiration_date: string;
  grace_period_until?: string;
  max_lanes: number;
  active_lanes: number;
  features: string[];
}

const Configuration: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'lanes' | 'licensing' | 'sdk' | 'outputs'>('lanes');
  const [selectedLane, setSelectedLane] = useState<string | null>(null);
  const [showAddLane, setShowAddLane] = useState(false);
  const queryClient = useQueryClient();

  // Fetch configuration data
  const { data: lanes = {}, isLoading: lanesLoading } = useQuery({
    queryKey: ['lanes-config'],
    queryFn: configAPI.getLanesConfig,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const { data: licenseInfo, isLoading: licenseLoading } = useQuery({
    queryKey: ['license-info'],
    queryFn: licenseAPI.getLicenseInfo,
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Mutations
  const updateLaneMutation = useMutation({
    mutationFn: ({ laneId, config }: { laneId: string; config: any }) => 
      configAPI.updateLaneConfig(laneId, config),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['lanes-config'] });
      toast.success('Lane configuration updated successfully');
    },
    onError: (error) => {
      toast.error(`Failed to update lane configuration: ${error.message}`);
    },
  });

  const activateLicenseMutation = useMutation({
    mutationFn: (licenseKey: string) => licenseAPI.activateLicense(licenseKey),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['license-info'] });
      toast.success('License activated successfully');
    },
    onError: (error) => {
      toast.error(`Failed to activate license: ${error.message}`);
    },
  });

  const getLicenseStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'trial': return 'text-blue-600 bg-blue-100';
      case 'expired': return 'text-red-600 bg-red-100';
      case 'disabled': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getLicenseStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircleIcon className="w-5 h-5" />;
      case 'trial': return <KeyIcon className="w-5 h-5" />;
      case 'expired': return <ExclamationTriangleIcon className="w-5 h-5" />;
      case 'disabled': return <ShieldCheckIcon className="w-5 h-5" />;
      default: return <ShieldCheckIcon className="w-5 h-5" />;
    }
  };

  if (lanesLoading || licenseLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Configuration</h1>
        <p className="text-gray-600">Manage lanes, licensing, and system configuration</p>
      </div>

      {/* License Status Banner */}
      {licenseInfo && (
        <div className={`p-4 rounded-lg border ${getLicenseStatusColor(licenseInfo.status)}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {getLicenseStatusIcon(licenseInfo.status)}
              <div>
                <h3 className="text-sm font-medium">
                  License: {licenseInfo.license_type.toUpperCase()} - {licenseInfo.status.toUpperCase()}
                </h3>
                <p className="text-sm">
                  Lanes: {licenseInfo.active_lanes}/{licenseInfo.max_lanes} • 
                  Expires: {new Date(licenseInfo.expiration_date).toLocaleDateString()}
                </p>
              </div>
            </div>
            {licenseInfo.status === 'expired' && licenseInfo.grace_period_until && (
              <div className="text-sm">
                Grace period until: {new Date(licenseInfo.grace_period_until).toLocaleDateString()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {[
            { id: 'lanes', name: 'Lanes', icon: CogIcon },
            { id: 'licensing', name: 'Licensing', icon: KeyIcon },
            { id: 'sdk', name: 'SDK Management', icon: ShieldCheckIcon },
            { id: 'outputs', name: 'Outputs', icon: CogIcon },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.name}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="mt-6">
        {activeTab === 'lanes' && (
          <LanesTab
            lanes={lanes}
            selectedLane={selectedLane}
            onSelectLane={setSelectedLane}
            onUpdateLane={updateLaneMutation.mutate}
            onAddLane={() => setShowAddLane(true)}
          />
        )}

        {activeTab === 'licensing' && (
          <LicensingTab
            licenseInfo={licenseInfo}
            onActivateLicense={activateLicenseMutation.mutate}
            isActivating={activateLicenseMutation.isPending}
          />
        )}

        {activeTab === 'sdk' && (
          <SDKManagementTab />
        )}

        {activeTab === 'outputs' && (
          <OutputsTab />
        )}
      </div>

      {/* Add Lane Modal */}
      {showAddLane && (
        <AddLaneModal
          onClose={() => setShowAddLane(false)}
          onSuccess={() => {
            setShowAddLane(false);
            queryClient.invalidateQueries({ queryKey: ['lanes-config'] });
          }}
        />
      )}
    </div>
  );
};

// Lanes Tab Component
const LanesTab: React.FC<{
  lanes: { [key: string]: LaneConfig };
  selectedLane: string | null;
  onSelectLane: (laneId: string) => void;
  onUpdateLane: (data: { laneId: string; config: any }) => void;
  onAddLane: () => void;
}> = ({ lanes, selectedLane, onSelectLane, onUpdateLane, onAddLane }) => {
  const laneEntries = Object.entries(lanes);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Lane List */}
      <div className="lg:col-span-1">
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Lanes</h3>
              <button
                onClick={onAddLane}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-blue-600 bg-blue-100 hover:bg-blue-200"
              >
                Add Lane
              </button>
            </div>
            <div className="space-y-2">
              {laneEntries.map(([laneId, lane]) => (
                <button
                  key={laneId}
                  onClick={() => onSelectLane(laneId)}
                  className={`w-full text-left p-3 rounded-md border ${
                    selectedLane === laneId
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-gray-900">{lane.name}</h4>
                      <p className="text-sm text-gray-500">
                        {Object.keys(lane.devices).length} devices
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        lane.license_status === 'active' ? 'bg-green-100 text-green-800' :
                        lane.license_status === 'trial' ? 'bg-blue-100 text-blue-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {lane.license_status}
                      </span>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                        lane.status === 'active' ? 'bg-green-100 text-green-800' :
                        lane.status === 'inactive' ? 'bg-gray-100 text-gray-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {lane.status}
                      </span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Lane Configuration */}
      <div className="lg:col-span-2">
        {selectedLane && lanes[selectedLane] ? (
          <LaneConfiguration
            laneId={selectedLane}
            lane={lanes[selectedLane]}
            onUpdate={onUpdateLane}
          />
        ) : (
          <div className="bg-white shadow rounded-lg p-6">
            <div className="text-center text-gray-500">
              <CogIcon className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No lane selected</h3>
              <p className="mt-1 text-sm text-gray-500">
                Select a lane from the list to configure it.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Lane Configuration Component
const LaneConfiguration: React.FC<{
  laneId: string;
  lane: LaneConfig;
  onUpdate: (data: { laneId: string; config: any }) => void;
}> = ({ laneId, lane, onUpdate }) => {
  const [config, setConfig] = useState(lane);

  const handleSave = () => {
    onUpdate({ laneId, config });
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Configure Lane: {lane.name}</h3>
        
        <div className="space-y-6">
          {/* Basic Settings */}
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-3">Basic Settings</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Lane Name</label>
                <input
                  type="text"
                  value={config.name}
                  onChange={(e) => setConfig({ ...config, name: e.target.value })}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Status</label>
                <select
                  value={config.status}
                  onChange={(e) => setConfig({ ...config, status: e.target.value as any })}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>

          {/* License Settings */}
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-3">License Settings</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={config.license_required}
                    onChange={(e) => setConfig({ ...config, license_required: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">License Required</span>
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">License Status</label>
                <div className="mt-1 text-sm text-gray-900">{config.license_status}</div>
              </div>
            </div>
          </div>

          {/* Sessionizer Settings */}
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-3">Sessionizer Settings</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={config.sessionizer.enabled}
                    onChange={(e) => setConfig({
                      ...config,
                      sessionizer: { ...config.sessionizer, enabled: e.target.checked }
                    })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Enable Sessionizer</span>
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Timeout (seconds)</label>
                <input
                  type="number"
                  value={config.sessionizer.timeout}
                  onChange={(e) => setConfig({
                    ...config,
                    sessionizer: { ...config.sessionizer, timeout: parseInt(e.target.value) }
                  })}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>

          {/* Output Settings */}
          <div>
            <h4 className="text-md font-medium text-gray-900 mb-3">Output Settings</h4>
            <div className="space-y-4">
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={config.outputs.live_events.enabled}
                    onChange={(e) => setConfig({
                      ...config,
                      outputs: {
                        ...config.outputs,
                        live_events: { ...config.outputs.live_events, enabled: e.target.checked }
                      }
                    })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Enable Live Events</span>
                </label>
              </div>
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={config.outputs.transaction_bundles.enabled}
                    onChange={(e) => setConfig({
                      ...config,
                      outputs: {
                        ...config.outputs,
                        transaction_bundles: { ...config.outputs.transaction_bundles, enabled: e.target.checked }
                      }
                    })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Enable Transaction Bundles</span>
                </label>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end">
            <button
              onClick={handleSave}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Save Configuration
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Licensing Tab Component
const LicensingTab: React.FC<{
  licenseInfo?: LicenseInfo;
  onActivateLicense: (licenseKey: string) => void;
  isActivating: boolean;
}> = ({ licenseInfo, onActivateLicense, isActivating }) => {
  const [licenseKey, setLicenseKey] = useState('');

  const handleActivate = () => {
    if (licenseKey.trim()) {
      onActivateLicense(licenseKey.trim());
      setLicenseKey('');
    }
  };

  return (
    <div className="space-y-6">
      {/* License Information */}
      {licenseInfo && (
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">License Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-medium text-gray-500">License Type</h4>
              <p className="text-lg font-semibold text-gray-900">{licenseInfo.license_type.toUpperCase()}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500">Status</h4>
              <p className="text-lg font-semibold text-gray-900">{licenseInfo.status.toUpperCase()}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500">Lanes Used</h4>
              <p className="text-lg font-semibold text-gray-900">{licenseInfo.active_lanes} / {licenseInfo.max_lanes}</p>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500">Expiration Date</h4>
              <p className="text-lg font-semibold text-gray-900">
                {new Date(licenseInfo.expiration_date).toLocaleDateString()}
              </p>
            </div>
          </div>
          
          {licenseInfo.features.length > 0 && (
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-500 mb-2">Features</h4>
              <div className="flex flex-wrap gap-2">
                {licenseInfo.features.map((feature, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Activate License */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Activate License</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">License Key</label>
            <input
              type="text"
              value={licenseKey}
              onChange={(e) => setLicenseKey(e.target.value)}
              placeholder="Enter your license key"
              className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <button
            onClick={handleActivate}
            disabled={!licenseKey.trim() || isActivating}
            className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {isActivating ? 'Activating...' : 'Activate License'}
          </button>
        </div>
      </div>
    </div>
  );
};

// SDK Management Tab Component
const SDKManagementTab: React.FC = () => {
  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">SDK Management</h3>
      <div className="space-y-4">
        <div className="p-4 bg-blue-50 rounded-md">
          <h4 className="text-sm font-medium text-blue-900">Python SDK</h4>
          <p className="text-sm text-blue-700 mt-1">
            Direct module import with dynamic loading. Supports version checking and connection parameters.
          </p>
        </div>
        <div className="p-4 bg-green-50 rounded-md">
          <h4 className="text-sm font-medium text-green-900">C++ SDK</h4>
          <p className="text-sm text-green-700 mt-1">
            DLL loading with ctypes for cross-platform compatibility. Supports 32-bit and 64-bit architectures.
          </p>
        </div>
        <div className="p-4 bg-purple-50 rounded-md">
          <h4 className="text-sm font-medium text-purple-900">C# SDK</h4>
          <p className="text-sm text-purple-700 mt-1">
            Multi-process architecture with IPC for .NET runtime isolation. Supports different .NET versions.
          </p>
        </div>
      </div>
    </div>
  );
};

// Outputs Tab Component
const OutputsTab: React.FC = () => {
  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Output Configuration</h3>
      <div className="space-y-4">
        <div className="p-4 bg-yellow-50 rounded-md">
          <h4 className="text-sm font-medium text-yellow-900">Live Events</h4>
          <p className="text-sm text-yellow-700 mt-1">
            Real-time event streaming for live monitoring and dashboards.
          </p>
        </div>
        <div className="p-4 bg-indigo-50 rounded-md">
          <h4 className="text-sm font-medium text-indigo-900">Transaction Bundles</h4>
          <p className="text-sm text-indigo-700 mt-1">
            Consolidated transaction records for analytics and compliance.
          </p>
        </div>
      </div>
    </div>
  );
};

// Add Lane Modal Component
const AddLaneModal: React.FC<{ onClose: () => void; onSuccess: () => void }> = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    license_required: true,
    sessionizer_enabled: true,
    sessionizer_timeout: 300,
    live_events_enabled: true,
    transaction_bundles_enabled: true,
  });

  const addLaneMutation = useMutation({
    mutationFn: (data: any) => configAPI.addLane(data),
    onSuccess: () => {
      toast.success('Lane added successfully');
      onSuccess();
    },
    onError: (error) => {
      toast.error(`Failed to add lane: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLaneMutation.mutate(formData);
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div className="mt-3">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Add New Lane</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Lane Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={addLaneMutation.isPending}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {addLaneMutation.isPending ? 'Adding...' : 'Add Lane'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Configuration; 