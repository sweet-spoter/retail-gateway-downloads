"""
Data detector for end-of-data detection in streaming transactions.
"""

from typing import List

class DataDetector:
    """
    Detects end of data stream for different device types.
    """
    
    @staticmethod
    def is_end_of_data_detected(device_data: bytes, device_type: str, buffer: List[bytes]) -> bool:
        """
        Detect end of data stream for different device types.
        
        Args:
            device_data: Current data chunk
            device_type: Type of device (verifone, infogenesis, etc.)
            buffer: Buffer of previous data chunks
            
        Returns:
            bool: True if end of data is detected
        """
        if device_type == "verifone":
            return DataDetector._detect_verifone_end(device_data, buffer)
        elif device_type == "infogenesis":
            return DataDetector._detect_infogenesis_end(device_data, buffer)
        else:
            return DataDetector._detect_generic_end(device_data, buffer)
    
    @staticmethod
    def _detect_verifone_end(data: bytes, buffer: List[bytes]) -> bool:
        """
        Detect Verifone end of data.
        
        Args:
            data: Current data chunk
            buffer: Buffer of previous data chunks
            
        Returns:
            bool: True if end of data is detected
        """
        # Verifone-specific end markers
        end_markers = [b'\x03', b'\x04', b'ETX', b'\x1C', b'\x0D\x0A']
        
        # Check current data for end markers
        if any(marker in data for marker in end_markers):
            return True
        
        # Check for timeout-based completion (10 chunks = complete transaction)
        if len(buffer) >= 10:
            return True
        
        # Check for empty data (end of stream)
        if len(data) == 0:
            return True
        
        return False
    
    @staticmethod
    def _detect_infogenesis_end(data: bytes, buffer: List[bytes]) -> bool:
        """
        Detect Infogenesis end of data.
        
        Args:
            data: Current data chunk
            buffer: Buffer of previous data chunks
            
        Returns:
            bool: True if end of data is detected
        """
        # Infogenesis-specific end markers
        end_markers = [b'\x0D\x0A', b'\x1C', b'END', b'\x00', b'\x03']
        
        # Check current data for end markers
        if any(marker in data for marker in end_markers):
            return True
        
        # Check for pattern-based completion
        if len(buffer) >= 5 and b'\x00' in data:
            return True
        
        # Check for timeout-based completion (8 chunks = complete transaction)
        if len(buffer) >= 8:
            return True
        
        # Check for empty data (end of stream)
        if len(data) == 0:
            return True
        
        return False
    
    @staticmethod
    def _detect_generic_end(data: bytes, buffer: List[bytes]) -> bool:
        """
        Generic end detection for unknown device types.
        
        Args:
            data: Current data chunk
            buffer: Buffer of previous data chunks
            
        Returns:
            bool: True if end of data is detected
        """
        # Generic end markers
        end_markers = [b'\x00', b'\x03', b'\x04', b'\x0D\x0A', b'\x1C']
        
        # Check current data for end markers
        if any(marker in data for marker in end_markers):
            return True
        
        # Default timeout-based completion (15 chunks = complete transaction)
        if len(buffer) >= 15:
            return True
        
        # Check for empty data (end of stream)
        if len(data) == 0:
            return True
        
        return False 