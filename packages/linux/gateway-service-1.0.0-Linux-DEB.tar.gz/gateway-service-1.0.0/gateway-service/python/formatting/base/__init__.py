"""
Base classes for POS device interfaces and streaming pipeline.
"""

from .pos_interface import POSInterface, ProtocolType, ConnectionType
from .streaming_pipeline import StreamingPipeline, TransactionState

__all__ = [
    'POSInterface',
    'ProtocolType', 
    'ConnectionType',
    'StreamingPipeline',
    'TransactionState'
] 