"""
Factory for creating POS interface instances based on device configuration.
"""

from typing import Dict, Any, Optional
from ..base.pos_interface import POSInterface
from ..implementations.tcp.verifone import VerifoneInterface
from ..implementations.udp.infogenesis import InfogenesisInterface
from ..implementations.handshake.infogenesis_handshake import InfogenesisHandshake
from ..implementations.sdk.apg.smarttill_interface import SmarttillInterface

class POSFactory:
    """
    Factory for creating POS interface instances.
    Dispatches to appropriate implementation based on device configuration.
    """
    
    # Registry of supported device types
    DEVICE_REGISTRY = {
        "verifone": VerifoneInterface,
        "infogenesis": InfogenesisInterface,
        "smarttill": SmarttillInterface
    }
    
    @classmethod
    def create_pos_interface(cls, config: dict) -> Optional[POSInterface]:
        """
        Create a POS interface instance based on device configuration.
        
        Args:
            config: Device configuration dictionary
            
        Returns:
            POSInterface: Configured POS interface instance, or None if unsupported
        """
        try:
            device_type = config.get('device_type', '').lower()
            
            if device_type not in cls.DEVICE_REGISTRY:
                print(f"Unsupported device type: {device_type}")
                print(f"Supported types: {list(cls.DEVICE_REGISTRY.keys())}")
                return None
            
            # Get the appropriate interface class
            interface_class = cls.DEVICE_REGISTRY[device_type]
            
            # Create and return the interface instance
            interface = interface_class(config)
            
            print(f"Created {device_type} interface with config: {cls._get_config_summary(config)}")
            
            return interface
            
        except Exception as e:
            print(f"Failed to create POS interface: {e}")
            return None
    
    @classmethod
    def register_device_type(cls, device_type: str, interface_class: type):
        """
        Register a new device type and its interface class.
        
        Args:
            device_type: Name of the device type
            interface_class: Class implementing POSInterface
        """
        if interface_class is None:
            raise ValueError(f"Interface class cannot be None")
        
        if not issubclass(interface_class, POSInterface):
            raise ValueError(f"Interface class must inherit from POSInterface")
        
        cls.DEVICE_REGISTRY[device_type.lower()] = interface_class
        print(f"Registered device type: {device_type}")
    
    @classmethod
    def get_supported_devices(cls) -> list:
        """
        Get list of supported device types.
        
        Returns:
            list: List of supported device type names
        """
        return list(cls.DEVICE_REGISTRY.keys())
    
    @classmethod
    def validate_config(cls, config: dict) -> Dict[str, Any]:
        """
        Validate device configuration.
        
        Args:
            config: Device configuration dictionary
            
        Returns:
            dict: Validation result with errors and warnings
        """
        validation_result = {
            "valid": True,
            "errors": [],
            "warnings": []
        }
        
        # Check if config is None
        if config is None:
            validation_result["errors"].append("Configuration is None")
            validation_result["valid"] = False
            return validation_result
        
        # Check required fields (device-specific)
        device_type = config.get('device_type', '').lower()
        if device_type == 'smarttill':
            # Smarttill uses SDK protocol and has different requirements
            required_fields = ['device_type', 'device_id']
        else:
            # Traditional devices need these fields
            required_fields = ['device_type', 'protocol', 'ip_connection', 'port_connection']
        
        for field in required_fields:
            if field not in config:
                validation_result["errors"].append(f"Missing required field: {field}")
                validation_result["valid"] = False
        
        # Check device type (already retrieved above)
        if device_type not in cls.DEVICE_REGISTRY:
            validation_result["errors"].append(f"Unsupported device type: {device_type}")
            validation_result["valid"] = False
        
        # Check protocol
        protocol = config.get('protocol', '').lower()
        if protocol not in ['tcp', 'udp', 'sdk']:
            validation_result["errors"].append(f"Unsupported protocol: {protocol}")
            validation_result["valid"] = False
        
        # Check connection type
        connection_type = config.get('connection_type', 'listen').lower()
        if connection_type not in ['listen', 'connect', 'ethernet', 'serial']:
            validation_result["warnings"].append(f"Unknown connection type: {connection_type}, using 'listen'")
        
        # Device-specific validation
        if device_type == "verifone":
            cls._validate_verifone_config(config, validation_result)
        elif device_type == "infogenesis":
            cls._validate_infogenesis_config(config, validation_result)
        elif device_type == "smarttill":
            cls._validate_smarttill_config(config, validation_result)
        
        return validation_result
    
    @classmethod
    def _validate_verifone_config(cls, config: dict, validation_result: dict):
        """
        Validate Verifone-specific configuration.
        
        Args:
            config: Device configuration
            validation_result: Validation result to update
        """
        # Check protocol
        if config.get('protocol', '').lower() != 'tcp':
            validation_result["errors"].append("Verifone requires TCP protocol")
            validation_result["valid"] = False
        
        # Check handshake requirement
        if config.get('handshake_required', False):
            validation_result["warnings"].append("Verifone typically doesn't require handshake")
        
        # Check for terminal_id
        if not config.get('terminal_id'):
            validation_result["warnings"].append("Terminal ID not specified for Verifone")
    
    @classmethod
    def _validate_infogenesis_config(cls, config: dict, validation_result: dict):
        """
        Validate Infogenesis-specific configuration.
        
        Args:
            config: Device configuration
            validation_result: Validation result to update
        """
        # Check protocol
        if config.get('protocol', '').lower() != 'udp':
            validation_result["errors"].append("Infogenesis requires UDP protocol")
            validation_result["valid"] = False
        
        # Check handshake requirement
        if not config.get('handshake_required', True):
            validation_result["warnings"].append("Infogenesis typically requires handshake")
        
        # Check for terminal_id
        if not config.get('terminal_id'):
            validation_result["errors"].append("Terminal ID required for Infogenesis")
            validation_result["valid"] = False
        
        # Check for terminal_ip
        if not config.get('terminal_ip'):
            validation_result["warnings"].append("Terminal IP not specified for Infogenesis")
    
    @classmethod
    def _validate_smarttill_config(cls, config: dict, validation_result: dict):
        """
        Validate Smarttill-specific configuration.
        
        Args:
            config: Device configuration
            validation_result: Validation result to update
        """
        # Check required fields
        required_fields = ['device_id']
        for field in required_fields:
            if field not in config:
                validation_result["errors"].append(f"Missing required field: {field}")
                validation_result["valid"] = False
        
        # Check connection type
        connection_type = config.get('connection_type', 'ethernet').lower()
        if connection_type not in ['ethernet', 'serial']:
            validation_result["errors"].append(f"Unsupported connection type: {connection_type}")
            validation_result["valid"] = False
        
        # Check device_id format
        device_id = config.get('device_id', '')
        if connection_type == 'ethernet':
            # Should be IP address or MAC address
            import re
            ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
            mac_pattern = r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'
            if not (re.match(ip_pattern, device_id) or re.match(mac_pattern, device_id)):
                validation_result["warnings"].append("Device ID should be IP address or MAC address for Ethernet connection")
        
        # Check port
        port = config.get('port', 8086)
        if not isinstance(port, int) or port < 1 or port > 65535:
            validation_result["errors"].append("Port must be an integer between 1 and 65535")
            validation_result["valid"] = False
        
        # Check protocol compatibility
        protocol = config.get('protocol', '').lower()
        if protocol and protocol != 'sdk':
            validation_result["warnings"].append("Smarttill uses SDK protocol, protocol field will be ignored")
        
        # Check handshake requirement
        if config.get('handshake_required', False):
            validation_result["warnings"].append("Smarttill typically doesn't require handshake")
        
        # Check for timeout configuration
        timeout = config.get('timeout')
        if timeout is not None and (not isinstance(timeout, int) or timeout < 1000):
            validation_result["warnings"].append("Timeout should be at least 1000ms for reliable operation")
    
    @classmethod
    def _get_config_summary(cls, config: dict) -> dict:
        """
        Get a summary of the configuration for logging.
        
        Args:
            config: Device configuration
            
        Returns:
            dict: Configuration summary
        """
        return {
            "device_type": config.get('device_type'),
            "device_id": config.get('device_id'),
            "protocol": config.get('protocol'),
            "connection_type": config.get('connection_type'),
            "ip_connection": config.get('ip_connection'),
            "port_connection": config.get('port_connection'),
            "handshake_required": config.get('handshake_required'),
            "output_mapping": config.get('output_mapping')
        }
    
    @classmethod
    def create_from_config_file(cls, config_file_path: str) -> Optional[POSInterface]:
        """
        Create POS interface from configuration file.
        
        Args:
            config_file_path: Path to configuration file
            
        Returns:
            POSInterface: Configured POS interface instance, or None if failed
        """
        try:
            import json
            
            with open(config_file_path, 'r') as f:
                config = json.load(f)
            
            # Validate configuration
            validation = cls.validate_config(config)
            if not validation["valid"]:
                print("Configuration validation failed:")
                for error in validation["errors"]:
                    print(f"  Error: {error}")
                return None
            
            if validation["warnings"]:
                print("Configuration warnings:")
                for warning in validation["warnings"]:
                    print(f"  Warning: {warning}")
            
            return cls.create_pos_interface(config)
            
        except FileNotFoundError:
            print(f"Configuration file not found: {config_file_path}")
            return None
        except json.JSONDecodeError as e:
            print(f"Invalid JSON in configuration file: {e}")
            return None
        except Exception as e:
            print(f"Failed to load configuration: {e}")
            return None
    
    @classmethod
    def get_supported_devices(cls) -> list:
        """
        Get list of supported device types.
        
        Returns:
            list: List of supported device type names
        """
        return list(cls.DEVICE_REGISTRY.keys())
    
    @classmethod
    def is_device_supported(cls, device_type: str) -> bool:
        """
        Check if a device type is supported.
        
        Args:
            device_type: Device type to check
            
        Returns:
            bool: True if device type is supported, False otherwise
        """
        return device_type.lower() in cls.DEVICE_REGISTRY 