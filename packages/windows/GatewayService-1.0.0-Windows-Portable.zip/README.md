# Gateway Service Installer

## Installation
1. Run `install.bat` as Administrator
2. Run `start_gateway.bat` to start the service

## Configuration
Edit files in the `config/` directory as needed.

## Uninstallation
Delete the `C:\Program Files\GatewayService` directory.
