"""
Windows Service Installation Module

This module provides multiple methods for installing the gateway service:
1. Direct installation (elevated permissions)
2. Download and manual installation
3. Silent installation script generation
4. PowerShell-based installation
"""

import os
import json
import subprocess
import tempfile
import zipfile
import shutil
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple
import logging

logger = logging.getLogger(__name__)

class WindowsServiceInstaller:
    """Windows Service Installation Manager"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.service_name = config.get('installation_config', {}).get('service_name', 'GulfCoastGateway')
        self.install_path = config.get('installation_config', {}).get('install_path', 'C:\\Program Files\\GulfCoast\\Gateway')
        self.log_path = config.get('installation_config', {}).get('log_path', 'C:\\Program Files\\GulfCoast\\Gateway\\logs')
        self.data_path = config.get('installation_config', {}).get('data_path', 'C:\\Program Files\\GulfCoast\\Gateway\\data')
        self.backup_path = config.get('installation_config', {}).get('backup_path', 'C:\\Program Files\\GulfCoast\\Gateway\\backup')
        self.startup_type = config.get('installation_config', {}).get('startup_type', 'automatic')
    
    def install_service_direct(self) -> Tuple[bool, str]:
        """Install service directly using PowerShell with elevated permissions"""
        try:
            # PowerShell script for service installation
            ps_script = f"""
            $serviceName = "{self.service_name}"
            $binaryPath = "{self.install_path}\\gateway_service.exe"
            $startupType = "{self.startup_type}"
            
            # Check if service already exists
            $existingService = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
            if ($existingService) {{
                Write-Host "Service already exists. Stopping and removing..."
                Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
                Remove-Service -Name $serviceName -Force
            }}
            
            # Create service
            New-Service -Name $serviceName -BinaryPathName $binaryPath -StartupType $startupType -DisplayName "GulfCoast Gateway Service"
            
            # Start service
            Start-Service -Name $serviceName
            
            # Set recovery options
            sc.exe failure $serviceName reset= 86400 actions= restart/60000/restart/60000/restart/60000
            
            Write-Host "Service installed and started successfully"
            """
            
            # Execute PowerShell script
            result = subprocess.run([
                'powershell.exe', '-ExecutionPolicy', 'Bypass', '-Command', ps_script
            ], capture_output=True, text=True, check=True)
            
            logger.info(f"Service installation successful: {result.stdout}")
            return True, "Service installed successfully"
            
        except subprocess.CalledProcessError as e:
            error_msg = f"Service installation failed: {e.stderr}"
            logger.error(error_msg)
            return False, error_msg
        except Exception as e:
            error_msg = f"Service installation error: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def generate_installation_package(self, output_path: str) -> Tuple[bool, str]:
        """Generate installation package for manual installation"""
        try:
            # Create temporary directory for package
            with tempfile.TemporaryDirectory() as temp_dir:
                package_dir = Path(temp_dir) / "gulfcoast_gateway_installer"
                package_dir.mkdir()
                
                # Create directory structure
                (package_dir / "bin").mkdir()
                (package_dir / "config").mkdir()
                (package_dir / "logs").mkdir()
                (package_dir / "data").mkdir()
                (package_dir / "backup").mkdir()
                (package_dir / "scripts").mkdir()
                
                # Copy service executable (placeholder)
                self._create_service_executable(package_dir / "bin" / "gateway_service.exe")
                
                # Create configuration files
                self._create_configuration_files(package_dir / "config")
                
                # Create installation scripts
                self._create_installation_scripts(package_dir / "scripts")
                
                # Create documentation
                self._create_documentation(package_dir)
                
                # Create ZIP package
                zip_path = Path(output_path) / f"{self.service_name}_installer.zip"
                self._create_zip_package(package_dir, zip_path)
                
                logger.info(f"Installation package created: {zip_path}")
                return True, str(zip_path)
                
        except Exception as e:
            error_msg = f"Failed to generate installation package: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def generate_silent_installer(self, output_path: str) -> Tuple[bool, str]:
        """Generate silent installation script"""
        try:
            script_content = f"""@echo off
REM GulfCoast Gateway Service Silent Installer
REM Generated for {self.config.get('client_name', 'Unknown Client')}

set SERVICE_NAME={self.service_name}
set INSTALL_PATH={self.install_path}
set LOG_PATH={self.log_path}
set DATA_PATH={self.data_path}
set BACKUP_PATH={self.backup_path}

echo Installing GulfCoast Gateway Service...

REM Create directories
if not exist "%INSTALL_PATH%" mkdir "%INSTALL_PATH%"
if not exist "%LOG_PATH%" mkdir "%LOG_PATH%"
if not exist "%DATA_PATH%" mkdir "%DATA_PATH%"
if not exist "%BACKUP_PATH%" mkdir "%BACKUP_PATH%"

REM Copy files (assuming they're in the same directory as this script)
copy "gateway_service.exe" "%INSTALL_PATH%\\"
copy "config.json" "%INSTALL_PATH%\\"
copy "license.json" "%INSTALL_PATH%\\"

REM Install service
sc create %SERVICE_NAME% binPath= "%INSTALL_PATH%\\gateway_service.exe" start= auto DisplayName= "GulfCoast Gateway Service"

REM Configure service
sc config %SERVICE_NAME% start= auto
sc failure %SERVICE_NAME% reset= 86400 actions= restart/60000/restart/60000/restart/60000

REM Start service
sc start %SERVICE_NAME%

REM Verify installation
sc query %SERVICE_NAME% | find "RUNNING"
if %ERRORLEVEL% EQU 0 (
    echo Installation completed successfully!
    echo Service is running.
) else (
    echo Installation completed but service is not running.
    echo Please check the logs for more information.
)

pause
"""
            
            script_path = Path(output_path) / f"install_{self.service_name}.bat"
            with open(script_path, 'w') as f:
                f.write(script_content)
            
            logger.info(f"Silent installer script created: {script_path}")
            return True, str(script_path)
            
        except Exception as e:
            error_msg = f"Failed to generate silent installer: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def install_service_powershell(self) -> Tuple[bool, str]:
        """Install service using PowerShell commands"""
        try:
            commands = [
                f'$serviceName = "{self.service_name}"',
                f'$binaryPath = "{self.install_path}\\gateway_service.exe"',
                f'$startupType = "{self.startup_type}"',
                '',
                '# Check if service exists',
                '$existingService = Get-Service -Name $serviceName -ErrorAction SilentlyContinue',
                'if ($existingService) {',
                '    Write-Host "Service already exists. Stopping and removing..."',
                '    Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue',
                '    Remove-Service -Name $serviceName -Force',
                '}',
                '',
                '# Create service',
                'New-Service -Name $serviceName -BinaryPathName $binaryPath -StartupType $startupType -DisplayName "GulfCoast Gateway Service"',
                '',
                '# Start service',
                'Start-Service -Name $serviceName',
                '',
                '# Set recovery options',
                'sc.exe failure $serviceName reset= 86400 actions= restart/60000/restart/60000/restart/60000',
                '',
                'Write-Host "Service installed and started successfully"'
            ]
            
            ps_script = '\n'.join(commands)
            
            # Execute PowerShell
            result = subprocess.run([
                'powershell.exe', '-ExecutionPolicy', 'Bypass', '-Command', ps_script
            ], capture_output=True, text=True, check=True)
            
            logger.info(f"PowerShell service installation successful: {result.stdout}")
            return True, "Service installed successfully using PowerShell"
            
        except subprocess.CalledProcessError as e:
            error_msg = f"PowerShell service installation failed: {e.stderr}"
            logger.error(error_msg)
            return False, error_msg
        except Exception as e:
            error_msg = f"PowerShell service installation error: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def validate_installation(self) -> Tuple[bool, str]:
        """Validate service installation"""
        try:
            # Check if service exists
            result = subprocess.run([
                'sc', 'query', self.service_name
            ], capture_output=True, text=True, check=True)
            
            if 'RUNNING' in result.stdout:
                return True, "Service is installed and running"
            elif 'STOPPED' in result.stdout:
                return True, "Service is installed but stopped"
            else:
                return False, "Service not found"
                
        except subprocess.CalledProcessError:
            return False, "Service not installed"
        except Exception as e:
            return False, f"Validation error: {str(e)}"
    
    def uninstall_service(self) -> Tuple[bool, str]:
        """Uninstall the service"""
        try:
            # Stop service
            subprocess.run(['sc', 'stop', self.service_name], capture_output=True)
            
            # Delete service
            subprocess.run(['sc', 'delete', self.service_name], capture_output=True, check=True)
            
            logger.info(f"Service {self.service_name} uninstalled successfully")
            return True, "Service uninstalled successfully"
            
        except subprocess.CalledProcessError as e:
            error_msg = f"Service uninstallation failed: {e.stderr}"
            logger.error(error_msg)
            return False, error_msg
        except Exception as e:
            error_msg = f"Service uninstallation error: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
    
    def _create_service_executable(self, path: Path):
        """Create placeholder service executable"""
        # This would typically copy the actual service executable
        # For now, create a placeholder file
        path.write_text("# Placeholder for gateway service executable")
    
    def _create_configuration_files(self, config_dir: Path):
        """Create configuration files"""
        # Main configuration
        config_data = {
            "gateway": self.config.get('gateway', {}),
            "client_config": self.config.get('client_config', {}),
            "licensing": self.config.get('licensing', {}),
            "lanes": self.config.get('lanes', {})
        }
        
        with open(config_dir / "config.json", 'w') as f:
            json.dump(config_data, f, indent=2)
        
        # License file
        license_data = {
            "license": self.config.get('licensing', {}),
            "client_id": self.config.get('client_config', {}).get('client_id'),
            "installation_date": "2024-01-01T00:00:00Z"
        }
        
        with open(config_dir / "license.json", 'w') as f:
            json.dump(license_data, f, indent=2)
    
    def _create_installation_scripts(self, scripts_dir: Path):
        """Create installation scripts"""
        # Silent installer
        silent_script = f"""@echo off
REM Silent installation script for {self.service_name}

set SERVICE_NAME={self.service_name}
set INSTALL_PATH={self.install_path}

echo Installing {self.service_name}...

REM Create directories
mkdir "%INSTALL_PATH%" 2>nul
mkdir "%INSTALL_PATH%\\logs" 2>nul
mkdir "%INSTALL_PATH%\\data" 2>nul
mkdir "%INSTALL_PATH%\\backup" 2>nul

REM Copy files
copy "bin\\gateway_service.exe" "%INSTALL_PATH%\\"
copy "config\\config.json" "%INSTALL_PATH%\\"
copy "config\\license.json" "%INSTALL_PATH%\\"

REM Install service
sc create %SERVICE_NAME% binPath= "%INSTALL_PATH%\\gateway_service.exe" start= auto DisplayName= "GulfCoast Gateway Service"

REM Start service
sc start %SERVICE_NAME%

echo Installation completed.
"""
        
        with open(scripts_dir / "install_silent.bat", 'w') as f:
            f.write(silent_script)
        
        # PowerShell installer
        ps_script = f"""
$serviceName = "{self.service_name}"
$installPath = "{self.install_path}"

# Create directories
New-Item -ItemType Directory -Force -Path $installPath
New-Item -ItemType Directory -Force -Path "$installPath\\logs"
New-Item -ItemType Directory -Force -Path "$installPath\\data"
New-Item -ItemType Directory -Force -Path "$installPath\\backup"

# Copy files
Copy-Item "bin\\gateway_service.exe" "$installPath\\"
Copy-Item "config\\config.json" "$installPath\\"
Copy-Item "config\\license.json" "$installPath\\"

# Install service
New-Service -Name $serviceName -BinaryPathName "$installPath\\gateway_service.exe" -StartupType Automatic -DisplayName "GulfCoast Gateway Service"

# Start service
Start-Service -Name $serviceName

Write-Host "Installation completed successfully"
"""
        
        with open(scripts_dir / "install.ps1", 'w') as f:
            f.write(ps_script)
    
    def _create_documentation(self, package_dir: Path):
        """Create installation documentation"""
        readme_content = f"""# GulfCoast Gateway Service Installation

## Overview
This package contains the installation files for the GulfCoast Gateway Service.

## Installation Methods

### 1. Silent Installation (Recommended)
Run the silent installer script:
```
install_silent.bat
```

### 2. PowerShell Installation
Run the PowerShell script:
```
powershell.exe -ExecutionPolicy Bypass -File install.ps1
```

### 3. Manual Installation
1. Copy files to {self.install_path}
2. Run: sc create {self.service_name} binPath= "{self.install_path}\\gateway_service.exe" start= auto
3. Run: sc start {self.service_name}

## Configuration
- Service Name: {self.service_name}
- Install Path: {self.install_path}
- Log Path: {self.log_path}
- Data Path: {self.data_path}

## Support
For installation support, contact your system administrator.
"""
        
        with open(package_dir / "README.md", 'w') as f:
            f.write(readme_content)
    
    def _create_zip_package(self, source_dir: Path, zip_path: Path):
        """Create ZIP package"""
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_dir):
                for file in files:
                    file_path = Path(root) / file
                    arc_name = file_path.relative_to(source_dir)
                    zipf.write(file_path, arc_name)

class InstallationManager:
    """High-level installation manager"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.installer = WindowsServiceInstaller(config)
    
    def install_service(self, method: str = 'direct') -> Tuple[bool, str]:
        """Install service using specified method"""
        if method == 'direct':
            return self.installer.install_service_direct()
        elif method == 'powershell':
            return self.installer.install_service_powershell()
        elif method == 'package':
            return self.installer.generate_installation_package('./installers')
        elif method == 'silent':
            return self.installer.generate_silent_installer('./installers')
        else:
            return False, f"Unknown installation method: {method}"
    
    def validate_installation(self) -> Tuple[bool, str]:
        """Validate service installation"""
        return self.installer.validate_installation()
    
    def uninstall_service(self) -> Tuple[bool, str]:
        """Uninstall service"""
        return self.installer.uninstall_service() 