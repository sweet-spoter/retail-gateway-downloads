import asyncio

from sockets.device_manager import device_manager
from .observer import subscribe
from formatting.data_arrival import data_interface
from formatting.handshake_interface import handshake_data_interface

async def input_callback_factory(data):
    await data_interface(data)

async def input_handshake_factory(data):
    await handshake_data_interface(data)
    
async def input_handshake_send_factory(data):
    
    device_manager.send_message(data['id'], data['data'], data['addr'])

def setup_input_event_handler(register):
    subscribe("input_register_" + register, input_callback_factory)
    subscribe("input_handshake_register_" + register, input_handshake_factory)
    subscribe("input_handshake_send_register_" + register, input_handshake_send_factory)