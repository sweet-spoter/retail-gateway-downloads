"""
Pipeline Manager for Two-Pipeline System

This module manages two distinct pipeline modes:
1. Transaction-Wrapped Pipeline: Device Data → Start → Stream → End → Repeat
2. Direct Data Pipeline: Device Data → Stream → Stream → Stream
"""

import json
import uuid
import time
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class PipelineMode(Enum):
    """Pipeline mode enumeration"""
    TRANSACTION_WRAPPED = "transaction_wrapped"
    DIRECT_DATA = "direct_data"

class TransactionState(Enum):
    """Transaction state enumeration"""
    IDLE = "idle"
    STARTING = "starting"
    STREAMING = "streaming"
    ENDING = "ending"

class PipelineManager:
    """Manages the two-pipeline system"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.pipeline_mode = PipelineMode(config.get('pipeline_mode', 'transaction_wrapped'))
        self.live_streaming_enabled = config.get('live_streaming_enabled', True)
        self.live_streaming_temporary = config.get('live_streaming_temporary', False)
        
        # Pipeline configuration
        self.pipeline_config = config.get('pipeline_config', {})
        self.output_config = config.get('output_config', {})
        self.performance_config = config.get('performance_config', {})
        
        # Transaction state management
        self.current_transaction_id = None
        self.transaction_state = TransactionState.IDLE
        self.transaction_start_time = None
        self.transaction_data_buffer = []
        
        # Performance tracking
        self.performance_metrics = {
            'messages_processed': 0,
            'transactions_processed': 0,
            'total_latency_ms': 0,
            'start_time': time.time()
        }
        
        # Initialize pipeline based on mode
        self._initialize_pipeline()
    
    def _initialize_pipeline(self):
        """Initialize the appropriate pipeline based on configuration"""
        if self.pipeline_mode == PipelineMode.TRANSACTION_WRAPPED:
            self._init_transaction_wrapped_pipeline()
        else:
            self._init_direct_data_pipeline()
    
    def _init_transaction_wrapped_pipeline(self):
        """Initialize transaction-wrapped pipeline"""
        logger.info("Initializing Transaction-Wrapped Pipeline")
        
        # Load transaction-wrapped configuration
        tw_config = self.pipeline_config.get('transaction_wrapped', {})
        self.start_template = tw_config.get('start_transaction_template', 'START_TRANSACTION: {transaction_id}')
        self.end_template = tw_config.get('end_transaction_template', 'END_TRANSACTION: {transaction_id}')
        self.transaction_timeout = tw_config.get('transaction_timeout', 300)
        self.auto_detect_boundaries = tw_config.get('auto_detect_boundaries', True)
        
        logger.info(f"Transaction-Wrapped Pipeline initialized with timeout: {self.transaction_timeout}s")
    
    def _init_direct_data_pipeline(self):
        """Initialize direct data pipeline"""
        logger.info("Initializing Direct Data Pipeline")
        
        # Load direct data configuration
        dd_config = self.pipeline_config.get('direct_data', {})
        self.stream_directly = dd_config.get('stream_directly', True)
        self.minimal_processing = dd_config.get('minimal_processing', True)
        self.no_transaction_wrapping = dd_config.get('no_transaction_wrapping', True)
        
        logger.info("Direct Data Pipeline initialized - minimal processing enabled")
    
    def process_device_data(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Process device data through the configured pipeline"""
        start_time = time.time()
        
        try:
            if self.pipeline_mode == PipelineMode.TRANSACTION_WRAPPED:
                result = self._process_transaction_wrapped(device_data, device_info)
            else:
                result = self._process_direct_data(device_data, device_info)
            
            # Update performance metrics
            latency = (time.time() - start_time) * 1000
            self._update_performance_metrics(latency)
            
            return result
            
        except Exception as e:
            logger.error(f"Error processing device data: {e}")
            return {
                'success': False,
                'error': str(e),
                'pipeline_mode': self.pipeline_mode.value,
                'timestamp': datetime.utcnow().isoformat()
            }
    
    def _process_transaction_wrapped(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Process data through transaction-wrapped pipeline"""
        device_type = device_info.get('device_type', 'unknown')
        device_id = device_info.get('device_id', 'unknown')
        
        # Detect transaction boundaries
        if self.auto_detect_boundaries:
            is_start = self._detect_transaction_start(device_data, device_type)
            is_end = self._detect_transaction_end(device_data, device_type)
        else:
            is_start = False
            is_end = False
        
        # Handle transaction start
        if is_start or self.transaction_state == TransactionState.IDLE:
            self._start_transaction(device_data, device_info)
        
        # Stream device data
        stream_result = self._stream_device_data(device_data, device_info)
        
        # Handle transaction end
        if is_end or self._should_end_transaction():
            end_result = self._end_transaction(device_data, device_info)
            return {
                'success': True,
                'pipeline_mode': 'transaction_wrapped',
                'transaction_id': self.current_transaction_id,
                'transaction_state': self.transaction_state.value,
                'stream_result': stream_result,
                'end_result': end_result,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return {
            'success': True,
            'pipeline_mode': 'transaction_wrapped',
            'transaction_id': self.current_transaction_id,
            'transaction_state': self.transaction_state.value,
            'stream_result': stream_result,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    def _process_direct_data(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Process data through direct data pipeline"""
        # Direct streaming without transaction wrapping
        stream_result = self._stream_device_data(device_data, device_info)
        
        return {
            'success': True,
            'pipeline_mode': 'direct_data',
            'stream_result': stream_result,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    def _start_transaction(self, device_data: bytes, device_info: Dict[str, Any]):
        """Start a new transaction"""
        self.current_transaction_id = str(uuid.uuid4())
        self.transaction_state = TransactionState.STARTING
        self.transaction_start_time = time.time()
        self.transaction_data_buffer = []
        
        # Create start transaction message
        start_message = self._create_start_transaction_message(device_data, device_info)
        
        # Send to outputs
        self._send_to_outputs(start_message, 'start_transaction')
        
        self.transaction_state = TransactionState.STREAMING
        logger.info(f"Started transaction: {self.current_transaction_id}")
    
    def _end_transaction(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """End the current transaction"""
        self.transaction_state = TransactionState.ENDING
        
        # Create end transaction message
        end_message = self._create_end_transaction_message(device_data, device_info)
        
        # Send to outputs
        send_result = self._send_to_outputs(end_message, 'end_transaction')
        
        # Update metrics
        self.performance_metrics['transactions_processed'] += 1
        
        # Reset transaction state
        self.transaction_state = TransactionState.IDLE
        self.current_transaction_id = None
        self.transaction_start_time = None
        self.transaction_data_buffer = []
        
        logger.info(f"Ended transaction: {self.current_transaction_id}")
        
        return {
            'transaction_id': self.current_transaction_id,
            'duration_ms': (time.time() - self.transaction_start_time) * 1000 if self.transaction_start_time else 0,
            'data_count': len(self.transaction_data_buffer),
            'send_result': send_result
        }
    
    def _stream_device_data(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Stream device data to outputs"""
        # Add to transaction buffer if in transaction mode
        if self.transaction_state == TransactionState.STREAMING:
            self.transaction_data_buffer.append(device_data)
        
        # Create stream message
        stream_message = self._create_stream_message(device_data, device_info)
        
        # Send to outputs
        send_result = self._send_to_outputs(stream_message, 'stream_data')
        
        # Update metrics
        self.performance_metrics['messages_processed'] += 1
        
        return {
            'message_type': 'stream_data',
            'device_type': device_info.get('device_type'),
            'device_id': device_info.get('device_id'),
            'data_size': len(device_data),
            'send_result': send_result
        }
    
    def _create_start_transaction_message(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Create start transaction message"""
        return {
            'message_type': 'start_transaction',
            'transaction_id': self.current_transaction_id,
            'timestamp': datetime.utcnow().isoformat(),
            'device_type': device_info.get('device_type'),
            'device_id': device_info.get('device_id'),
            'template': self.start_template.format(transaction_id=self.current_transaction_id),
            'initial_data': device_data.hex() if device_data else None
        }
    
    def _create_end_transaction_message(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Create end transaction message"""
        return {
            'message_type': 'end_transaction',
            'transaction_id': self.current_transaction_id,
            'timestamp': datetime.utcnow().isoformat(),
            'device_type': device_info.get('device_type'),
            'device_id': device_info.get('device_id'),
            'template': self.end_template.format(transaction_id=self.current_transaction_id),
            'final_data': device_data.hex() if device_data else None,
            'transaction_summary': {
                'duration_ms': (time.time() - self.transaction_start_time) * 1000 if self.transaction_start_time else 0,
                'data_count': len(self.transaction_data_buffer),
                'total_data_size': sum(len(data) for data in self.transaction_data_buffer)
            }
        }
    
    def _create_stream_message(self, device_data: bytes, device_info: Dict[str, Any]) -> Dict[str, Any]:
        """Create stream message"""
        return {
            'message_type': 'stream_data',
            'transaction_id': self.current_transaction_id if self.transaction_state != TransactionState.IDLE else None,
            'timestamp': datetime.utcnow().isoformat(),
            'device_type': device_info.get('device_type'),
            'device_id': device_info.get('device_id'),
            'data': device_data.hex() if device_data else None,
            'data_size': len(device_data) if device_data else 0
        }
    
    def _send_to_outputs(self, message: Dict[str, Any], message_type: str) -> Dict[str, Any]:
        """Send message to configured outputs"""
        results = {
            'live_streaming': None,
            'external_systems': [],
            'analytics_api': None
        }
        
        # Send to live streaming if enabled
        if self.live_streaming_enabled:
            results['live_streaming'] = self._send_to_live_streaming(message)
        
        # Send to external systems
        external_systems = self.output_config.get('external_systems', [])
        for system in external_systems:
            if system.get('enabled', False):
                system_result = self._send_to_external_system(message, system, message_type)
                results['external_systems'].append(system_result)
        
        # Send to analytics API if enabled
        if self.output_config.get('analytics_api_enabled', False):
            results['analytics_api'] = self._send_to_analytics_api(message)
        
        return results
    
    def _send_to_live_streaming(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send message to live streaming (retail-gateway-ui)"""
        # This would integrate with the WebSocket server
        try:
            # Simulate WebSocket send
            logger.debug(f"Live streaming message: {message['message_type']}")
            return {
                'success': True,
                'target': 'live_streaming',
                'message_type': message['message_type']
            }
        except Exception as e:
            logger.error(f"Live streaming error: {e}")
            return {
                'success': False,
                'target': 'live_streaming',
                'error': str(e)
            }
    
    def _send_to_external_system(self, message: Dict[str, Any], system: Dict[str, Any], message_type: str) -> Dict[str, Any]:
        """Send message to external system"""
        system_name = system.get('name', 'unknown')
        system_type = system.get('type', 'tcp')
        host = system.get('host', 'localhost')
        port = system.get('port', 8080)
        
        try:
            # Check if system requires transaction wrapping
            requires_wrapping = system.get('requires_transaction_wrapping', False)
            
            # Skip if transaction wrapping required but we're in direct mode
            if requires_wrapping and self.pipeline_mode == PipelineMode.DIRECT_DATA:
                return {
                    'success': False,
                    'target': system_name,
                    'error': 'System requires transaction wrapping but direct data mode is active'
                }
            
            # Simulate sending to external system
            logger.debug(f"Sending {message_type} to {system_name} ({host}:{port})")
            
            return {
                'success': True,
                'target': system_name,
                'system_type': system_type,
                'host': host,
                'port': port,
                'message_type': message_type
            }
            
        except Exception as e:
            logger.error(f"External system error ({system_name}): {e}")
            return {
                'success': False,
                'target': system_name,
                'error': str(e)
            }
    
    def _send_to_analytics_api(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Send message to analytics API"""
        try:
            # Simulate analytics API call
            logger.debug(f"Analytics API message: {message['message_type']}")
            return {
                'success': True,
                'target': 'analytics_api',
                'message_type': message['message_type']
            }
        except Exception as e:
            logger.error(f"Analytics API error: {e}")
            return {
                'success': False,
                'target': 'analytics_api',
                'error': str(e)
            }
    
    def _detect_transaction_start(self, device_data: bytes, device_type: str) -> bool:
        """Detect if this data indicates transaction start"""
        # This would implement device-specific logic
        # For now, use simple heuristics
        
        if device_type == 'infogenesis':
            # Infogenesis specific start detection
            return b'SCM' in device_data or b'PEM' in device_data
        elif device_type == 'verifone':
            # Verifone specific start detection
            return b'STX' in device_data and b'TRANSACTION' in device_data
        else:
            # Generic start detection
            return b'START' in device_data or b'BEGIN' in device_data
    
    def _detect_transaction_end(self, device_data: bytes, device_type: str) -> bool:
        """Detect if this data indicates transaction end"""
        # This would implement device-specific logic
        
        if device_type == 'infogenesis':
            # Infogenesis specific end detection
            return b'SAM' in device_data or b'END' in device_data
        elif device_type == 'verifone':
            # Verifone specific end detection
            return b'ETX' in device_data and b'END' in device_data
        else:
            # Generic end detection
            return b'END' in device_data or b'COMPLETE' in device_data
    
    def _should_end_transaction(self) -> bool:
        """Check if transaction should be ended based on timeout"""
        if self.transaction_start_time is None:
            return False
        
        elapsed = time.time() - self.transaction_start_time
        return elapsed > self.transaction_timeout
    
    def _update_performance_metrics(self, latency_ms: float):
        """Update performance metrics"""
        self.performance_metrics['total_latency_ms'] += latency_ms
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get current performance metrics"""
        uptime = time.time() - self.performance_metrics['start_time']
        
        return {
            'pipeline_mode': self.pipeline_mode.value,
            'live_streaming_enabled': self.live_streaming_enabled,
            'live_streaming_temporary': self.live_streaming_temporary,
            'messages_processed': self.performance_metrics['messages_processed'],
            'transactions_processed': self.performance_metrics['transactions_processed'],
            'uptime_seconds': uptime,
            'messages_per_second': self.performance_metrics['messages_processed'] / uptime if uptime > 0 else 0,
            'average_latency_ms': self.performance_metrics['total_latency_ms'] / self.performance_metrics['messages_processed'] if self.performance_metrics['messages_processed'] > 0 else 0,
            'current_transaction_state': self.transaction_state.value,
            'current_transaction_id': self.current_transaction_id
        }
    
    def switch_pipeline_mode(self, new_mode: PipelineMode):
        """Switch pipeline mode"""
        logger.info(f"Switching pipeline mode from {self.pipeline_mode.value} to {new_mode.value}")
        
        # End current transaction if active
        if self.transaction_state != TransactionState.IDLE:
            logger.warning("Ending active transaction due to pipeline mode switch")
            self.transaction_state = TransactionState.IDLE
            self.current_transaction_id = None
            self.transaction_start_time = None
            self.transaction_data_buffer = []
        
        # Switch mode
        self.pipeline_mode = new_mode
        self._initialize_pipeline()
        
        logger.info(f"Pipeline mode switched to {new_mode.value}")
    
    def toggle_live_streaming(self, enabled: bool, temporary: bool = False):
        """Toggle live streaming on/off"""
        logger.info(f"Toggling live streaming: enabled={enabled}, temporary={temporary}")
        
        self.live_streaming_enabled = enabled
        self.live_streaming_temporary = temporary
        
        logger.info(f"Live streaming: {'ENABLED' if enabled else 'DISABLED'} {'(temporary)' if temporary else ''}")
    
    def get_configuration_summary(self) -> Dict[str, Any]:
        """Get configuration summary"""
        return {
            'pipeline_mode': self.pipeline_mode.value,
            'live_streaming_enabled': self.live_streaming_enabled,
            'live_streaming_temporary': self.live_streaming_temporary,
            'external_systems_count': len(self.output_config.get('external_systems', [])),
            'analytics_api_enabled': self.output_config.get('analytics_api_enabled', False),
            'performance_targets': self.performance_config
        } 