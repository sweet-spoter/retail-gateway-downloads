import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  EyeIcon, 
  ClockIcon, 
  ExclamationTriangleIcon, 
  CheckCircleIcon,
  XCircleIcon,
  ArrowPathIcon,
  ChartBarIcon,
  DeviceTabletIcon
} from '@heroicons/react/24/outline';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { monitoringAPI, deviceAPI } from '../../services/api';

interface DeviceStatus {
  id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error' | 'connecting';
  last_activity: string;
  error_count: number;
  lane_id?: string;
}

interface Transaction {
  id: string;
  lane_id: string;
  register_id: string;
  cashier_id: string;
  start_time: string;
  end_time?: string;
  status: 'active' | 'completed' | 'timeout' | 'error';
  events: TransactionEvent[];
  total_amount?: number;
  currency?: string;
}

interface TransactionEvent {
  id: string;
  device_id: string;
  device_type: string;
  event_type: string;
  timestamp: string;
  payload: any;
}

interface LaneStatus {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  device_count: number;
  active_transactions: number;
  last_activity: string;
}

const Monitoring: React.FC = () => {
  const [selectedLane, setSelectedLane] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<'1h' | '6h' | '24h' | '7d'>('1h');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  // Fetch monitoring data
  const { data: devices = [], isLoading: devicesLoading } = useQuery({
    queryKey: ['monitoring-devices'],
    queryFn: deviceAPI.getDevices,
    refetchInterval: 2000, // Refresh every 2 seconds for real-time monitoring
  });

  const { data: transactions = [], isLoading: transactionsLoading } = useQuery({
    queryKey: ['monitoring-transactions', timeRange],
    queryFn: () => monitoringAPI.getTransactions(timeRange),
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: lanes = [], isLoading: lanesLoading } = useQuery({
    queryKey: ['monitoring-lanes'],
    queryFn: monitoringAPI.getLanesStatus,
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  const { data: metrics = {}, isLoading: metricsLoading } = useQuery({
    queryKey: ['monitoring-metrics', timeRange],
    queryFn: () => monitoringAPI.getMetrics(timeRange),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Filter data based on selected lane
  const filteredDevices = selectedLane === 'all' 
    ? devices 
    : devices.filter(device => device.lane_id === selectedLane);

  const filteredTransactions = selectedLane === 'all'
    ? transactions
    : transactions.filter(tx => tx.lane_id === selectedLane);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
      case 'active':
      case 'completed':
        return 'text-green-600 bg-green-100';
      case 'connecting':
        return 'text-yellow-600 bg-yellow-100';
      case 'disconnected':
      case 'inactive':
        return 'text-gray-600 bg-gray-100';
      case 'error':
      case 'timeout':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
      case 'active':
      case 'completed':
        return <CheckCircleIcon className="w-4 h-4" />;
      case 'connecting':
        return <ArrowPathIcon className="w-4 h-4 animate-spin" />;
      case 'disconnected':
      case 'inactive':
        return <XCircleIcon className="w-4 h-4" />;
      case 'error':
      case 'timeout':
        return <ExclamationTriangleIcon className="w-4 h-4" />;
      default:
        return <XCircleIcon className="w-4 h-4" />;
    }
  };

  if (devicesLoading || transactionsLoading || lanesLoading || metricsLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Real-Time Monitoring</h1>
          <p className="text-gray-600">Monitor devices, transactions, and system performance</p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={selectedLane}
            onChange={(e) => setSelectedLane(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Lanes</option>
            {lanes.map((lane) => (
              <option key={lane.id} value={lane.id}>
                {lane.name}
              </option>
            ))}
          </select>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as any)}
            className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="1h">Last Hour</option>
            <option value="6h">Last 6 Hours</option>
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
          </select>
        </div>
      </div>

      {/* System Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <DeviceTabletIcon className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Total Devices</p>
              <p className="text-lg font-semibold text-gray-900">{devices.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CheckCircleIcon className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Connected</p>
              <p className="text-lg font-semibold text-gray-900">
                {devices.filter(d => d.status === 'connected').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ClockIcon className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Active Transactions</p>
              <p className="text-lg font-semibold text-gray-900">
                {transactions.filter(tx => tx.status === 'active').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ExclamationTriangleIcon className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Errors</p>
              <p className="text-lg font-semibold text-gray-900">
                {devices.filter(d => d.status === 'error').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Transaction Volume Chart */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Transaction Volume</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={metrics.transaction_volume || []}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#3B82F6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Device Status Chart */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Device Status Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={[
              { status: 'Connected', count: devices.filter(d => d.status === 'connected').length },
              { status: 'Disconnected', count: devices.filter(d => d.status === 'disconnected').length },
              { status: 'Error', count: devices.filter(d => d.status === 'error').length },
              { status: 'Connecting', count: devices.filter(d => d.status === 'connecting').length },
            ]}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="status" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3B82F6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Device Status Table */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Device Status</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Device
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Activity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Errors
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDevices.map((device) => (
                <tr key={device.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{device.name}</div>
                      <div className="text-sm text-gray-500">ID: {device.id}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {device.type}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(device.status)}`}>
                      {getStatusIcon(device.status)}
                      <span className="ml-1">{device.status}</span>
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {device.last_activity ? new Date(device.last_activity).toLocaleString() : 'Never'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {device.error_count}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transactions Timeline */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Transaction Timeline</h3>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {filteredTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 cursor-pointer"
                onClick={() => setSelectedTransaction(transaction)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(transaction.status)}`}>
                        {getStatusIcon(transaction.status)}
                        <span className="ml-1">{transaction.status}</span>
                      </span>
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">
                        Transaction {transaction.id}
                      </h4>
                      <p className="text-sm text-gray-500">
                        Lane: {transaction.lane_id} • Register: {transaction.register_id} • Cashier: {transaction.cashier_id}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-900">
                      {new Date(transaction.start_time).toLocaleTimeString()}
                    </div>
                    <div className="text-sm text-gray-500">
                      {transaction.events.length} events
                    </div>
                    {transaction.total_amount && (
                      <div className="text-sm font-medium text-green-600">
                        ${transaction.total_amount.toFixed(2)} {transaction.currency}
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Event Timeline */}
                <div className="mt-4">
                  <div className="flex items-center space-x-2">
                    {transaction.events.map((event, index) => (
                      <div key={event.id} className="flex items-center">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <span className="text-xs text-gray-500 ml-1">
                          {event.device_type}: {event.event_type}
                        </span>
                        {index < transaction.events.length - 1 && (
                          <div className="w-4 h-px bg-gray-300 mx-2"></div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Transaction Detail Modal */}
      {selectedTransaction && (
        <TransactionDetailModal
          transaction={selectedTransaction}
          onClose={() => setSelectedTransaction(null)}
        />
      )}
    </div>
  );
};

// Transaction Detail Modal Component
const TransactionDetailModal: React.FC<{
  transaction: Transaction;
  onClose: () => void;
}> = ({ transaction, onClose }) => {
  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-11/12 max-w-4xl shadow-lg rounded-md bg-white">
        <div className="mt-3">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">
              Transaction Details: {transaction.id}
            </h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <XCircleIcon className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Transaction Info */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <h4 className="text-sm font-medium text-gray-500">Status</h4>
                <p className="text-lg font-semibold text-gray-900">{transaction.status}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-500">Lane</h4>
                <p className="text-lg font-semibold text-gray-900">{transaction.lane_id}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-500">Register</h4>
                <p className="text-lg font-semibold text-gray-900">{transaction.register_id}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-500">Cashier</h4>
                <p className="text-lg font-semibold text-gray-900">{transaction.cashier_id}</p>
              </div>
              <div>
                <h4 className="text-sm font-medium text-gray-500">Start Time</h4>
                <p className="text-lg font-semibold text-gray-900">
                  {new Date(transaction.start_time).toLocaleString()}
                </p>
              </div>
              {transaction.end_time && (
                <div>
                  <h4 className="text-sm font-medium text-gray-500">End Time</h4>
                  <p className="text-lg font-semibold text-gray-900">
                    {new Date(transaction.end_time).toLocaleString()}
                  </p>
                </div>
              )}
            </div>

            {/* Amount Information */}
            {transaction.total_amount && (
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium text-green-800">Total Amount</h4>
                <p className="text-2xl font-bold text-green-900">
                  ${transaction.total_amount.toFixed(2)} {transaction.currency}
                </p>
              </div>
            )}

            {/* Events Timeline */}
            <div>
              <h4 className="text-lg font-medium text-gray-900 mb-4">Event Timeline</h4>
              <div className="space-y-3">
                {transaction.events.map((event, index) => (
                  <div key={event.id} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium text-blue-600">{index + 1}</span>
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {event.device_type}: {event.event_type}
                          </p>
                          <p className="text-sm text-gray-500">
                            Device: {event.device_id}
                          </p>
                        </div>
                        <div className="text-sm text-gray-500">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                      {event.payload && Object.keys(event.payload).length > 0 && (
                        <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                          <pre className="text-gray-700">
                            {JSON.stringify(event.payload, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Monitoring; 