"""
Abstract base class for streaming transaction pipeline.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any
from enum import Enum

class TransactionState(Enum):
    IDLE = "idle"
    STARTING = "starting"
    STREAMING = "streaming"
    ENDING = "ending"

class StreamingPipeline(ABC):
    """
    Abstract base class for streaming transaction pipeline.
    Handles the flow: Data → Start → Stream → End → Repeat
    """
    
    def __init__(self, config: dict):
        self.config = config
        self.tcp_pipeline_host = config.get('tcp_pipeline_host', 'localhost')
        self.tcp_pipeline_port = config.get('tcp_pipeline_port', 9000)
        self.transaction_timeout = config.get('transaction_timeout', 30)
        self.current_transaction = None
        self.transaction_state = TransactionState.IDLE
        self.streaming_buffer = []
    
    def process_streaming_data(self, device_data: bytes, device_info: dict) -> dict:
        """
        Main streaming pipeline: Data → Start → Stream → End → Repeat
        
        Args:
            device_data: Raw device data
            device_info: Device information dictionary
            
        Returns:
            dict: Streaming processing result
        """
        try:
            # Step 1: Check if we need to start a new transaction
            if self.transaction_state == TransactionState.IDLE:
                self._start_transaction_with_data(device_data, device_info)
                self.transaction_state = TransactionState.STREAMING
            
            # Step 2: Stream data as it arrives
            self._stream_data(device_data, device_info)
            
            # Step 3: Check if end of data is detected
            if self._is_end_of_data_detected(device_data, device_info):
                # Step 4: End transaction and prepare for next
                self._end_transaction_with_data(device_data, device_info)
                self.transaction_state = TransactionState.IDLE
                
                return {
                    "status": "transaction_complete",
                    "device_type": device_info.get("device_type"),
                    "transaction_id": self.current_transaction
                }
            
            return {
                "status": "streaming",
                "device_type": device_info.get("device_type"),
                "transaction_id": self.current_transaction
            }
            
        except Exception as e:
            self._handle_streaming_error(e, device_info)
            return {"status": "error", "error": str(e)}
    
    @abstractmethod
    def _start_transaction_with_data(self, device_data: bytes, device_info: dict):
        """
        Send Start Transaction + Initial Device Data
        
        Args:
            device_data: Raw device data
            device_info: Device information
        """
        pass
    
    @abstractmethod
    def _stream_data(self, device_data: bytes, device_info: dict):
        """
        Stream data as it arrives
        
        Args:
            device_data: Raw device data
            device_info: Device information
        """
        pass
    
    @abstractmethod
    def _end_transaction_with_data(self, device_data: bytes, device_info: dict):
        """
        Send End Data + End Transaction
        
        Args:
            device_data: Raw device data
            device_info: Device information
        """
        pass
    
    @abstractmethod
    def _is_end_of_data_detected(self, device_data: bytes, device_info: dict) -> bool:
        """
        Detect end of data stream
        
        Args:
            device_data: Raw device data
            device_info: Device information
            
        Returns:
            bool: True if end of data is detected
        """
        pass
    
    def _handle_streaming_error(self, error: Exception, device_info: dict):
        """
        Handle streaming errors
        
        Args:
            error: Exception that occurred
            device_info: Device information
        """
        self.transaction_state = TransactionState.IDLE
        self.streaming_buffer.clear()
        print(f"Streaming error for {device_info.get('device_type')}: {error}")
    
    def _get_timestamp(self) -> str:
        """
        Get current timestamp
        
        Returns:
            str: ISO formatted timestamp
        """
        from datetime import datetime
        return datetime.now().isoformat() 