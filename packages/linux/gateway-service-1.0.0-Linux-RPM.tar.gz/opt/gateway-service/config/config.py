import sys
import os
import shutil
import json
import logging
from logging.handlers import RotatingFileHandler
from typing import Dict, Any
from core.logging_config import setup_application_logging, get_logger
from core.exceptions import ConfigurationError
from models.device_config import AppConfig

def ensure_config_exists():
    """Ensure configuration file exists, copy from frozen executable if needed"""
    executable_dir = os.path.dirname(sys.executable)
    target_config_path = os.path.join(executable_dir, 'config.json')
    if not os.path.exists(target_config_path):
        source_config_path = os.path.join(sys._MEIPASS, 'config.json')
        shutil.copy(source_config_path, target_config_path)
    return target_config_path

def load_config() -> Dict[str, Any]:
    """Load configuration from JSON file"""
    try:
        if getattr(sys, 'frozen', False):
            # The application is frozen
            base_path = sys._MEIPASS
            config_path = ensure_config_exists()
        else:
            # The application is not frozen
            base_path = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(base_path, 'config.json')
        
        logger = get_logger(__name__)
        logger.info(f"Loading configuration from: {config_path}")
        
        with open(config_path, 'r') as config_file:
            config = json.load(config_file)
        
        # Validate configuration
        try:
            AppConfig.from_dict(config)
            logger.info("Configuration loaded and validated successfully")
        except Exception as e:
            logger.error(f"Configuration validation failed: {e}")
            raise ConfigurationError(f"Invalid configuration: {e}")
        
        return config
        
    except FileNotFoundError:
        raise ConfigurationError(f"Configuration file not found: {config_path}")
    except json.JSONDecodeError as e:
        raise ConfigurationError(f"Invalid JSON in configuration file: {e}")
    except Exception as e:
        raise ConfigurationError(f"Failed to load configuration: {e}")

def save_config(config: Dict[str, Any]) -> None:
    """Save the updated configuration back to the JSON file"""
    try:
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
            config_path = ensure_config_exists()
        else:
            base_path = os.path.dirname(os.path.abspath(__file__))
            config_path = os.path.join(base_path, 'config.json')
        
        logger = get_logger(__name__)
        
        # Validate configuration before saving
        try:
            AppConfig.from_dict(config)
        except Exception as e:
            logger.error(f"Configuration validation failed before saving: {e}")
            raise ConfigurationError(f"Invalid configuration: {e}")
        
        with open(config_path, 'w') as config_file:
            json.dump(config, config_file, indent=4)
        
        logger.info(f"Configuration saved to {config_path}")
        
    except Exception as e:
        logger.error(f"Failed to save configuration: {e}")
        raise ConfigurationError(f"Failed to save configuration: {e}")

def get_config() -> Dict[str, Any]:
    """Get current configuration"""
    return load_config()

def validate_config(config: Dict[str, Any]) -> bool:
    """Validate configuration"""
    try:
        AppConfig.from_dict(config)
        return True
    except Exception:
        return False

# Initialize logging first
try:
    _config = load_config()
    logger = setup_application_logging(_config)
    logger.info("Configuration and logging initialized successfully")
except Exception as e:
    # Fallback logging if configuration fails
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    logger.error(f"Failed to initialize configuration: {e}")
    raise

# Legacy exports for backward compatibility
input_configs = _config['input_configs']
output_configs = _config['output_configs']