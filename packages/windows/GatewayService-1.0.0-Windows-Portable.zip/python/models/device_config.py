from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any
from core.exceptions import ValidationError

class TerminalConfig(BaseModel):
    """Configuration for a terminal device"""
    term_id: int = Field(..., description="Terminal ID")
    term_ip: str = Field(..., description="Terminal IP address or range")

class DeviceConfig(BaseModel):
    """Configuration for a device"""
    name: str = Field(..., description="Device name")
    type: str = Field(..., description="Device type (e.g., 'handshake', 'none')")
    terminals: Optional[List[TerminalConfig]] = Field(None, description="List of terminals")

class FilterConfig(BaseModel):
    """Configuration for data filtering"""
    date: List[int] = Field(..., description="Date field positions [start, end]")
    time: List[int] = Field(..., description="Time field positions [start, end]")
    terminal: List[int] = Field(..., description="Terminal field positions [start, end]")
    description: List[int] = Field(..., description="Description field positions [start, end]")
    quantity: List[int] = Field(..., description="Quantity field positions [start, end]")
    price: List[Optional[int]] = Field(..., description="Price field positions [start, end]")

    @validator('date', 'time', 'terminal', 'description', 'quantity', 'price')
    def validate_field_positions(cls, v):
        if len(v) != 2:
            raise ValidationError("Field positions must have exactly 2 values [start, end]")
        return v

class SocketConfig(BaseModel):
    """Configuration for a socket connection"""
    socket_type: str = Field(..., description="Socket type (tcp, udp, multicast)")
    connection_type: str = Field(..., description="Connection type (listen, connect)")
    host: str = Field(..., description="Host address")
    port: int = Field(..., ge=1, le=65535, description="Port number")
    register: str = Field(..., description="Register identifier")
    device: DeviceConfig = Field(..., description="Device configuration")
    filter: Optional[FilterConfig] = Field(None, description="Data filter configuration")

    @validator('socket_type')
    def validate_socket_type(cls, v):
        allowed_types = ['tcp', 'udp', 'multicast']
        if v not in allowed_types:
            raise ValidationError(f"Socket type must be one of: {allowed_types}")
        return v

    @validator('connection_type')
    def validate_connection_type(cls, v):
        allowed_types = ['listen', 'connect']
        if v not in allowed_types:
            raise ValidationError(f"Connection type must be one of: {allowed_types}")
        return v

    @validator('host')
    def validate_host(cls, v):
        if not v or v.strip() == "":
            raise ValidationError("Host cannot be empty")
        return v

class AppConfig(BaseModel):
    """Main application configuration"""
    debug: bool = Field(False, description="Enable debug mode")
    discover_remote_ip: bool = Field(False, description="Enable IP discovery")
    input_configs: List[SocketConfig] = Field(..., description="Input socket configurations")
    output_configs: List[SocketConfig] = Field(..., description="Output socket configurations")

    @validator('input_configs', 'output_configs')
    def validate_configs_not_empty(cls, v):
        if not v:
            raise ValidationError("At least one configuration must be provided")
        return v

    def get_input_config_by_register(self, register: str) -> Optional[SocketConfig]:
        """Get input configuration by register"""
        for config in self.input_configs:
            if config.register == register:
                return config
        return None

    def get_output_config_by_register(self, register: str) -> Optional[SocketConfig]:
        """Get output configuration by register"""
        for config in self.output_configs:
            if config.register == register:
                return config
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        return self.dict()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AppConfig':
        """Create configuration from dictionary"""
        return cls(**data) 