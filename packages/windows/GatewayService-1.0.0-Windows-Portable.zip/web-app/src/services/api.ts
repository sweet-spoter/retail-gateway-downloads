import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { mockAuthAPI, mockHealthAPI, mockMetricsAPI, mockServiceAPI, mockDeviceAPI, mockConfigAPI, mockGatewayInfo, mockLocation, mockClient } from './mockApi';

// API base configuration
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
apiClient.interceptors.response.use(
  (response: AxiosResponse) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Use mock APIs for testing (change this to false to use real API)
const USE_MOCK_API = true;

// Enhanced API interfaces for Phase 4
export interface DeviceStatus {
  id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error' | 'connecting';
  last_activity: string;
  error_count: number;
  lane_id?: string;
  connection_type: 'sdk' | 'socket';
  sdk_type?: 'python' | 'cpp' | 'csharp';
  socket_config?: {
    type: 'tcp' | 'udp' | 'multicast';
    host: string;
    port: number;
    mode: 'connect' | 'listen';
  };
  sdk_config?: {
    sdk_type: 'python' | 'cpp' | 'csharp';
    module?: string;
    dll_path?: string;
    assembly?: string;
    runtime?: string;
    version?: string;
  };
}

export interface Transaction {
  id: string;
  lane_id: string;
  register_id: string;
  cashier_id: string;
  start_time: string;
  end_time?: string;
  status: 'active' | 'completed' | 'timeout' | 'error';
  events: TransactionEvent[];
  total_amount?: number;
  currency?: string;
}

export interface TransactionEvent {
  id: string;
  device_id: string;
  device_type: string;
  event_type: string;
  timestamp: string;
  payload: any;
}

export interface LaneConfig {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  license_required: boolean;
  license_status: 'active' | 'expired' | 'trial' | 'disabled';
  activation_date?: string;
  expiration_date?: string;
  grace_period_until?: string;
  devices: {
    [key: string]: {
      device_type: string;
      connection_type: 'sdk' | 'socket';
      sdk_config?: {
        sdk_type: 'python' | 'cpp' | 'csharp';
        module?: string;
        dll_path?: string;
        assembly?: string;
        runtime?: string;
      };
      socket_config?: {
        type: 'tcp' | 'udp' | 'multicast';
        host: string;
        port: number;
        mode: 'connect' | 'listen';
      };
    };
  };
  sessionizer: {
    enabled: boolean;
    timeout: number;
    expected_sequence: string[];
    correlation_window: number;
  };
  outputs: {
    live_events: {
      enabled: boolean;
      destinations: string[];
    };
    transaction_bundles: {
      enabled: boolean;
      destinations: string[];
    };
  };
}

export interface LicenseInfo {
  license_key: string;
  license_type: 'trial' | 'basic' | 'professional' | 'enterprise';
  status: 'active' | 'expired' | 'disabled';
  activation_date: string;
  expiration_date: string;
  grace_period_until?: string;
  max_lanes: number;
  active_lanes: number;
  features: string[];
}

export interface MonitoringMetrics {
  transaction_volume: Array<{ time: string; count: number }>;
  device_status_distribution: Array<{ status: string; count: number }>;
  error_rate: number;
  average_response_time: number;
  throughput: number;
}

// Types
export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  user: {
    id: string;
    username: string;
    email: string;
    role: 'admin' | 'user' | 'viewer';
    permissions: string[];
  };
  token: string;
}

export interface Device {
  id: string;
  name: string;
  type: string;
  status: 'online' | 'offline' | 'error';
  lastSeen: string;
  configuration: any;
}

export interface Location {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  country: string;
  timezone: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

export interface Client {
  id: string;
  name: string;
  code: string;
  contact: {
    email: string;
    phone: string;
    address: string;
  };
  settings: {
    timezone: string;
    currency: string;
    language: string;
  };
}

export interface GatewayService {
  id: string;
  name: string;
  version: string;
  location: Location;
  client: Client;
  status: 'running' | 'stopped' | 'error';
  lastSeen: string;
  uptime: number;
  configuration: {
    inputDevices: Device[];
    outputDevices: Device[];
    analyticsApi: {
      endpoint: string;
      apiKey: string;
      enabled: boolean;
    };
  };
}

export interface Configuration {
  id: string;
  name: string;
  type: 'input' | 'output' | 'analytics';
  socketType: string;
  connectionType: string;
  host: string;
  port: number;
  device: any;
  filter?: any;
  analytics?: {
    enabled: boolean;
    endpoint: string;
    apiKey: string;
    dataMapping: Record<string, string>;
  };
}

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy' | 'unknown';
  message: string;
  timestamp: number;
  checks: Array<{
    name: string;
    status: string;
    message: string;
    details?: any;
    timestamp: number;
  }>;
}

export interface Metrics {
  timestamp: number;
  metrics: Record<string, {
    name: string;
    description: string;
    count: number;
    min: number | null;
    max: number | null;
    avg: number | null;
    latest: number | null;
  }>;
}

// Auth API
export const authAPI = {
  login: async (username: string, password: string): Promise<LoginResponse> => {
    if (USE_MOCK_API) {
      return mockAuthAPI.login(username, password);
    }
    const response = await apiClient.post('/api/auth/login', { username, password });
    return response.data;
  },

  validateToken: async (token: string) => {
    if (USE_MOCK_API) {
      return mockAuthAPI.validateToken(token);
    }
    const response = await apiClient.get('/api/auth/validate', {
      headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
  },

  logout: async () => {
    if (USE_MOCK_API) {
      return mockAuthAPI.logout();
    }
    await apiClient.post('/api/auth/logout');
  },
};

// Device API
export const deviceAPI = {
  getDevices: async (): Promise<DeviceStatus[]> => {
    if (USE_MOCK_API) {
      return [
        {
          id: 'pos_001',
          name: 'Verifone Terminal',
          type: 'pos',
          status: 'connected',
          last_activity: new Date().toISOString(),
          error_count: 0,
          lane_id: 'lane_1',
          connection_type: 'sdk',
          sdk_type: 'csharp',
          sdk_config: {
            sdk_type: 'csharp',
            assembly: 'VerifoneSDK.dll',
            runtime: 'net6.0'
          }
        },
        {
          id: 'drawer_001',
          name: 'Cash Drawer',
          type: 'drawer',
          status: 'connected',
          last_activity: new Date().toISOString(),
          error_count: 0,
          lane_id: 'lane_1',
          connection_type: 'socket',
          socket_config: {
            type: 'tcp',
            host: '192.168.1.100',
            port: 8080,
            mode: 'connect'
          }
        }
      ];
    }
    const response = await apiClient.get('/api/devices');
    return response.data;
  },

  getDevice: async (id: string): Promise<DeviceStatus> => {
    if (USE_MOCK_API) {
      return {
        id,
        name: 'Mock Device',
        type: 'pos',
        status: 'connected',
        last_activity: new Date().toISOString(),
        error_count: 0,
        lane_id: 'lane_1',
        connection_type: 'sdk',
        sdk_type: 'csharp'
      };
    }
    const response = await apiClient.get(`/api/devices/${id}`);
    return response.data;
  },

  addDevice: async (device: any): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Device added successfully' };
    }
    const response = await apiClient.post('/api/devices', device);
    return response.data;
  },

  updateDevice: async (id: string, device: any): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Device updated successfully' };
    }
    const response = await apiClient.put(`/api/devices/${id}`, device);
    return response.data;
  },

  deleteDevice: async (id: string): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Device deleted successfully' };
    }
    const response = await apiClient.delete(`/api/devices/${id}`);
    return response.data;
  },

  connectDevice: async (id: string): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Device connected successfully' };
    }
    const response = await apiClient.post(`/api/devices/${id}/connect`);
    return response.data;
  },

  disconnectDevice: async (id: string): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Device disconnected successfully' };
    }
    const response = await apiClient.post(`/api/devices/${id}/disconnect`);
    return response.data;
  },

  getLanes: async (): Promise<any[]> => {
    if (USE_MOCK_API) {
      return [
        { id: 'lane_1', name: 'Lane 1', device_count: 3 },
        { id: 'lane_2', name: 'Lane 2', device_count: 2 }
      ];
    }
    const response = await apiClient.get('/api/lanes');
    return response.data;
  },

  discoverDevices: async (): Promise<DeviceStatus[]> => {
    if (USE_MOCK_API) {
      return [
        {
          id: 'discovered_001',
          name: 'Discovered Device',
          type: 'pos',
          status: 'disconnected',
          last_activity: new Date().toISOString(),
          error_count: 0,
          connection_type: 'socket'
        }
      ];
    }
    const response = await apiClient.post('/api/devices/discover');
    return response.data;
  },
};

// Configuration API
export const configAPI = {
  getConfiguration: async (): Promise<Configuration[]> => {
    const response = await apiClient.get('/api/config');
    return response.data;
  },

  getConfigurationById: async (id: string): Promise<Configuration> => {
    const response = await apiClient.get(`/api/config/${id}`);
    return response.data;
  },

  createConfiguration: async (config: Partial<Configuration>): Promise<Configuration> => {
    const response = await apiClient.post('/api/config', config);
    return response.data;
  },

  updateConfiguration: async (id: string, config: Partial<Configuration>): Promise<Configuration> => {
    const response = await apiClient.put(`/api/config/${id}`, config);
    return response.data;
  },

  deleteConfiguration: async (id: string): Promise<void> => {
    await apiClient.delete(`/api/config/${id}`);
  },

  testConfiguration: async (config: Partial<Configuration>): Promise<{ success: boolean; message: string }> => {
    const response = await apiClient.post('/api/config/test', config);
    return response.data;
  },

  exportConfiguration: async (): Promise<Blob> => {
    const response = await apiClient.get('/api/config/export', {
      responseType: 'blob',
    });
    return response.data;
  },

  importConfiguration: async (file: File): Promise<{ success: boolean; message: string }> => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await apiClient.post('/api/config/import', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },
};

// Health API
export const healthAPI = {
  getHealth: async (): Promise<HealthStatus> => {
    if (USE_MOCK_API) {
      return mockHealthAPI.getHealth();
    }
    const response = await apiClient.get('/health');
    return response.data;
  },

  getStatus: async (): Promise<any> => {
    if (USE_MOCK_API) {
      return mockHealthAPI.getStatus();
    }
    const response = await apiClient.get('/status');
    return response.data;
  },

  getInfo: async (): Promise<any> => {
    if (USE_MOCK_API) {
      return mockHealthAPI.getInfo();
    }
    const response = await apiClient.get('/info');
    return response.data;
  },
};

// Metrics API
export const metricsAPI = {
  getMetrics: async (): Promise<Metrics> => {
    if (USE_MOCK_API) {
      return mockMetricsAPI.getMetrics();
    }
    const response = await apiClient.get('/metrics/json');
    return response.data;
  },

  getPrometheusMetrics: async (): Promise<string> => {
    if (USE_MOCK_API) {
      return mockMetricsAPI.getPrometheusMetrics();
    }
    const response = await apiClient.get('/metrics', {
      responseType: 'text',
    });
    return response.data;
  },
};

// Service API
export const serviceAPI = {
  startService: async (): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return mockServiceAPI.startService();
    }
    const response = await apiClient.post('/api/service/start');
    return response.data;
  },

  stopService: async (): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return mockServiceAPI.stopService();
    }
    const response = await apiClient.post('/api/service/stop');
    return response.data;
  },

  restartService: async (): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return mockServiceAPI.restartService();
    }
    const response = await apiClient.post('/api/service/restart');
    return response.data;
  },

  getServiceStatus: async (): Promise<any> => {
    if (USE_MOCK_API) {
      return mockServiceAPI.getServiceStatus();
    }
    const response = await apiClient.get('/api/service/status');
    return response.data;
  },
};

// License API
export const licenseAPI = {
  getLicenseInfo: async (): Promise<LicenseInfo> => {
    if (USE_MOCK_API) {
      return {
        license_key: 'MOCK-LICENSE-KEY',
        license_type: 'professional',
        status: 'active',
        activation_date: '2024-01-01T00:00:00Z',
        expiration_date: '2025-01-01T00:00:00Z',
        max_lanes: 10,
        active_lanes: 3,
        features: ['SDK Integration', 'Real-time Monitoring', 'Transaction Bundles', 'Advanced Analytics']
      };
    }
    const response = await apiClient.get('/api/license');
    return response.data;
  },

  validateLicense: async (licenseKey: string): Promise<{ valid: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { valid: true, message: 'License is valid' };
    }
    const response = await apiClient.post('/api/license/validate', { licenseKey });
    return response.data;
  },

  activateLicense: async (licenseKey: string): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'License activated successfully' };
    }
    const response = await apiClient.post('/api/license/activate', { licenseKey });
    return response.data;
  },
};

// Monitoring API
export const monitoringAPI = {
  getTransactions: async (timeRange: string): Promise<Transaction[]> => {
    if (USE_MOCK_API) {
      return [
        {
          id: 'tx_001',
          lane_id: 'lane_1',
          register_id: 'register_101',
          cashier_id: 'cashier_001',
          start_time: new Date(Date.now() - 300000).toISOString(),
          status: 'completed',
          events: [
            {
              id: 'evt_001',
              device_id: 'pos_001',
              device_type: 'pos',
              event_type: 'payment_received',
              timestamp: new Date(Date.now() - 300000).toISOString(),
              payload: { amount: 25.50, currency: 'USD' }
            },
            {
              id: 'evt_002',
              device_id: 'drawer_001',
              device_type: 'drawer',
              event_type: 'drawer_open',
              timestamp: new Date(Date.now() - 299000).toISOString(),
              payload: { reason: 'payment' }
            }
          ],
          total_amount: 25.50,
          currency: 'USD'
        }
      ];
    }
    const response = await apiClient.get(`/api/monitoring/transactions?timeRange=${timeRange}`);
    return response.data;
  },

  getLanesStatus: async (): Promise<any[]> => {
    if (USE_MOCK_API) {
      return [
        { id: 'lane_1', name: 'Lane 1', status: 'active', device_count: 3, active_transactions: 1, last_activity: new Date().toISOString() },
        { id: 'lane_2', name: 'Lane 2', status: 'active', device_count: 2, active_transactions: 0, last_activity: new Date().toISOString() }
      ];
    }
    const response = await apiClient.get('/api/monitoring/lanes');
    return response.data;
  },

  getMetrics: async (timeRange: string): Promise<MonitoringMetrics> => {
    if (USE_MOCK_API) {
      return {
        transaction_volume: [
          { time: '10:00', count: 5 },
          { time: '11:00', count: 8 },
          { time: '12:00', count: 12 },
          { time: '13:00', count: 15 },
          { time: '14:00', count: 10 }
        ],
        device_status_distribution: [
          { status: 'Connected', count: 8 },
          { status: 'Disconnected', count: 2 },
          { status: 'Error', count: 1 }
        ],
        error_rate: 0.05,
        average_response_time: 150,
        throughput: 25.5
      };
    }
    const response = await apiClient.get(`/api/monitoring/metrics?timeRange=${timeRange}`);
    return response.data;
  }
};

// Configuration API
export const configAPI = {
  getLanesConfig: async (): Promise<{ [key: string]: LaneConfig }> => {
    if (USE_MOCK_API) {
      return {
        lane_1: {
          id: 'lane_1',
          name: 'Lane 1',
          status: 'active',
          license_required: true,
          license_status: 'active',
          devices: {
            pos: {
              device_type: 'verifone_terminal',
              connection_type: 'sdk',
              sdk_config: {
                sdk_type: 'csharp',
                assembly: 'VerifoneSDK.dll',
                runtime: 'net6.0'
              }
            },
            drawer: {
              device_type: 'cash_drawer',
              connection_type: 'socket',
              socket_config: {
                type: 'tcp',
                host: '192.168.1.100',
                port: 8080,
                mode: 'connect'
              }
            }
          },
          sessionizer: {
            enabled: true,
            timeout: 300,
            expected_sequence: ['pos', 'drawer'],
            correlation_window: 60
          },
          outputs: {
            live_events: {
              enabled: true,
              destinations: ['tcp://192.168.1.200:9000']
            },
            transaction_bundles: {
              enabled: true,
              destinations: ['https://api.example.com/transactions']
            }
          }
        }
      };
    }
    const response = await apiClient.get('/api/config/lanes');
    return response.data;
  },

  updateLaneConfig: async (laneId: string, config: LaneConfig): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Lane configuration updated successfully' };
    }
    const response = await apiClient.put(`/api/config/lanes/${laneId}`, config);
    return response.data;
  },

  addLane: async (config: any): Promise<{ success: boolean; message: string }> => {
    if (USE_MOCK_API) {
      return { success: true, message: 'Lane added successfully' };
    }
    const response = await apiClient.post('/api/config/lanes', config);
    return response.data;
  }
};

// Location & Client API
export const locationAPI = {
  getLocations: async (): Promise<Location[]> => {
    if (USE_MOCK_API) {
      return [mockLocation];
    }
    const response = await apiClient.get('/api/locations');
    return response.data;
  },

  getLocation: async (id: string): Promise<Location> => {
    if (USE_MOCK_API) {
      return mockLocation;
    }
    const response = await apiClient.get(`/api/locations/${id}`);
    return response.data;
  },

  createLocation: async (location: Partial<Location>): Promise<Location> => {
    if (USE_MOCK_API) {
      return { ...mockLocation, ...location, id: Date.now().toString() };
    }
    const response = await apiClient.post('/api/locations', location);
    return response.data;
  },

  updateLocation: async (id: string, location: Partial<Location>): Promise<Location> => {
    if (USE_MOCK_API) {
      return { ...mockLocation, ...location, id };
    }
    const response = await apiClient.put(`/api/locations/${id}`, location);
    return response.data;
  },
};

export const clientAPI = {
  getClients: async (): Promise<Client[]> => {
    if (USE_MOCK_API) {
      return [mockClient];
    }
    const response = await apiClient.get('/api/clients');
    return response.data;
  },

  getClient: async (id: string): Promise<Client> => {
    if (USE_MOCK_API) {
      return mockClient;
    }
    const response = await apiClient.get(`/api/clients/${id}`);
    return response.data;
  },

  createClient: async (client: Partial<Client>): Promise<Client> => {
    if (USE_MOCK_API) {
      return { ...mockClient, ...client, id: Date.now().toString() };
    }
    const response = await apiClient.post('/api/clients', client);
    return response.data;
  },

  updateClient: async (id: string, client: Partial<Client>): Promise<Client> => {
    if (USE_MOCK_API) {
      return { ...mockClient, ...client, id };
    }
    const response = await apiClient.put(`/api/clients/${id}`, client);
    return response.data;
  },
};

export const gatewayAPI = {
  getGatewayInfo: async (): Promise<GatewayService> => {
    if (USE_MOCK_API) {
      return mockGatewayInfo;
    }
    const response = await apiClient.get('/api/gateway');
    return response.data;
  },

  updateGatewayConfig: async (config: Partial<GatewayService>): Promise<GatewayService> => {
    if (USE_MOCK_API) {
      return { ...mockGatewayInfo, ...config };
    }
    const response = await apiClient.put('/api/gateway/config', config);
    return response.data;
  },
};

export default apiClient; 