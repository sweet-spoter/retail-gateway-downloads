import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { PlusIcon, CogIcon, WifiIcon, WifiOffIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';
import { deviceAPI } from '../../services/api';
import { toast } from 'react-hot-toast';

interface Device {
  id: string;
  name: string;
  type: string;
  connection_type: 'sdk' | 'socket';
  sdk_type?: 'python' | 'cpp' | 'csharp';
  status: 'connected' | 'disconnected' | 'error' | 'connecting';
  lane_id?: string;
  last_activity?: string;
  error_count: number;
  socket_config?: {
    type: 'tcp' | 'udp' | 'multicast';
    host: string;
    port: number;
    mode: 'connect' | 'listen';
  };
  sdk_config?: {
    sdk_type: 'python' | 'cpp' | 'csharp';
    module?: string;
    dll_path?: string;
    assembly?: string;
    runtime?: string;
    version?: string;
  };
}

interface Lane {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'error';
  device_count: number;
  devices: Device[];
}

const Devices: React.FC = () => {
  const [selectedLane, setSelectedLane] = useState<string>('all');
  const [showAddDevice, setShowAddDevice] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const queryClient = useQueryClient();

  // Fetch devices and lanes
  const { data: devices = [], isLoading: devicesLoading } = useQuery({
    queryKey: ['devices'],
    queryFn: deviceAPI.getDevices,
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const { data: lanes = [], isLoading: lanesLoading } = useQuery({
    queryKey: ['lanes'],
    queryFn: deviceAPI.getLanes,
    refetchInterval: 5000,
  });

  // Device mutations
  const connectDeviceMutation = useMutation({
    mutationFn: (deviceId: string) => deviceAPI.connectDevice(deviceId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['devices'] });
      toast.success('Device connected successfully');
    },
    onError: (error) => {
      toast.error(`Failed to connect device: ${error.message}`);
    },
  });

  const disconnectDeviceMutation = useMutation({
    mutationFn: (deviceId: string) => deviceAPI.disconnectDevice(deviceId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['devices'] });
      toast.success('Device disconnected successfully');
    },
    onError: (error) => {
      toast.error(`Failed to disconnect device: ${error.message}`);
    },
  });

  const deleteDeviceMutation = useMutation({
    mutationFn: (deviceId: string) => deviceAPI.deleteDevice(deviceId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['devices'] });
      toast.success('Device deleted successfully');
    },
    onError: (error) => {
      toast.error(`Failed to delete device: ${error.message}`);
    },
  });

  // Filter devices by lane
  const filteredDevices = selectedLane === 'all' 
    ? devices 
    : devices.filter(device => device.lane_id === selectedLane);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'text-green-600 bg-green-100';
      case 'connecting': return 'text-yellow-600 bg-yellow-100';
      case 'error': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <WifiIcon className="w-4 h-4" />;
      case 'connecting': return <CogIcon className="w-4 h-4 animate-spin" />;
      case 'error': return <ExclamationTriangleIcon className="w-4 h-4" />;
      default: return <WifiOffIcon className="w-4 h-4" />;
    }
  };

  const handleConnectDevice = (deviceId: string) => {
    connectDeviceMutation.mutate(deviceId);
  };

  const handleDisconnectDevice = (deviceId: string) => {
    disconnectDeviceMutation.mutate(deviceId);
  };

  const handleDeleteDevice = (deviceId: string) => {
    if (window.confirm('Are you sure you want to delete this device?')) {
      deleteDeviceMutation.mutate(deviceId);
    }
  };

  if (devicesLoading || lanesLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Device Management</h1>
          <p className="text-gray-600">Manage and monitor all connected devices</p>
        </div>
        <button
          onClick={() => setShowAddDevice(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          <PlusIcon className="w-4 h-4 mr-2" />
          Add Device
        </button>
      </div>

      {/* Lane Filter */}
      <div className="bg-white shadow rounded-lg p-4">
        <div className="flex items-center space-x-4">
          <label className="text-sm font-medium text-gray-700">Filter by Lane:</label>
          <select
            value={selectedLane}
            onChange={(e) => setSelectedLane(e.target.value)}
            className="border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Lanes</option>
            {lanes.map((lane) => (
              <option key={lane.id} value={lane.id}>
                {lane.name} ({lane.device_count} devices)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Device Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <WifiIcon className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Connected</p>
              <p className="text-lg font-semibold text-gray-900">
                {devices.filter(d => d.status === 'connected').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <WifiOffIcon className="h-6 w-6 text-gray-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Disconnected</p>
              <p className="text-lg font-semibold text-gray-900">
                {devices.filter(d => d.status === 'disconnected').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ExclamationTriangleIcon className="h-6 w-6 text-red-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Errors</p>
              <p className="text-lg font-semibold text-gray-900">
                {devices.filter(d => d.status === 'error').length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <CogIcon className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">Total Devices</p>
              <p className="text-lg font-semibold text-gray-900">{devices.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Devices Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Devices</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Device
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Connection
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Activity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDevices.map((device) => (
                <tr key={device.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{device.name}</div>
                      <div className="text-sm text-gray-500">ID: {device.id}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{device.type}</div>
                    <div className="text-sm text-gray-500">
                      {device.connection_type === 'sdk' && device.sdk_type && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          {device.sdk_type.toUpperCase()} SDK
                        </span>
                      )}
                      {device.connection_type === 'socket' && device.socket_config && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                          {device.socket_config.type.toUpperCase()}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {device.connection_type === 'sdk' && device.sdk_config && (
                      <div>
                        <div>{device.sdk_config.sdk_type}</div>
                        {device.sdk_config.module && <div className="text-gray-500">{device.sdk_config.module}</div>}
                        {device.sdk_config.assembly && <div className="text-gray-500">{device.sdk_config.assembly}</div>}
                      </div>
                    )}
                    {device.connection_type === 'socket' && device.socket_config && (
                      <div>
                        <div>{device.socket_config.host}:{device.socket_config.port}</div>
                        <div className="text-gray-500">{device.socket_config.mode}</div>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(device.status)}`}>
                      {getStatusIcon(device.status)}
                      <span className="ml-1">{device.status}</span>
                    </span>
                    {device.error_count > 0 && (
                      <div className="text-xs text-red-600 mt-1">
                        {device.error_count} error(s)
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {device.last_activity ? new Date(device.last_activity).toLocaleString() : 'Never'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      {device.status === 'disconnected' ? (
                        <button
                          onClick={() => handleConnectDevice(device.id)}
                          className="text-blue-600 hover:text-blue-900"
                          disabled={connectDeviceMutation.isPending}
                        >
                          Connect
                        </button>
                      ) : (
                        <button
                          onClick={() => handleDisconnectDevice(device.id)}
                          className="text-yellow-600 hover:text-yellow-900"
                          disabled={disconnectDeviceMutation.isPending}
                        >
                          Disconnect
                        </button>
                      )}
                      <button
                        onClick={() => setSelectedDevice(device)}
                        className="text-gray-600 hover:text-gray-900"
                      >
                        Configure
                      </button>
                      <button
                        onClick={() => handleDeleteDevice(device.id)}
                        className="text-red-600 hover:text-red-900"
                        disabled={deleteDeviceMutation.isPending}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Device Modal */}
      {showAddDevice && (
        <AddDeviceModal
          onClose={() => setShowAddDevice(false)}
          onSuccess={() => {
            setShowAddDevice(false);
            queryClient.invalidateQueries({ queryKey: ['devices'] });
          }}
        />
      )}

      {/* Configure Device Modal */}
      {selectedDevice && (
        <ConfigureDeviceModal
          device={selectedDevice}
          onClose={() => setSelectedDevice(null)}
          onSuccess={() => {
            setSelectedDevice(null);
            queryClient.invalidateQueries({ queryKey: ['devices'] });
          }}
        />
      )}
    </div>
  );
};

// Add Device Modal Component
const AddDeviceModal: React.FC<{ onClose: () => void; onSuccess: () => void }> = ({ onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    type: '',
    connection_type: 'socket' as 'sdk' | 'socket',
    lane_id: '',
    sdk_config: {
      sdk_type: 'python' as 'python' | 'cpp' | 'csharp',
      module: '',
      assembly: '',
      runtime: 'net6.0',
      version: '',
    },
    socket_config: {
      type: 'tcp' as 'tcp' | 'udp' | 'multicast',
      host: '',
      port: 8080,
      mode: 'connect' as 'connect' | 'listen',
    },
  });

  const addDeviceMutation = useMutation({
    mutationFn: (data: any) => deviceAPI.addDevice(data),
    onSuccess: () => {
      toast.success('Device added successfully');
      onSuccess();
    },
    onError: (error) => {
      toast.error(`Failed to add device: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addDeviceMutation.mutate(formData);
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div className="mt-3">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Add New Device</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Device Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Device Type</label>
              <input
                type="text"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Connection Type</label>
              <select
                value={formData.connection_type}
                onChange={(e) => setFormData({ ...formData, connection_type: e.target.value as 'sdk' | 'socket' })}
                className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="socket">Socket</option>
                <option value="sdk">SDK</option>
              </select>
            </div>

            {formData.connection_type === 'sdk' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">SDK Type</label>
                  <select
                    value={formData.sdk_config.sdk_type}
                    onChange={(e) => setFormData({
                      ...formData,
                      sdk_config: { ...formData.sdk_config, sdk_type: e.target.value as 'python' | 'cpp' | 'csharp' }
                    })}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="python">Python</option>
                    <option value="cpp">C++</option>
                    <option value="csharp">C#</option>
                  </select>
                </div>
                {formData.sdk_config.sdk_type === 'python' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Module Name</label>
                    <input
                      type="text"
                      value={formData.sdk_config.module}
                      onChange={(e) => setFormData({
                        ...formData,
                        sdk_config: { ...formData.sdk_config, module: e.target.value }
                      })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                )}
                {formData.sdk_config.sdk_type === 'csharp' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Assembly</label>
                    <input
                      type="text"
                      value={formData.sdk_config.assembly}
                      onChange={(e) => setFormData({
                        ...formData,
                        sdk_config: { ...formData.sdk_config, assembly: e.target.value }
                      })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                )}
              </div>
            )}

            {formData.connection_type === 'socket' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Socket Type</label>
                  <select
                    value={formData.socket_config.type}
                    onChange={(e) => setFormData({
                      ...formData,
                      socket_config: { ...formData.socket_config, type: e.target.value as 'tcp' | 'udp' | 'multicast' }
                    })}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="tcp">TCP</option>
                    <option value="udp">UDP</option>
                    <option value="multicast">Multicast</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Host</label>
                  <input
                    type="text"
                    value={formData.socket_config.host}
                    onChange={(e) => setFormData({
                      ...formData,
                      socket_config: { ...formData.socket_config, host: e.target.value }
                    })}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Port</label>
                  <input
                    type="number"
                    value={formData.socket_config.port}
                    onChange={(e) => setFormData({
                      ...formData,
                      socket_config: { ...formData.socket_config, port: parseInt(e.target.value) }
                    })}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={addDeviceMutation.isPending}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {addDeviceMutation.isPending ? 'Adding...' : 'Add Device'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// Configure Device Modal Component
const ConfigureDeviceModal: React.FC<{ device: Device; onClose: () => void; onSuccess: () => void }> = ({ device, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: device.name,
    sdk_config: device.sdk_config || {},
    socket_config: device.socket_config || {},
  });

  const updateDeviceMutation = useMutation({
    mutationFn: (data: any) => deviceAPI.updateDevice(device.id, data),
    onSuccess: () => {
      toast.success('Device updated successfully');
      onSuccess();
    },
    onError: (error) => {
      toast.error(`Failed to update device: ${error.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateDeviceMutation.mutate(formData);
  };

  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div className="mt-3">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Configure Device: {device.name}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Device Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            {device.connection_type === 'sdk' && device.sdk_config && (
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">SDK Configuration</h4>
                <div>
                  <label className="block text-sm font-medium text-gray-700">SDK Type</label>
                  <div className="mt-1 text-sm text-gray-900">{device.sdk_config.sdk_type}</div>
                </div>
                {device.sdk_config.module && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Module</label>
                    <input
                      type="text"
                      value={formData.sdk_config.module || ''}
                      onChange={(e) => setFormData({
                        ...formData,
                        sdk_config: { ...formData.sdk_config, module: e.target.value }
                      })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                )}
                {device.sdk_config.assembly && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Assembly</label>
                    <input
                      type="text"
                      value={formData.sdk_config.assembly || ''}
                      onChange={(e) => setFormData({
                        ...formData,
                        sdk_config: { ...formData.sdk_config, assembly: e.target.value }
                      })}
                      className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                )}
              </div>
            )}

            {device.connection_type === 'socket' && device.socket_config && (
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Socket Configuration</h4>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Host</label>
                  <input
                    type="text"
                    value={formData.socket_config.host || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      socket_config: { ...formData.socket_config, host: e.target.value }
                    })}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Port</label>
                  <input
                    type="number"
                    value={formData.socket_config.port || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      socket_config: { ...formData.socket_config, port: parseInt(e.target.value) }
                    })}
                    className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            <div className="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={updateDeviceMutation.isPending}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {updateDeviceMutation.isPending ? 'Updating...' : 'Update Device'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Devices; 