import asyncio
from typing import Dict, Any, Optional
from core.logging_config import get_logger
from core.interfaces import DeviceManagerProtocol
from server.observer import post_event
from sockets.tcp_server import TCPServerProtocol
from sockets.tcp_client import TCPClientProtocol
from sockets.udp_server import UDPServerProtocol
from sockets.udp_client import UDPClientProtocol
from sockets.multicast_socket import MulticastProtocol
from event_manager.event_bus import EventBus
from event_manager.packet_processor import PacketProcessor
from event_manager.socket_listener import SocketListener

class DeviceHandler(DeviceManagerProtocol):
    """Device handler with dependency injection support"""
    
    def __init__(self, event_bus: Optional[EventBus] = None):
        self.device_configs: Dict[str, Dict[str, Any]] = {}
        self.protocols: Dict[str, Any] = {}
        self.directions: Dict[str, str] = {}
        self.registers: Dict[str, str] = {}
        self.socket_types: Dict[str, str] = {}
        self.connection_types: Dict[str, str] = {}
        self.logger = get_logger(__name__)
        
        # Initialize EventBus, PacketProcessor, and SocketListener
        self.evt_bus = event_bus or EventBus()
        self.packet_processor = PacketProcessor(self.evt_bus)
        self.sck_listener = SocketListener(self.evt_bus)

        # Subscribe to the "packet_processed" event
        self.total_packets = 0  # Total number of packets to process (set dynamically)
        self.processed_packets = 0  # Track how many packets have been processed
        self.packet_completion_event = asyncio.Event()  # Event to signal when all packets are processed
        self.evt_bus.subscribe("packet_processed", self.packet_processed_callback)
        
    def add_device(self, device_id: str, device_config: Dict[str, Any], 
                   socket_type: str, connection_type: str) -> None:
        """Add a new device"""
        self.device_configs[device_id] = device_config
        self.protocols[device_id] = None
        self.directions[device_id] = None
        self.registers[device_id] = None
        self.socket_types[device_id] = socket_type
        self.connection_types[device_id] = connection_type
        self.logger.debug(f"Added device {device_id} with type {socket_type}")

    def set_protocol(self, device_id: str, direction: str, register: str) -> None:
        """Set protocol for device"""
        self.directions[device_id] = direction
        self.registers[device_id] = register

        if direction == 'input':
            if self.socket_types[device_id] == 'tcp':
                if self.connection_types[device_id] == 'listen':
                    self.protocols[device_id] = TCPServerProtocol.connections.get('input' + register)
                elif self.connection_types[device_id] == 'connect':
                    self.protocols[device_id] = TCPClientProtocol.connections.get('input' + register)
            elif self.socket_types[device_id] == 'udp':
                if self.connection_types[device_id] == 'listen':
                    self.protocols[device_id] = UDPServerProtocol.connections.get('input' + register)
                elif self.connection_types[device_id] == 'connect':
                    self.protocols[device_id] = UDPClientProtocol.connections.get('input' + register)
            elif self.socket_types[device_id] == 'multicast':
                self.protocols[device_id] = MulticastProtocol.connections.get('input' + register)
        elif direction == 'output':
            if self.socket_types[device_id] == 'tcp':
                if self.connection_types[device_id] == 'listen':
                    self.protocols[device_id] = TCPServerProtocol.connections.get('output' + register)
                elif self.connection_types[device_id] == 'connect':
                    self.protocols[device_id] = TCPClientProtocol.connections.get('output' + register)
            elif self.socket_types[device_id] == 'multicast':
                self.protocols[device_id] = MulticastProtocol.connections.get('output' + register)
        else:
            self.logger.warning(f"Device {self.device_configs[device_id]['name']}: Protocol not set, message not sent.")

        if not self.protocols[device_id]:
            self.logger.warning(f"Device {self.device_configs[device_id]['name']}: Protocol not found for register {register}")

    def on_connection_made(self, device_id: str) -> None:
        """Handle connection made event"""
        device_name = self.device_configs[device_id]['name']
        direction = self.directions[device_id]
        self.logger.info(f"Device {device_name} connected in {direction} mode.")
        
        if self.device_configs[device_id]['type'] == 'handshake':
            result = {
                "id": device_id, 
                'register': self.registers[device_id], 
                'device': device_name, 
                'data': 'start'
            }
            self.sck_listener.receive_packet("input_handshake_register_" + self.registers[device_id], device_id, result)
            
    def handle_heartbeat(self, device_id: str, data: str) -> None:
        """Handle heartbeat data"""
        if self.directions[device_id] == 'input':
            self.process_input_data(device_id, data)
        elif self.directions[device_id] == 'output':
            self.process_output_data(device_id, data)

    def handle_data(self, device_id: str, data: str, client_ip: str) -> None:
        """Handle incoming data"""
        if self.directions[device_id] == 'input':
            self.process_input_data(device_id, data, client_ip)
        elif self.directions[device_id] == 'output':
            self.process_output_data(device_id, data, client_ip)

    def process_input_data(self, device_id: str, data: str, client_ip: str) -> None:
        """Process input data"""
        result = {
            "id": device_id, 
            "ip": client_ip, 
            'register': self.registers[device_id], 
            'device': self.device_configs[device_id]['name'], 
            'data': data
        }
        self.logger.debug(f"Processing input data for device {self.device_configs[device_id]['name']}: {result}")
        
        if self.device_configs[device_id]['type'] == 'handshake':
            self.sck_listener.receive_packet("input_handshake_register_" + self.registers[device_id], device_id, result)
        else:
            self.sck_listener.receive_packet("input_register_" + self.registers[device_id], device_id, result)

    def process_output_data(self, device_id: str, data: str) -> None:
        """Process output data"""
        self.logger.debug(f"Processing output data for device {self.device_configs[device_id]['name']}: {data}")

    def on_connection_lost(self, device_id: str) -> None:
        """Handle connection lost event"""
        device_name = self.device_configs[device_id]['name']
        self.logger.info(f"Device {device_name} disconnected.")

    def send_message(self, device_id: str, data: str, addr: Optional[str] = None) -> None:
        """Send message to device"""
        if self.protocols[device_id]:
            if self.directions[device_id] == 'input':
                self.send_input_message(device_id, data, addr)
            elif self.directions[device_id] == 'output':
                self.send_output_message(device_id, data)
        else:
            device_name = self.device_configs[device_id]['name']
            self.logger.warning(f"Device {device_name}: Protocol not set, data not sent.")

    def send_input_message(self, device_id: str, data: str, addr: Optional[str] = None) -> None:
        """Send input message"""
        device_name = self.device_configs[device_id]['name']
        if self.connection_types[device_id] == 'connect':
            self.protocols[device_id].send_message(data, addr)
            self.logger.debug(f"Device {device_name} (input): Message sent: {data}")
        elif self.connection_types[device_id] == 'listen':
            self.protocols[device_id].send_message(data, addr)
            self.logger.debug(f"Device {device_name} (input): Message sent for listen connection: {data}")

    def send_output_message(self, device_id: str, data: str) -> None:
        """Send output message"""
        device_name = self.device_configs[device_id]['name']
        if self.connection_types[device_id] == 'connect':
            self.protocols[device_id].send_message(data)
            self.logger.debug(f"Device {device_name} (output): Message sent: {data}")
        elif self.connection_types[device_id] == 'listen':
            self.protocols[device_id].send_message(data)
            self.logger.debug(f"Device {device_name} (output): Message sent for listen connection: {data}")
            
    def packet_processed_callback(self, data: Dict[str, Any]) -> None:
        """Callback function triggered when a packet is processed"""
        self.processed_packets += 1
        self.logger.debug(f"Processed packet from {data['device_id']}: {data['packet']} (Total processed: {self.processed_packets}/{self.total_packets})")

        # Check if all packets have been processed
        if self.processed_packets == self.total_packets:
            self.packet_completion_event.set()  # Signal that all packets are processed

    def get_device_info(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific device"""
        if device_id not in self.device_configs:
            return None
        
        return {
            "id": device_id,
            "config": self.device_configs[device_id],
            "direction": self.directions.get(device_id),
            "register": self.registers.get(device_id),
            "socket_type": self.socket_types.get(device_id),
            "connection_type": self.connection_types.get(device_id),
            "protocol_active": self.protocols.get(device_id) is not None
        }

    def get_all_devices(self) -> Dict[str, Dict[str, Any]]:
        """Get information about all devices"""
        return {
            device_id: self.get_device_info(device_id)
            for device_id in self.device_configs.keys()
        }

# Legacy singleton instance for backward compatibility
device_manager = DeviceHandler()


