"""
Handshake-based POS device implementations.
"""

from .infogenesis_handshake import InfogenesisHandshake

__all__ = [
    'InfogenesisHandshake'
] 