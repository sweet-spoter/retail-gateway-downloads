import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { Device } from '../services/api';

interface DeviceState {
  devices: Device[];
  isLoading: boolean;
  error: string | null;
}

interface DeviceContextType extends DeviceState {
  setDevices: (devices: Device[]) => void;
  addDevice: (device: Device) => void;
  updateDevice: (id: string, device: Partial<Device>) => void;
  removeDevice: (id: string) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

type DeviceAction =
  | { type: 'SET_DEVICES'; payload: Device[] }
  | { type: 'ADD_DEVICE'; payload: Device }
  | { type: 'UPDATE_DEVICE'; payload: { id: string; device: Partial<Device> } }
  | { type: 'REMOVE_DEVICE'; payload: string }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null };

const initialState: DeviceState = {
  devices: [],
  isLoading: false,
  error: null,
};

const deviceReducer = (state: DeviceState, action: DeviceAction): DeviceState => {
  switch (action.type) {
    case 'SET_DEVICES':
      return {
        ...state,
        devices: action.payload,
        error: null,
      };
    case 'ADD_DEVICE':
      return {
        ...state,
        devices: [...state.devices, action.payload],
        error: null,
      };
    case 'UPDATE_DEVICE':
      return {
        ...state,
        devices: state.devices.map(device =>
          device.id === action.payload.id
            ? { ...device, ...action.payload.device }
            : device
        ),
        error: null,
      };
    case 'REMOVE_DEVICE':
      return {
        ...state,
        devices: state.devices.filter(device => device.id !== action.payload),
        error: null,
      };
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload,
      };
    case 'SET_ERROR':
      return {
        ...state,
        error: action.payload,
      };
    default:
      return state;
  }
};

const DeviceContext = createContext<DeviceContextType | undefined>(undefined);

export const DeviceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(deviceReducer, initialState);

  const setDevices = (devices: Device[]) => {
    dispatch({ type: 'SET_DEVICES', payload: devices });
  };

  const addDevice = (device: Device) => {
    dispatch({ type: 'ADD_DEVICE', payload: device });
  };

  const updateDevice = (id: string, device: Partial<Device>) => {
    dispatch({ type: 'UPDATE_DEVICE', payload: { id, device } });
  };

  const removeDevice = (id: string) => {
    dispatch({ type: 'REMOVE_DEVICE', payload: id });
  };

  const setLoading = (loading: boolean) => {
    dispatch({ type: 'SET_LOADING', payload: loading });
  };

  const setError = (error: string | null) => {
    dispatch({ type: 'SET_ERROR', payload: error });
  };

  const value: DeviceContextType = {
    ...state,
    setDevices,
    addDevice,
    updateDevice,
    removeDevice,
    setLoading,
    setError,
  };

  return <DeviceContext.Provider value={value}>{children}</DeviceContext.Provider>;
};

export const useDevice = (): DeviceContextType => {
  const context = useContext(DeviceContext);
  if (context === undefined) {
    throw new Error('useDevice must be used within a DeviceProvider');
  }
  return context;
}; 