from pydantic import BaseModel, Field, validator, model_validator
from typing import List, Optional, Dict, Any, Union
from enum import Enum
from datetime import datetime
from core.exceptions import ValidationError

class ConnectionType(str, Enum):
    """Device connection types"""
    SDK = "sdk"
    SOCKET = "socket"

class SDKType(str, Enum):
    """SDK types"""
    PYTHON = "python"
    CPP = "cpp"
    CSHARP = "csharp"

class SocketType(str, Enum):
    """Socket types"""
    TCP = "tcp"
    UDP = "udp"
    MULTICAST = "multicast"

class ConnectionMode(str, Enum):
    """Connection modes"""
    LISTEN = "listen"
    CONNECT = "connect"

class LicenseStatus(str, Enum):
    """License status"""
    ACTIVE = "active"
    EXPIRED = "expired"
    GRACE_PERIOD = "grace_period"
    DISABLED = "disabled"

class LicenseType(str, Enum):
    """License types"""
    TRIAL = "trial"
    BASIC = "basic"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"

class SDKConfig(BaseModel):
    """Configuration for SDK-based devices"""
    sdk_type: SDKType = Field(..., description="SDK type (python, cpp, csharp)")
    module: Optional[str] = Field(None, description="Python module name")
    version: Optional[str] = Field(None, description="SDK version")
    dll_path: Optional[str] = Field(None, description="C++ DLL path")
    assembly: Optional[str] = Field(None, description="C# assembly name")
    runtime: Optional[str] = Field(None, description=".NET runtime version")
    connection_params: Optional[Dict[str, Any]] = Field(None, description="Connection parameters")

    @model_validator(mode='after')
    def validate_sdk_config(self):
        """Validate SDK configuration after model creation"""
        if self.sdk_type == SDKType.PYTHON:
            if not self.module:
                raise ValidationError("Python SDK requires module name")
        elif self.sdk_type == SDKType.CPP:
            if not self.dll_path:
                raise ValidationError("C++ SDK requires DLL path")
        elif self.sdk_type == SDKType.CSHARP:
            if not self.assembly:
                raise ValidationError("C# SDK requires assembly name")
        return self

class SocketConfig(BaseModel):
    """Configuration for socket-based devices"""
    type: SocketType = Field(..., description="Socket type (tcp, udp, multicast)")
    mode: ConnectionMode = Field(..., description="Connection mode (listen, connect)")
    host: str = Field(..., description="Host address")
    port: int = Field(..., ge=1, le=65535, description="Port number")
    group: Optional[str] = Field(None, description="Multicast group address")
    interface: Optional[str] = Field(None, description="Network interface")
    protocol: Optional[str] = Field("raw", description="Protocol type")
    timeout: Optional[int] = Field(30, description="Connection timeout in seconds")

    @validator('group')
    def validate_multicast_group(cls, v, values):
        if values.get('type') == SocketType.MULTICAST and not v:
            raise ValidationError("Multicast socket requires group address")
        return v

class DeviceConfig(BaseModel):
    """Configuration for a device in a lane"""
    device_type: str = Field(..., description="Device type identifier")
    connection_type: ConnectionType = Field(..., description="Connection type (sdk or socket)")
    sdk_config: Optional[SDKConfig] = Field(None, description="SDK configuration")
    socket_config: Optional[SocketConfig] = Field(None, description="Socket configuration")

    @validator('sdk_config', 'socket_config')
    def validate_connection_config(cls, v, values):
        connection_type = values.get('connection_type')
        if connection_type == ConnectionType.SDK and not v:
            raise ValidationError("SDK connection requires sdk_config")
        elif connection_type == ConnectionType.SOCKET and not v:
            raise ValidationError("Socket connection requires socket_config")
        return v

class SessionizerConfig(BaseModel):
    """Configuration for session management"""
    enabled: bool = Field(True, description="Enable session management")
    timeout: int = Field(300, ge=30, le=3600, description="Session timeout in seconds")
    expected_sequence: Optional[List[str]] = Field(None, description="Expected device sequence")
    correlation_window: int = Field(60, ge=10, le=300, description="Correlation window in seconds")
    retry_attempts: int = Field(3, ge=0, le=10, description="Retry attempts for failed sessions")
    grace_period: int = Field(30, ge=0, le=300, description="Grace period in seconds")

class OutputDestination(BaseModel):
    """Configuration for output destinations"""
    name: str = Field(..., description="Output destination name")
    type: str = Field(..., description="Output type (tcp, udp, api, file)")
    host: Optional[str] = Field(None, description="Host address for network outputs")
    port: Optional[int] = Field(None, description="Port for network outputs")
    endpoint: Optional[str] = Field(None, description="API endpoint")
    format: str = Field("json", description="Output format")
    filter: Optional[str] = Field(None, description="Event filter")
    retention_days: Optional[int] = Field(90, description="Retention period in days")

class LiveEventsConfig(BaseModel):
    """Configuration for live events output"""
    enabled: bool = Field(True, description="Enable live events")
    destinations: List[str] = Field(["web_ui"], description="Live event destinations")
    format: str = Field("real_time", description="Live event format")
    filter: str = Field("all_events", description="Event filter")

class TransactionBundleConfig(BaseModel):
    """Configuration for transaction bundles"""
    enabled: bool = Field(True, description="Enable transaction bundles")
    destinations: List[str] = Field(["analytics_api"], description="Bundle destinations")
    format: str = Field("transaction_bundle", description="Bundle format")
    retention_days: int = Field(90, description="Retention period in days")

class OutputsConfig(BaseModel):
    """Configuration for lane outputs"""
    live_events: LiveEventsConfig = Field(default_factory=LiveEventsConfig)
    transaction_bundles: TransactionBundleConfig = Field(default_factory=TransactionBundleConfig)
    simple_outputs: Optional[List[OutputDestination]] = Field(None, description="Simple output destinations")

class LicenseConfig(BaseModel):
    """Configuration for lane licensing"""
    license_required: bool = Field(True, description="License required for this lane")
    license_status: LicenseStatus = Field(LicenseStatus.ACTIVE, description="Current license status")
    activation_date: Optional[datetime] = Field(None, description="License activation date")
    expiration_date: Optional[datetime] = Field(None, description="License expiration date")
    grace_period_until: Optional[datetime] = Field(None, description="Grace period end date")

class LaneConfig(BaseModel):
    """Configuration for a lane"""
    lane_id: str = Field(..., description="Unique lane identifier")
    register_id: str = Field(..., description="Register identifier")
    cashier_id: Optional[str] = Field(None, description="Cashier identifier")
    location: Optional[str] = Field(None, description="Location identifier")
    client: Optional[str] = Field(None, description="Client identifier")
    devices: Dict[str, DeviceConfig] = Field(..., description="Devices in this lane")
    sessionizer: SessionizerConfig = Field(default_factory=SessionizerConfig)
    outputs: OutputsConfig = Field(default_factory=OutputsConfig)
    license: LicenseConfig = Field(default_factory=LicenseConfig)

    @validator('devices')
    def validate_devices(cls, v):
        if not v:
            raise ValidationError("At least one device must be configured")
        return v

    def get_device_by_type(self, device_type: str) -> Optional[DeviceConfig]:
        """Get device configuration by type"""
        return self.devices.get(device_type)

    def has_sdk_device(self) -> bool:
        """Check if lane has any SDK devices"""
        return any(device.connection_type == ConnectionType.SDK for device in self.devices.values())

    def has_socket_device(self) -> bool:
        """Check if lane has any socket devices"""
        return any(device.connection_type == ConnectionType.SOCKET for device in self.devices.values())

class GatewayConfig(BaseModel):
    """Gateway-level configuration"""
    id: str = Field(..., description="Gateway identifier")
    version: str = Field(..., description="Gateway version")
    location: str = Field(..., description="Gateway location")
    client: str = Field(..., description="Client identifier")

class LicensingConfig(BaseModel):
    """Global licensing configuration"""
    license_key: str = Field(..., description="Encrypted license key")
    license_type: LicenseType = Field(..., description="License type")
    max_lanes: int = Field(..., ge=1, description="Maximum number of lanes")
    max_devices_per_lane: int = Field(5, ge=1, le=20, description="Maximum devices per lane")
    features: Dict[str, bool] = Field(default_factory=dict, description="Feature flags")
    grace_period_days: int = Field(7, ge=0, le=30, description="Grace period in days")
    auto_renewal: bool = Field(True, description="Enable auto-renewal")
    billing_cycle: str = Field("monthly", description="Billing cycle")

class AnalyticsConfig(BaseModel):
    """Analytics configuration"""
    api_endpoint: str = Field(..., description="Analytics API endpoint")
    api_key: str = Field(..., description="API key")
    batch_size: int = Field(100, ge=1, le=1000, description="Batch size for API calls")
    retry_attempts: int = Field(3, ge=0, le=10, description="Retry attempts")

class MonitoringConfig(BaseModel):
    """Monitoring configuration"""
    health_check_interval: int = Field(30, ge=10, le=300, description="Health check interval in seconds")
    metrics_collection: bool = Field(True, description="Enable metrics collection")
    log_level: str = Field("INFO", description="Logging level")

class EnhancedAppConfig(BaseModel):
    """Enhanced application configuration with lane-based architecture"""
    gateway: GatewayConfig = Field(..., description="Gateway configuration")
    licensing: LicensingConfig = Field(..., description="Licensing configuration")
    lanes: Dict[str, LaneConfig] = Field(..., description="Lane configurations")
    analytics: AnalyticsConfig = Field(..., description="Analytics configuration")
    monitoring: MonitoringConfig = Field(default_factory=MonitoringConfig, description="Monitoring configuration")

    @validator('lanes')
    def validate_lanes(cls, v, values):
        licensing = values.get('licensing')
        if licensing and len(v) > licensing.max_lanes:
            raise ValidationError(f"Number of lanes ({len(v)}) exceeds license limit ({licensing.max_lanes})")
        
        for lane_id, lane_config in v.items():
            if len(lane_config.devices) > licensing.max_devices_per_lane:
                raise ValidationError(f"Lane {lane_id} has {len(lane_config.devices)} devices, exceeds limit of {licensing.max_devices_per_lane}")
        
        return v

    def get_lane_by_id(self, lane_id: str) -> Optional[LaneConfig]:
        """Get lane configuration by ID"""
        return self.lanes.get(lane_id)

    def get_lanes_by_client(self, client: str) -> List[LaneConfig]:
        """Get all lanes for a specific client"""
        return [lane for lane in self.lanes.values() if lane.client == client]

    def get_active_lanes(self) -> List[LaneConfig]:
        """Get all active lanes (not expired or disabled)"""
        return [lane for lane in self.lanes.values() 
                if lane.license.license_status in [LicenseStatus.ACTIVE, LicenseStatus.GRACE_PERIOD]]

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        return self.dict()

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EnhancedAppConfig':
        """Create configuration from dictionary"""
        return cls(**data) 