from dependency_injector import containers, providers
from typing import Dict, Any
from core.logging_config import get_logger
from core.interfaces import (
    DeviceManagerProtocol, 
    EventBusProtocol, 
    ConfigurationProvider,
    ConnectionManagerProtocol
)
from models.device_config import AppConfig
from config.config import load_config, save_config

class Container(containers.DeclarativeContainer):
    """Dependency injection container"""
    
    # Configuration
    config_data = providers.Singleton(load_config)
    app_config = providers.Singleton(AppConfig.from_dict, config_data)
    
    # Logging
    logger = providers.Singleton(get_logger, "gateway_service")
    
    # Core services
    event_bus = providers.Singleton(
        lambda: __import__('event_manager.event_bus', fromlist=['EventBus']).EventBus()
    )
    
    device_manager = providers.Singleton(
        lambda: __import__('sockets.device_handler', fromlist=['DeviceHandler']).DeviceHandler()
    )
    
    # Connection manager will be provided by the service layer
    connection_manager = providers.Singleton(
        lambda: __import__('services.connection_manager', fromlist=['ConnectionManager']).ConnectionManager(
            app_config=app_config,
            event_bus=event_bus,
            device_manager=device_manager
        )
    )
    
    # Configuration provider
    config_provider = providers.Singleton(
        lambda: ConfigurationProviderImpl(
            config_data=config_data,
            save_config_func=save_config
        )
    )

class ConfigurationProviderImpl:
    """Implementation of configuration provider"""
    
    def __init__(self, config_data: Dict[str, Any], save_config_func):
        self._config_data = config_data
        self._save_config_func = save_config_func
        self.logger = get_logger(__name__)
    
    def get_config(self) -> Dict[str, Any]:
        """Get current configuration"""
        return self._config_data
    
    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration"""
        try:
            self._save_config_func(config)
            self._config_data = config
            self.logger.info("Configuration saved successfully")
        except Exception as e:
            self.logger.error(f"Failed to save configuration: {e}")
            raise
    
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """Validate configuration"""
        try:
            AppConfig.from_dict(config)
            return True
        except Exception as e:
            self.logger.error(f"Configuration validation failed: {e}")
            return False

# Global container instance
container = Container()

def get_container() -> Container:
    """Get the global container instance"""
    return container

def wire_container():
    """Wire the container dependencies"""
    container.wire(modules=[
        'services.service_manager',
        'services.application_service',
        'services.connection_manager',
        'sockets.device_handler',
        'event_manager.event_bus'
    ]) 