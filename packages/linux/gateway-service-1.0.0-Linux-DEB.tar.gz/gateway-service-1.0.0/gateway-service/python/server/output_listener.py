import asyncio

from sockets.device_manager import device_manager
from .observer import subscribe

async def output_callback_factory(data):
   # output_sockets[data['register']].write(data['result'])
    # protocol = TCPServerProtocol.connections.get('output'+data['register'])
    # if protocol:
    #     print(f"Active connection for identifier: {'output'+data['register']} and {data['data']}")
    #     protocol.send_message(data['data'])
    # else:
    #     print(f"No active connection for identifier: {'output'+data['register']}")
     device_manager.send_message(data['id'], data['data'], data['addr'])

def setup_output_event_handler(register):
    subscribe("output_register_" + register, output_callback_factory)
    