"""
Enhanced configuration loader for lane-based architecture with streaming pipeline integration.
"""

import json
import os
from typing import Dict, Any, List, Optional
from formatting.factory.pos_factory import POSFactory

class EnhancedConfigLoader:
    """
    Loads and manages enhanced lane-based configuration with streaming pipeline integration.
    """
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path or os.path.join('config', 'enhanced_config.json')
        self.config = None
        self.lanes = {}
        self.streaming_devices = {}
        self.pos_interfaces = {}
    
    def load_config(self) -> Dict[str, Any]:
        """
        Load enhanced configuration from the specified path.
        
        Returns:
            Dict: Loaded configuration
        """
        try:
            with open(self.config_path, 'r') as f:
                self.config = json.load(f)
            
            # Extract lanes
            self.lanes = self.config.get('lanes', {})
            
            return self.config
            
        except FileNotFoundError:
            raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in configuration file: {e}")
    
    def get_gateway_info(self) -> Dict[str, Any]:
        """
        Get gateway information from configuration.
        
        Returns:
            Dict: Gateway information
        """
        return self.config.get('gateway', {})
    
    def get_licensing_info(self) -> Dict[str, Any]:
        """
        Get licensing information from configuration.
        
        Returns:
            Dict: Licensing information
        """
        return self.config.get('licensing', {})
    
    def get_lanes(self) -> Dict[str, Any]:
        """
        Get all lanes from configuration.
        
        Returns:
            Dict: All lanes
        """
        return self.lanes
    
    def get_lane(self, lane_id: str) -> Optional[Dict[str, Any]]:
        """
        Get specific lane by ID.
        
        Args:
            lane_id: Lane identifier
            
        Returns:
            Dict: Lane configuration or None if not found
        """
        return self.lanes.get(lane_id)
    
    def get_lane_devices(self, lane_id: str) -> Dict[str, Any]:
        """
        Get devices for a specific lane.
        
        Args:
            lane_id: Lane identifier
            
        Returns:
            Dict: Devices configuration
        """
        lane = self.get_lane(lane_id)
        if lane:
            return lane.get('devices', {})
        return {}
    
    def get_lane_outputs(self, lane_id: str) -> Dict[str, Any]:
        """
        Get outputs for a specific lane.
        
        Args:
            lane_id: Lane identifier
            
        Returns:
            Dict: Outputs configuration
        """
        lane = self.get_lane(lane_id)
        if lane:
            return lane.get('outputs', {})
        return {}
    
    def create_streaming_devices_from_lanes(self) -> Dict[str, Any]:
        """
        Create streaming pipeline devices from lane-based configuration.
        
        Returns:
            Dict: Dictionary of streaming devices
        """
        self.streaming_devices = {}
        
        for lane_id, lane_config in self.lanes.items():
            devices = lane_config.get('devices', {})
            
            for device_name, device_config in devices.items():
                # Check if device has streaming configuration
                streaming_config = device_config.get('streaming_config')
                if streaming_config and streaming_config.get('enabled', False):
                    device_key = f"{lane_id}_{device_name}"
                    
                    # Create streaming device config
                    streaming_device_config = {
                        "device_type": streaming_config.get('device_type'),
                        "handshake_required": streaming_config.get('handshake_required', False),
                        "protocol": streaming_config.get('protocol'),
                        "connection_type": streaming_config.get('connection_type'),
                        "ip_connection": streaming_config.get('ip_connection'),
                        "port_connection": streaming_config.get('port_connection'),
                        "output_mapping": f"{lane_id}_{device_name}",
                        "tcp_pipeline_host": streaming_config.get('tcp_pipeline_host'),
                        "tcp_pipeline_port": streaming_config.get('tcp_pipeline_port'),
                        "transaction_timeout": streaming_config.get('transaction_timeout', 30),
                        "streaming_config": streaming_config.get('streaming_config', {})
                    }
                    
                    # Add device-specific configurations
                    if streaming_config.get('device_type') == 'infogenesis':
                        streaming_device_config.update({
                            "terminal_id": streaming_config.get('terminal_id'),
                            "terminal_ip": streaming_config.get('terminal_ip'),
                            "handshake_timeout": streaming_config.get('handshake_timeout', 10),
                            "handshake_retries": streaming_config.get('handshake_retries', 3),
                            "terminal_output_mapping": streaming_config.get('terminal_output_mapping', {})
                        })
                    elif streaming_config.get('device_type') == 'verifone':
                        streaming_device_config.update({
                            "terminal_id": streaming_config.get('terminal_id'),
                            "merchant_id": streaming_config.get('merchant_id')
                        })
                    
                    self.streaming_devices[device_key] = streaming_device_config
        
        return self.streaming_devices
    
    def create_pos_interfaces_from_lanes(self) -> Dict[str, Any]:
        """
        Create POS interface instances from lane-based configuration.
        
        Returns:
            Dict: Dictionary of POS interface instances
        """
        self.pos_interfaces = {}
        
        for lane_id, lane_config in self.lanes.items():
            devices = lane_config.get('devices', {})
            
            for device_name, device_config in devices.items():
                streaming_config = device_config.get('streaming_config')
                if streaming_config and streaming_config.get('enabled', False):
                    device_key = f"{lane_id}_{device_name}"
                    
                    try:
                        # Create streaming device config for POS factory
                        pos_config = {
                            "device_type": streaming_config.get('device_type'),
                            "handshake_required": streaming_config.get('handshake_required', False),
                            "protocol": streaming_config.get('protocol'),
                            "connection_type": streaming_config.get('connection_type'),
                            "ip_connection": streaming_config.get('ip_connection'),
                            "port_connection": streaming_config.get('port_connection'),
                            "output_mapping": f"{lane_id}_{device_name}",
                            "tcp_pipeline_host": streaming_config.get('tcp_pipeline_host'),
                            "tcp_pipeline_port": streaming_config.get('tcp_pipeline_port'),
                            "transaction_timeout": streaming_config.get('transaction_timeout', 30),
                            "streaming_config": streaming_config.get('streaming_config', {})
                        }
                        
                        # Add device-specific configurations
                        if streaming_config.get('device_type') == 'infogenesis':
                            pos_config.update({
                                "terminal_id": streaming_config.get('terminal_id'),
                                "terminal_ip": streaming_config.get('terminal_ip'),
                                "handshake_timeout": streaming_config.get('handshake_timeout', 10),
                                "handshake_retries": streaming_config.get('handshake_retries', 3),
                                "terminal_output_mapping": streaming_config.get('terminal_output_mapping', {})
                            })
                        elif streaming_config.get('device_type') == 'verifone':
                            pos_config.update({
                                "terminal_id": streaming_config.get('terminal_id'),
                                "merchant_id": streaming_config.get('merchant_id')
                            })
                        
                        # Validate configuration
                        validation = POSFactory.validate_config(pos_config)
                        if not validation["valid"]:
                            print(f"Configuration validation failed for {device_key}:")
                            for error in validation["errors"]:
                                print(f"  Error: {error}")
                            continue
                        
                        # Create interface
                        interface = POSFactory.create_pos_interface(pos_config)
                        if interface:
                            self.pos_interfaces[device_key] = interface
                            print(f"Created POS interface: {device_key}")
                        else:
                            print(f"Failed to create POS interface: {device_key}")
                            
                    except Exception as e:
                        print(f"Error creating POS interface {device_key}: {e}")
        
        return self.pos_interfaces
    
    def get_streaming_pipeline_config(self) -> Dict[str, Any]:
        """
        Get global streaming pipeline configuration.
        
        Returns:
            Dict: Streaming pipeline configuration
        """
        return self.config.get('streaming_pipeline', {})
    
    def get_analytics_config(self) -> Dict[str, Any]:
        """
        Get analytics configuration.
        
        Returns:
            Dict: Analytics configuration
        """
        return self.config.get('analytics', {})
    
    def get_monitoring_config(self) -> Dict[str, Any]:
        """
        Get monitoring configuration.
        
        Returns:
            Dict: Monitoring configuration
        """
        return self.config.get('monitoring', {})
    
    def validate_lane_configuration(self, lane_id: str) -> Dict[str, Any]:
        """
        Validate lane configuration.
        
        Args:
            lane_id: Lane identifier
            
        Returns:
            Dict: Validation result
        """
        lane = self.get_lane(lane_id)
        if not lane:
            return {"valid": False, "errors": [f"Lane {lane_id} not found"]}
        
        errors = []
        
        # Check required fields
        required_fields = ['lane_id', 'register_id', 'cashier_id', 'location', 'client']
        for field in required_fields:
            if field not in lane:
                errors.append(f"Missing required field: {field}")
        
        # Check devices
        devices = lane.get('devices', {})
        if not devices:
            errors.append("No devices configured")
        
        # Check outputs
        outputs = lane.get('outputs', {})
        if not outputs:
            errors.append("No outputs configured")
        
        # Check streaming pipeline configuration
        streaming_outputs = outputs.get('streaming_pipeline', {})
        if streaming_outputs.get('enabled', False):
            required_streaming_fields = ['tcp_pipeline_host', 'tcp_pipeline_port']
            for field in required_streaming_fields:
                if field not in streaming_outputs:
                    errors.append(f"Missing streaming pipeline field: {field}")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "lane_id": lane_id
        }
    
    def get_lane_summary(self) -> List[Dict[str, Any]]:
        """
        Get summary of all lanes.
        
        Returns:
            List: Lane summaries
        """
        summaries = []
        
        for lane_id, lane_config in self.lanes.items():
            devices = lane_config.get('devices', {})
            outputs = lane_config.get('outputs', {})
            
            # Count streaming devices
            streaming_devices = 0
            for device_config in devices.values():
                if device_config.get('streaming_config', {}).get('enabled', False):
                    streaming_devices += 1
            
            summary = {
                "lane_id": lane_id,
                "register_id": lane_config.get('register_id'),
                "cashier_id": lane_config.get('cashier_id'),
                "location": lane_config.get('location'),
                "client": lane_config.get('client'),
                "license_status": lane_config.get('license_status'),
                "device_count": len(devices),
                "streaming_devices": streaming_devices,
                "output_count": len(outputs),
                "streaming_enabled": outputs.get('streaming_pipeline', {}).get('enabled', False)
            }
            
            summaries.append(summary)
        
        return summaries
    
    def save_enhanced_config(self, output_path: str = None):
        """
        Save enhanced configuration to a file.
        
        Args:
            output_path: Path to save the configuration
        """
        if output_path is None:
            output_path = self.config_path
        
        with open(output_path, 'w') as f:
            json.dump(self.config, f, indent=2)
        
        print(f"Enhanced configuration saved to: {output_path}")

def load_enhanced_config(config_path: str = None) -> EnhancedConfigLoader:
    """
    Convenience function to load enhanced configuration.
    
    Args:
        config_path: Path to configuration file
        
    Returns:
        EnhancedConfigLoader: Loaded configuration
    """
    loader = EnhancedConfigLoader(config_path)
    loader.load_config()
    return loader 