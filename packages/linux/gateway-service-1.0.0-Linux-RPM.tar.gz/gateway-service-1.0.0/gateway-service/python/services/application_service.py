import asyncio
from typing import Optional
from core.logging_config import get_logger
from core.exceptions import ServiceError
from core.container import get_container
from core.health import HealthChecker
from core.metrics import get_metrics_registry, get_system_metrics, get_connection_metrics
from services.connection_manager import ConnectionManager
from models.device_config import AppConfig

class ApplicationService:
    """Core application service that manages business logic"""
    
    def __init__(self):
        self.container = get_container()
        self.connection_manager: Optional[ConnectionManager] = None
        self.logger = get_logger(__name__)
        self.running = False
        self.healthy = False
        self.startup_time = None
        
        # Initialize monitoring components
        self.health_checker = HealthChecker()
        self.metrics_registry = get_metrics_registry()
        self.system_metrics = get_system_metrics()
        self.connection_metrics = get_connection_metrics()
    
    async def start(self):
        """Start the application service"""
        try:
            self.logger.info("Starting application service")
            
            # Get configuration
            config = self.container.app_config()
            self.logger.info(f"Loaded configuration with {len(config.input_configs)} input and {len(config.output_configs)} output configs")
            
            # Initialize connection manager
            self.connection_manager = ConnectionManager(
                config=config,
                event_bus=self.container.event_bus(),
                device_manager=self.container.device_manager()
            )
            
            # Start all connections
            await self.connection_manager.start_all_connections()
            
            self.running = True
            self.healthy = True
            self.startup_time = asyncio.get_event_loop().time()
            
            # Update metrics
            self.system_metrics["uptime_seconds"].set(0)
            self.system_metrics["startup_time"].set(self.startup_time)
            
            self.logger.info("Application service started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start application service: {e}")
            self.healthy = False
            raise ServiceError(f"Application service startup failed: {e}")
    
    async def shutdown(self):
        """Gracefully shutdown the application service"""
        try:
            self.logger.info("Shutting down application service")
            
            self.running = False
            self.healthy = False
            
            if self.connection_manager:
                await self.connection_manager.shutdown_all_connections()
            
            self.logger.info("Application service shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during application service shutdown: {e}")
            raise
    
    async def restart(self):
        """Restart the application service"""
        try:
            self.logger.info("Restarting application service")
            
            await self.shutdown()
            await asyncio.sleep(1)  # Brief pause before restart
            await self.start()
            
            self.logger.info("Application service restarted successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to restart application service: {e}")
            raise ServiceError(f"Application service restart failed: {e}")
    
    def is_healthy(self) -> bool:
        """Check if the application service is healthy"""
        if not self.running:
            return False
        
        if not self.connection_manager:
            return False
        
        # Check connection health
        connection_status = self.connection_manager.get_connection_status()
        active_connections = sum(1 for status in connection_status.values() if status)
        
        # Consider healthy if at least one connection is active
        self.healthy = active_connections > 0
        
        if not self.healthy:
            self.logger.warning(f"Service unhealthy: {active_connections} active connections")
        
        return self.healthy
    
    def get_status(self) -> dict:
        """Get current service status"""
        return {
            "running": self.running,
            "healthy": self.healthy,
            "startup_time": self.startup_time,
            "uptime": asyncio.get_event_loop().time() - self.startup_time if self.startup_time else 0,
            "connections": self.connection_manager.get_connection_status() if self.connection_manager else {}
        }
    
    async def get_configuration(self) -> AppConfig:
        """Get current configuration"""
        return self.container.app_config()
    
    async def update_configuration(self, new_config: dict) -> bool:
        """Update configuration and restart if needed"""
        try:
            self.logger.info("Updating configuration")
            
            # Validate new configuration
            config_provider = self.container.config_provider()
            if not config_provider.validate_config(new_config):
                raise ServiceError("Invalid configuration")
            
            # Save new configuration
            config_provider.save_config(new_config)
            
            # Restart service to apply new configuration
            await self.restart()
            
            self.logger.info("Configuration updated successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to update configuration: {e}")
            return False 