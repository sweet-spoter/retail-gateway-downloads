import uuid
import threading
from typing import Optional

class CorrelationManager:
    """Manages correlation IDs for request tracing"""
    
    def __init__(self):
        self._local = threading.local()
    
    def get_correlation_id(self) -> str:
        """Get the current correlation ID"""
        if not hasattr(self._local, 'correlation_id'):
            self._local.correlation_id = str(uuid.uuid4())
        return self._local.correlation_id
    
    def set_correlation_id(self, correlation_id: str) -> None:
        """Set the current correlation ID"""
        self._local.correlation_id = correlation_id
    
    def generate_correlation_id(self) -> str:
        """Generate a new correlation ID and set it as current"""
        correlation_id = str(uuid.uuid4())
        self.set_correlation_id(correlation_id)
        return correlation_id
    
    def clear_correlation_id(self) -> None:
        """Clear the current correlation ID"""
        if hasattr(self._local, 'correlation_id'):
            delattr(self._local, 'correlation_id')

# Global correlation manager instance
correlation_manager = CorrelationManager()

def get_correlation_id() -> str:
    """Get the current correlation ID"""
    return correlation_manager.get_correlation_id()

def set_correlation_id(correlation_id: str) -> None:
    """Set the current correlation ID"""
    correlation_manager.set_correlation_id(correlation_id)

def generate_correlation_id() -> str:
    """Generate a new correlation ID and set it as current"""
    return correlation_manager.generate_correlation_id()

def clear_correlation_id() -> None:
    """Clear the current correlation ID"""
    correlation_manager.clear_correlation_id() 