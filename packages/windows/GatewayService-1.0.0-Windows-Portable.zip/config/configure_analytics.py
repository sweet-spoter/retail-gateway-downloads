#!/usr/bin/env python3
"""
Analytics Configuration Script

This script helps configure the analytics client in the Gateway Service.
It allows enabling/disabling analytics and updating the configuration.
"""

import json
import sys
import argparse
from pathlib import Path

def load_config():
    """Load the current analytics configuration."""
    config_file = Path("config/analytics_config.json")
    
    if config_file.exists():
        with open(config_file, 'r') as f:
            return json.load(f)
    else:
        # Return default configuration
        return {
            "analytics_api": {
                "enabled": False,
                "base_url": "https://analytics.example.com/api/v1",
                "api_key": "your_api_key_here",
                "auth_token": None,
                "timeout": 30,
                "max_retries": 3,
                "retry_delay": 1.0,
                "batch_size": 100,
                "batch_timeout": 5.0,
                "rate_limit": 1000,
                "queue_file": "analytics_queue.json",
                "enable_offline_queue": True
            },
            "endpoints": {
                "transactions": {
                    "enabled": True,
                    "priority": 2,
                    "batch_size": 50
                },
                "metrics": {
                    "enabled": True,
                    "priority": 1,
                    "batch_size": 100
                },
                "events": {
                    "enabled": True,
                    "priority": 1,
                    "batch_size": 200
                },
                "health": {
                    "enabled": True,
                    "priority": 3,
                    "batch_size": 10
                }
            },
            "data_formats": {
                "transaction_bundle": {
                    "include_metadata": True,
                    "include_audit_trail": True,
                    "compress_data": False
                },
                "metrics": {
                    "include_timestamps": True,
                    "include_tags": True
                },
                "events": {
                    "include_context": True,
                    "include_correlation_ids": True
                }
            }
        }

def save_config(config):
    """Save the analytics configuration."""
    config_file = Path("config/analytics_config.json")
    config_file.parent.mkdir(exist_ok=True)
    
    with open(config_file, 'w') as f:
        json.dump(config, f, indent=2)

def enable_analytics(config, base_url=None, api_key=None, auth_token=None):
    """Enable analytics with the given configuration."""
    config["analytics_api"]["enabled"] = True
    
    if base_url:
        config["analytics_api"]["base_url"] = base_url
    
    if api_key:
        config["analytics_api"]["api_key"] = api_key
    
    if auth_token:
        config["analytics_api"]["auth_token"] = auth_token
    
    print("✅ Analytics enabled")
    print(f"   Base URL: {config['analytics_api']['base_url']}")
    print(f"   API Key: {'Set' if config['analytics_api']['api_key'] else 'Not set'}")
    print(f"   Auth Token: {'Set' if config['analytics_api']['auth_token'] else 'Not set'}")

def disable_analytics(config):
    """Disable analytics."""
    config["analytics_api"]["enabled"] = False
    print("❌ Analytics disabled")

def show_status(config):
    """Show the current analytics status."""
    enabled = config["analytics_api"]["enabled"]
    base_url = config["analytics_api"]["base_url"]
    
    print("📊 Analytics Configuration Status:")
    print(f"   Status: {'✅ Enabled' if enabled else '❌ Disabled'}")
    print(f"   Base URL: {base_url}")
    print(f"   API Key: {'Set' if config['analytics_api']['api_key'] else 'Not set'}")
    print(f"   Auth Token: {'Set' if config['analytics_api']['auth_token'] else 'Not set'}")
    print(f"   Timeout: {config['analytics_api']['timeout']}s")
    print(f"   Max Retries: {config['analytics_api']['max_retries']}")
    print(f"   Batch Size: {config['analytics_api']['batch_size']}")

def main():
    parser = argparse.ArgumentParser(description="Configure Gateway Service Analytics")
    parser.add_argument("--enable", action="store_true", help="Enable analytics")
    parser.add_argument("--disable", action="store_true", help="Disable analytics")
    parser.add_argument("--status", action="store_true", help="Show current status")
    parser.add_argument("--base-url", help="Set analytics base URL")
    parser.add_argument("--api-key", help="Set API key")
    parser.add_argument("--auth-token", help="Set auth token")
    
    args = parser.parse_args()
    
    # Load current configuration
    config = load_config()
    
    # Handle commands
    if args.status:
        show_status(config)
        return
    
    if args.enable:
        enable_analytics(config, args.base_url, args.api_key, args.auth_token)
        save_config(config)
    elif args.disable:
        disable_analytics(config)
        save_config(config)
    else:
        # Show current status if no action specified
        show_status(config)
        print("\n💡 Usage:")
        print("   python configure_analytics.py --enable --base-url https://your-api.com --api-key your_key")
        print("   python configure_analytics.py --disable")
        print("   python configure_analytics.py --status")

if __name__ == "__main__":
    main()
