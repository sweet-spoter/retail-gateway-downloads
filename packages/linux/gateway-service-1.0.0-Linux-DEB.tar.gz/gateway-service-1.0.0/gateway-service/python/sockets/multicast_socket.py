# import asyncio

# class MulticastSocket:
#     def __init__(self, group, port, mode):
#         self.group = group
#         self.port = port
#         self.mode = mode

#     async def connect_or_listen(self):
#         if self.mode == 'connect':
#             await self.connect()
#         elif self.mode == 'listen':
#             await self.listen()

#     async def connect(self):
#         try:
#             self.transport, self.protocol = await asyncio.get_event_loop().create_datagram_endpoint(
#                 lambda: MulticastProtocol(self.group),
#                 local_addr=('0.0.0.0', self.port)
#             )
#             print(f"Connected to multicast group {self.group} on port {self.port}")
#         except Exception as e:
#             print(f"Failed to connect to multicast group {self.group} on port {self.port}: {e}")

#     async def listen(self):
#         try:
#             self.transport, self.protocol = await asyncio.get_event_loop().create_datagram_endpoint(
#                 lambda: MulticastProtocol(self.group),
#                 remote_addr=(self.group, self.port)
#             )
#             print(f"Listening for multicast messages on group {self.group} on port {self.port}")
#         except Exception as e:
#             print(f"Failed to start listening for multicast messages on group {self.group} on port {self.port}: {e}")

#     async def send(self, data):
#         if self.mode == 'connect':
#             self.transport.sendto(data.encode(), (self.group, self.port))
#             print(f"Message sent via multicast: {data}")
#         else:
#             print("Cannot send data in listen mode.")

#     async def receive(self):
#         if self.mode == 'listen':
#             data, _ = await self.protocol.wait_for_data()
#             return data.decode()
#         else:
#             print("Cannot receive data in connect mode.")

#     async def close(self):
#         self.transport.close()
#         print("Socket closed.")

# class MulticastProtocol:
#     def __init__(self, group):
#         self.group = group

#     def connection_made(self, transport):
#         self.transport = transport

#     def datagram_received(self, data, addr):
#         print(f"Received multicast message from {addr}: {data.decode()}")

#     def error_received(self, exc):
#         print(f"Error received: {exc}")

#     def connection_lost(self, exc):
#         print("Connection lost")
import asyncio
from server.observer import post_event

class MulticastProtocol(asyncio.DatagramProtocol):
    connections = {}
    
    def __init__(self, multicast_group, port, register, direction, device_manager):
        self.multicast_group = multicast_group
        self.port = port
        self.register = register
        self.direction = direction
        self.device_manager = device_manager
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport
        print('Multicast listener started')
        MulticastProtocol.connections[self.direction+self.register] = self
        self.device_manager.set_protocol( self.direction+self.register ,self.direction, self.register)
        self.device_manager.on_connection_made(self.direction+self.register)

    def datagram_received(self, data, addr):
        print(f"Received message from {addr}: {data.decode()}")
        # Handle the complete message here
        ip_address, port = addr  # Unpack the IP address and port
        result = {'register': self.register,  'data': data.decode()}
        self.device_manager.handle_data(self.direction+self.register, data.decode, ip_address)

    def connection_lost(self, exc):
        print('Connection closed')
        self.transport.close()
        self.device_manager.on_connection_lost(self.direction+self.register)

    def send_message(self, message):
        self.transport.sendto(message.encode(), (self.multicast_group, self.port))
