"""
Lane manager for handling lane-based operations and device management.
"""

import asyncio
from typing import Dict, Any, Optional, List
from core.logging_config import get_logger
from core.exceptions import ServiceError
from core.interfaces import EventBusProtocol, DeviceManagerProtocol
from formatting.factory.pos_factory import POSFactory
from config.enhanced_config_loader import EnhancedConfigLoader

class LaneManager:
    """Manages lane-based operations and device management"""
    
    def __init__(self, config: Dict[str, Any], container):
        self.config = config
        self.container = container
        self.event_bus: EventBusProtocol = container.event_bus()
        self.device_manager: DeviceManagerProtocol = container.device_manager()
        
        self.logger = get_logger(__name__)
        
        # Lane tracking
        self.lanes: Dict[str, Dict[str, Any]] = {}
        self.lane_status: Dict[str, bool] = {}
        self.lane_devices: Dict[str, Dict[str, Any]] = {}
        self.lane_tasks: Dict[str, asyncio.Task] = {}
        
        # POS interfaces per lane
        self.pos_interfaces: Dict[str, Dict[str, Any]] = {}
        
        # Metrics
        self.lane_metrics: Dict[str, Dict[str, Any]] = {}
    
    async def start_lane(self, lane_id: str, lane_config: Dict[str, Any]) -> bool:
        """Start a specific lane with all its devices and outputs"""
        try:
            self.logger.info(f"Starting lane: {lane_id}")
            
            # Store lane configuration
            self.lanes[lane_id] = lane_config
            self.lane_status[lane_id] = False
            self.lane_devices[lane_id] = {}
            self.lane_metrics[lane_id] = {
                "start_time": asyncio.get_event_loop().time(),
                "devices_active": 0,
                "transactions_processed": 0,
                "errors": 0
            }
            
            # Initialize devices for this lane
            await self._initialize_lane_devices(lane_id, lane_config)
            
            # Start lane task
            task = asyncio.create_task(self._run_lane(lane_id, lane_config))
            self.lane_tasks[lane_id] = task
            
            # Mark lane as active
            self.lane_status[lane_id] = True
            
            self.logger.info(f"Lane {lane_id} started successfully with {len(self.lane_devices[lane_id])} devices")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to start lane {lane_id}: {e}")
            self.lane_status[lane_id] = False
            return False
    
    async def stop_lane(self, lane_id: str) -> bool:
        """Stop a specific lane"""
        try:
            self.logger.info(f"Stopping lane: {lane_id}")
            
            # Cancel lane task
            if lane_id in self.lane_tasks:
                self.lane_tasks[lane_id].cancel()
                try:
                    await self.lane_tasks[lane_id]
                except asyncio.CancelledError:
                    pass
                del self.lane_tasks[lane_id]
            
            # Stop devices
            await self._stop_lane_devices(lane_id)
            
            # Mark lane as inactive
            self.lane_status[lane_id] = False
            
            self.logger.info(f"Lane {lane_id} stopped successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to stop lane {lane_id}: {e}")
            return False
    
    async def restart_lane(self, lane_id: str) -> bool:
        """Restart a specific lane"""
        try:
            self.logger.info(f"Restarting lane: {lane_id}")
            
            # Stop lane
            await self.stop_lane(lane_id)
            
            # Wait a bit
            await asyncio.sleep(1)
            
            # Start lane again
            if lane_id in self.lanes:
                success = await self.start_lane(lane_id, self.lanes[lane_id])
                return success
            
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to restart lane {lane_id}: {e}")
            return False
    
    async def shutdown_all_lanes(self):
        """Shutdown all lanes"""
        try:
            self.logger.info("Shutting down all lanes")
            
            # Stop all lanes
            for lane_id in list(self.lanes.keys()):
                await self.stop_lane(lane_id)
            
            # Clear tracking
            self.lanes.clear()
            self.lane_status.clear()
            self.lane_devices.clear()
            self.lane_tasks.clear()
            self.pos_interfaces.clear()
            self.lane_metrics.clear()
            
            self.logger.info("All lanes shut down successfully")
            
        except Exception as e:
            self.logger.error(f"Error during lane shutdown: {e}")
            raise
    
    async def _initialize_lane_devices(self, lane_id: str, lane_config: Dict[str, Any]):
        """Initialize devices for a specific lane"""
        try:
            devices = lane_config.get('devices', {})
            self.lane_devices[lane_id] = {}
            self.pos_interfaces[lane_id] = {}
            
            for device_name, device_config in devices.items():
                # Check if device has streaming configuration
                streaming_config = device_config.get('streaming_config')
                if streaming_config and streaming_config.get('enabled', False):
                    # Create POS interface for streaming devices
                    pos_interface = await self._create_pos_interface(lane_id, device_name, streaming_config)
                    if pos_interface:
                        self.pos_interfaces[lane_id][device_name] = pos_interface
                        self.lane_devices[lane_id][device_name] = {
                            "type": "streaming",
                            "config": device_config,
                            "interface": pos_interface
                        }
                        self.logger.info(f"Created streaming interface for {lane_id}.{device_name}")
                
                # Add all devices to tracking
                self.lane_devices[lane_id][device_name] = {
                    "type": device_config.get('device_type', 'unknown'),
                    "config": device_config,
                    "active": True
                }
            
            self.logger.info(f"Initialized {len(self.lane_devices[lane_id])} devices for lane {lane_id}")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize devices for lane {lane_id}: {e}")
            raise
    
    async def _create_pos_interface(self, lane_id: str, device_name: str, streaming_config: Dict[str, Any]) -> Optional[Any]:
        """Create POS interface for streaming device"""
        try:
            # Create configuration for POS factory
            pos_config = {
                "device_type": streaming_config.get('device_type'),
                "handshake_required": streaming_config.get('handshake_required', False),
                "protocol": streaming_config.get('protocol'),
                "connection_type": streaming_config.get('connection_type'),
                "ip_connection": streaming_config.get('ip_connection'),
                "port_connection": streaming_config.get('port_connection'),
                "output_mapping": f"{lane_id}_{device_name}",
                "tcp_pipeline_host": streaming_config.get('tcp_pipeline_host'),
                "tcp_pipeline_port": streaming_config.get('tcp_pipeline_port'),
                "transaction_timeout": streaming_config.get('transaction_timeout', 30),
                "streaming_config": streaming_config.get('streaming_config', {})
            }
            
            # Add device-specific configurations
            if streaming_config.get('device_type') == 'infogenesis':
                pos_config.update({
                    "terminal_id": streaming_config.get('terminal_id'),
                    "terminal_ip": streaming_config.get('terminal_ip'),
                    "handshake_timeout": streaming_config.get('handshake_timeout', 10),
                    "handshake_retries": streaming_config.get('handshake_retries', 3),
                    "terminal_output_mapping": streaming_config.get('terminal_output_mapping', {})
                })
            elif streaming_config.get('device_type') == 'verifone':
                pos_config.update({
                    "terminal_id": streaming_config.get('terminal_id'),
                    "merchant_id": streaming_config.get('merchant_id')
                })
            
            # Validate configuration
            validation = POSFactory.validate_config(pos_config)
            if not validation["valid"]:
                self.logger.error(f"Configuration validation failed for {lane_id}.{device_name}:")
                for error in validation["errors"]:
                    self.logger.error(f"  Error: {error}")
                return None
            
            # Create interface
            interface = POSFactory.create_pos_interface(pos_config)
            if interface:
                self.logger.info(f"Created POS interface for {lane_id}.{device_name}")
                return interface
            else:
                self.logger.error(f"Failed to create POS interface for {lane_id}.{device_name}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error creating POS interface for {lane_id}.{device_name}: {e}")
            return None
    
    async def _stop_lane_devices(self, lane_id: str):
        """Stop devices for a specific lane"""
        try:
            if lane_id in self.lane_devices:
                for device_name, device_info in self.lane_devices[lane_id].items():
                    if device_info.get("type") == "streaming" and "interface" in device_info:
                        # Close POS interface
                        try:
                            interface = device_info["interface"]
                            if hasattr(interface, 'close'):
                                interface.close()
                        except Exception as e:
                            self.logger.error(f"Error closing interface for {lane_id}.{device_name}: {e}")
                    
                    device_info["active"] = False
                
                self.logger.info(f"Stopped all devices for lane {lane_id}")
            
        except Exception as e:
            self.logger.error(f"Error stopping devices for lane {lane_id}: {e}")
    
    async def _run_lane(self, lane_id: str, lane_config: Dict[str, Any]):
        """Run a lane with all its components"""
        try:
            self.logger.info(f"Running lane: {lane_id}")
            
            # Get lane outputs
            outputs = lane_config.get('outputs', {})
            
            # Subscribe to lane events
            await self._subscribe_to_lane_events(lane_id, outputs)
            
            # Run lane indefinitely
            while self.lane_status.get(lane_id, False):
                try:
                    # Process lane events
                    await self._process_lane_events(lane_id)
                    
                    # Update metrics
                    await self._update_lane_metrics(lane_id)
                    
                    # Sleep briefly
                    await asyncio.sleep(0.1)
                    
                except asyncio.CancelledError:
                    self.logger.info(f"Lane {lane_id} cancelled")
                    break
                except Exception as e:
                    self.logger.error(f"Error in lane {lane_id}: {e}")
                    self.lane_metrics[lane_id]["errors"] += 1
                    await asyncio.sleep(1)  # Brief pause on error
            
            self.logger.info(f"Lane {lane_id} stopped running")
            
        except Exception as e:
            self.logger.error(f"Failed to run lane {lane_id}: {e}")
            self.lane_status[lane_id] = False
    
    async def _subscribe_to_lane_events(self, lane_id: str, outputs: Dict[str, Any]):
        """Subscribe to events for this lane"""
        try:
            # Subscribe to device events
            for device_name in self.lane_devices.get(lane_id, {}).keys():
                event_type = f"lane_{lane_id}_device_{device_name}"
                self.event_bus.subscribe(event_type, self._handle_lane_device_event)
            
            # Subscribe to output events
            for output_name in outputs.keys():
                event_type = f"lane_{lane_id}_output_{output_name}"
                self.event_bus.subscribe(event_type, self._handle_lane_output_event)
            
            self.logger.info(f"Subscribed to events for lane {lane_id}")
            
        except Exception as e:
            self.logger.error(f"Failed to subscribe to events for lane {lane_id}: {e}")
    
    async def _process_lane_events(self, lane_id: str):
        """Process events for this lane"""
        # This would handle lane-specific event processing
        # Implementation depends on specific business logic
        pass
    
    async def _update_lane_metrics(self, lane_id: str):
        """Update metrics for this lane"""
        try:
            if lane_id in self.lane_metrics:
                metrics = self.lane_metrics[lane_id]
                
                # Count active devices
                active_devices = sum(
                    1 for device_info in self.lane_devices.get(lane_id, {}).values()
                    if device_info.get("active", False)
                )
                metrics["devices_active"] = active_devices
                
        except Exception as e:
            self.logger.error(f"Error updating metrics for lane {lane_id}: {e}")
    
    def _handle_lane_device_event(self, data: Dict[str, Any]):
        """Handle device events for lanes"""
        try:
            lane_id = data.get('lane_id')
            device_name = data.get('device_name')
            
            if lane_id and device_name:
                self.logger.debug(f"Lane {lane_id} device {device_name} event: {data}")
                
                # Update metrics
                if lane_id in self.lane_metrics:
                    self.lane_metrics[lane_id]["transactions_processed"] += 1
                
                # Process with POS interface if available
                if (lane_id in self.pos_interfaces and 
                    device_name in self.pos_interfaces[lane_id]):
                    interface = self.pos_interfaces[lane_id][device_name]
                    # Process with streaming pipeline
                    if hasattr(interface, 'process_streaming_data'):
                        interface.process_streaming_data(data.get('data', b''), data)
            
        except Exception as e:
            self.logger.error(f"Error handling lane device event: {e}")
    
    def _handle_lane_output_event(self, data: Dict[str, Any]):
        """Handle output events for lanes"""
        try:
            lane_id = data.get('lane_id')
            output_name = data.get('output_name')
            
            if lane_id and output_name:
                self.logger.debug(f"Lane {lane_id} output {output_name} event: {data}")
                
                # Handle different output types
                if output_name == 'streaming_pipeline':
                    # Send to streaming pipeline
                    pass
                elif output_name == 'live_events':
                    # Send to live events
                    pass
                elif output_name == 'transaction_bundles':
                    # Send to transaction bundles
                    pass
            
        except Exception as e:
            self.logger.error(f"Error handling lane output event: {e}")
    
    def get_lane_health(self) -> Dict[str, bool]:
        """Get health status of all lanes"""
        return self.lane_status.copy()
    
    def get_lane_status(self, lane_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed status of a specific lane"""
        if lane_id not in self.lanes:
            return None
        
        lane_config = self.lanes[lane_id]
        devices = self.lane_devices.get(lane_id, {})
        metrics = self.lane_metrics.get(lane_id, {})
        
        return {
            "lane_id": lane_id,
            "active": self.lane_status.get(lane_id, False),
            "register_id": lane_config.get('register_id'),
            "cashier_id": lane_config.get('cashier_id'),
            "location": lane_config.get('location'),
            "client": lane_config.get('client'),
            "license_status": lane_config.get('license_status'),
            "devices": {
                name: {
                    "type": info.get("type"),
                    "active": info.get("active", False)
                }
                for name, info in devices.items()
            },
            "metrics": metrics,
            "task_running": lane_id in self.lane_tasks and not self.lane_tasks[lane_id].done()
        }
    
    def get_lane_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Get metrics for all lanes"""
        return self.lane_metrics.copy()
    
    def get_all_lanes(self) -> Dict[str, Dict[str, Any]]:
        """Get information about all lanes"""
        return {
            lane_id: self.get_lane_status(lane_id)
            for lane_id in self.lanes.keys()
        } 