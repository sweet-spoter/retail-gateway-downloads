from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Protocol
from models.device_config import SocketConfig

class EventHandler(Protocol):
    """Protocol for event handlers"""
    def __call__(self, data: Any) -> None:
        ...

class ConnectionProtocol(ABC):
    """Abstract base class for connection protocols"""
    
    @abstractmethod
    async def connect(self) -> bool:
        """Establish connection"""
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """Close connection"""
        pass
    
    @abstractmethod
    async def send(self, data: bytes) -> bool:
        """Send data"""
        pass
    
    @abstractmethod
    async def receive(self) -> Optional[bytes]:
        """Receive data"""
        pass
    
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if connection is active"""
        pass

class DeviceManagerProtocol(ABC):
    """Abstract base class for device management"""
    
    @abstractmethod
    def add_device(self, device_id: str, device_config: Dict[str, Any], 
                   socket_type: str, connection_type: str) -> None:
        """Add a new device"""
        pass
    
    @abstractmethod
    def set_protocol(self, device_id: str, direction: str, register: str) -> None:
        """Set protocol for device"""
        pass
    
    @abstractmethod
    def handle_data(self, device_id: str, data: str, client_ip: str) -> None:
        """Handle incoming data"""
        pass
    
    @abstractmethod
    def send_message(self, device_id: str, data: str, addr: Optional[str] = None) -> None:
        """Send message to device"""
        pass

class EventBusProtocol(ABC):
    """Abstract base class for event bus"""
    
    @abstractmethod
    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        """Subscribe to an event type"""
        pass
    
    @abstractmethod
    def publish(self, event_type: str, data: Any = None) -> None:
        """Publish an event"""
        pass
    
    @abstractmethod
    def unsubscribe(self, event_type: str, handler: EventHandler) -> None:
        """Unsubscribe from an event type"""
        pass

class ConfigurationProvider(ABC):
    """Abstract base class for configuration providers"""
    
    @abstractmethod
    def get_config(self) -> Dict[str, Any]:
        """Get configuration"""
        pass
    
    @abstractmethod
    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration"""
        pass
    
    @abstractmethod
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """Validate configuration"""
        pass

class ConnectionManagerProtocol(ABC):
    """Abstract base class for connection management"""
    
    @abstractmethod
    async def start_all_connections(self) -> None:
        """Start all configured connections"""
        pass
    
    @abstractmethod
    async def stop_all_connections(self) -> None:
        """Stop all connections"""
        pass
    
    @abstractmethod
    async def restart_connection(self, config: SocketConfig) -> bool:
        """Restart a specific connection"""
        pass
    
    @abstractmethod
    def get_connection_status(self) -> Dict[str, bool]:
        """Get status of all connections"""
        pass 