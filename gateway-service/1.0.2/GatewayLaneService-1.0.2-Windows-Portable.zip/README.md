# Gateway Lane Service Installer

## System Requirements
- Windows 10 or later (64-bit)
- 4GB RAM minimum
- 10GB free disk space
- Administrator privileges for installation

## Installation
1. Run `validate-requirements.bat` to check system compatibility
2. Run `install.bat` as Administrator
3. Run `start_gateway.bat` to start the service

## Configuration
Edit `config.json` as needed.

## Service Management
- Service Name: Gateway Lane Service
- Service ID: GatewayLaneService
- Install Location: C:\Program Files\GatewayLaneService

## Uninstallation
Run `uninstall.bat` as Administrator to remove the service.
