"""
Enhanced application service that supports lane-based architecture with streaming pipeline integration.
"""

import asyncio
from typing import Optional, Dict, Any, List
from core.logging_config import get_logger
from core.exceptions import ServiceError
from core.container import get_container
from core.health import HealthChecker
from core.metrics import get_metrics_registry, get_system_metrics, get_connection_metrics
from services.enhanced_connection_manager import EnhancedConnectionManager
from services.lane_manager import LaneManager
from services.streaming_pipeline_manager import StreamingPipelineManager
from services.session_manager import SessionManager
from config.enhanced_config_loader import EnhancedConfigLoader

class EnhancedApplicationService:
    """Enhanced application service that manages lane-based architecture with streaming pipeline"""
    
    def __init__(self, config_path: str = None):
        self.container = get_container()
        self.config_loader = EnhancedConfigLoader(config_path)
        self.lane_manager: Optional[LaneManager] = None
        self.connection_manager: Optional[EnhancedConnectionManager] = None
        self.streaming_pipeline_manager: Optional[StreamingPipelineManager] = None
        self.session_manager: Optional[SessionManager] = None
        
        self.logger = get_logger(__name__)
        self.running = False
        self.healthy = False
        self.startup_time = None
        
        # Initialize monitoring components
        self.health_checker = HealthChecker()
        self.metrics_registry = get_metrics_registry()
        self.system_metrics = get_system_metrics()
        self.connection_metrics = get_connection_metrics()
        
        # Lane tracking
        self.lanes: Dict[str, Any] = {}
        self.active_lanes: List[str] = []
    
    async def start(self):
        """Start the enhanced application service"""
        try:
            self.logger.info("Starting enhanced application service")
            
            # Load enhanced configuration
            config = self.config_loader.load_config()
            self.logger.info(f"Loaded enhanced configuration with {len(self.config_loader.get_lanes())} lanes")
            
            # Initialize managers
            await self._initialize_managers(config)
            
            # Start all lanes
            await self._start_all_lanes()
            
            # Start streaming pipeline
            await self._start_streaming_pipeline()
            
            # Start session management
            await self._start_session_management()
            
            self.running = True
            self.healthy = True
            self.startup_time = asyncio.get_event_loop().time()
            
            # Update metrics
            self.system_metrics["uptime_seconds"].set(0)
            self.system_metrics["startup_time"].set(self.startup_time)
            self.system_metrics["active_lanes"].set(len(self.active_lanes))
            
            self.logger.info(f"Enhanced application service started successfully with {len(self.active_lanes)} active lanes")
            
        except Exception as e:
            self.logger.error(f"Failed to start enhanced application service: {e}")
            self.healthy = False
            raise ServiceError(f"Enhanced application service startup failed: {e}")
    
    async def shutdown(self):
        """Gracefully shutdown the enhanced application service"""
        try:
            self.logger.info("Shutting down enhanced application service")
            
            self.running = False
            self.healthy = False
            
            # Stop session management
            if self.session_manager:
                await self.session_manager.shutdown()
            
            # Stop streaming pipeline
            if self.streaming_pipeline_manager:
                await self.streaming_pipeline_manager.shutdown()
            
            # Stop all lanes
            if self.lane_manager:
                await self.lane_manager.shutdown_all_lanes()
            
            # Stop connection manager
            if self.connection_manager:
                await self.connection_manager.shutdown_all_connections()
            
            self.logger.info("Enhanced application service shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during enhanced application service shutdown: {e}")
            raise
    
    async def restart(self):
        """Restart the enhanced application service"""
        try:
            self.logger.info("Restarting enhanced application service")
            
            await self.shutdown()
            await asyncio.sleep(1)  # Brief pause before restart
            await self.start()
            
            self.logger.info("Enhanced application service restarted successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to restart enhanced application service: {e}")
            raise ServiceError(f"Enhanced application service restart failed: {e}")
    
    async def _initialize_managers(self, config: Dict[str, Any]):
        """Initialize all service managers"""
        try:
            # Initialize lane manager
            self.lane_manager = LaneManager(config, self.container)
            
            # Initialize connection manager
            self.connection_manager = EnhancedConnectionManager(
                config=config,
                event_bus=self.container.event_bus(),
                device_manager=self.container.device_manager()
            )
            
            # Initialize streaming pipeline manager
            streaming_config = self.config_loader.get_streaming_pipeline_config()
            self.streaming_pipeline_manager = StreamingPipelineManager(
                config=streaming_config,
                event_bus=self.container.event_bus()
            )
            
            # Initialize session manager
            self.session_manager = SessionManager(
                event_bus=self.container.event_bus()
            )
            
            self.logger.info("All managers initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize managers: {e}")
            raise
    
    async def _start_all_lanes(self):
        """Start all configured lanes"""
        try:
            lanes = self.config_loader.get_lanes()
            
            for lane_id, lane_config in lanes.items():
                # Validate lane configuration
                validation = self.config_loader.validate_lane_configuration(lane_id)
                if not validation["valid"]:
                    self.logger.error(f"Lane {lane_id} validation failed: {validation['errors']}")
                    continue
                
                # Start lane
                success = await self.lane_manager.start_lane(lane_id, lane_config)
                if success:
                    self.active_lanes.append(lane_id)
                    self.lanes[lane_id] = lane_config
                    self.logger.info(f"Lane {lane_id} started successfully")
                else:
                    self.logger.error(f"Failed to start lane {lane_id}")
            
            self.logger.info(f"Started {len(self.active_lanes)} lanes")
            
        except Exception as e:
            self.logger.error(f"Failed to start lanes: {e}")
            raise
    
    async def _start_streaming_pipeline(self):
        """Start streaming pipeline"""
        try:
            if self.streaming_pipeline_manager:
                await self.streaming_pipeline_manager.start()
                self.logger.info("Streaming pipeline started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start streaming pipeline: {e}")
            raise
    
    async def _start_session_management(self):
        """Start session management"""
        try:
            if self.session_manager:
                await self.session_manager.start()
                self.logger.info("Session management started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start session management: {e}")
            raise
    
    def is_healthy(self) -> bool:
        """Check if the enhanced application service is healthy"""
        if not self.running:
            return False
        
        # Check lane health
        if self.lane_manager:
            lane_health = self.lane_manager.get_lane_health()
            unhealthy_lanes = [lane_id for lane_id, healthy in lane_health.items() if not healthy]
            if unhealthy_lanes:
                self.logger.warning(f"Unhealthy lanes: {unhealthy_lanes}")
        
        # Check connection health
        if self.connection_manager:
            connection_status = self.connection_manager.get_connection_status()
            active_connections = sum(1 for status in connection_status.values() if status)
            if active_connections == 0:
                self.logger.warning("No active connections")
        
        # Check streaming pipeline health
        if self.streaming_pipeline_manager:
            pipeline_health = self.streaming_pipeline_manager.is_healthy()
            if not pipeline_health:
                self.logger.warning("Streaming pipeline unhealthy")
        
        # Consider healthy if at least one lane is active
        self.healthy = len(self.active_lanes) > 0
        
        return self.healthy
    
    def get_status(self) -> dict:
        """Get current enhanced service status"""
        lane_health = self.lane_manager.get_lane_health() if self.lane_manager else {}
        connection_status = self.connection_manager.get_connection_status() if self.connection_manager else {}
        pipeline_health = self.streaming_pipeline_manager.is_healthy() if self.streaming_pipeline_manager else False
        
        return {
            "running": self.running,
            "healthy": self.healthy,
            "startup_time": self.startup_time,
            "uptime": asyncio.get_event_loop().time() - self.startup_time if self.startup_time else 0,
            "active_lanes": self.active_lanes,
            "total_lanes": len(self.lanes),
            "lane_health": lane_health,
            "connections": connection_status,
            "streaming_pipeline_healthy": pipeline_health,
            "session_manager_active": self.session_manager.is_running() if self.session_manager else False
        }
    
    def get_lane_summary(self) -> List[Dict[str, Any]]:
        """Get summary of all lanes"""
        return self.config_loader.get_lane_summary()
    
    def get_lane_status(self, lane_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a specific lane"""
        if not self.lane_manager:
            return None
        
        return self.lane_manager.get_lane_status(lane_id)
    
    async def restart_lane(self, lane_id: str) -> bool:
        """Restart a specific lane"""
        try:
            if not self.lane_manager:
                return False
            
            success = await self.lane_manager.restart_lane(lane_id)
            if success:
                self.logger.info(f"Lane {lane_id} restarted successfully")
            else:
                self.logger.error(f"Failed to restart lane {lane_id}")
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error restarting lane {lane_id}: {e}")
            return False
    
    async def get_configuration(self) -> Dict[str, Any]:
        """Get current enhanced configuration"""
        return self.config_loader.config
    
    async def update_configuration(self, new_config: dict) -> bool:
        """Update enhanced configuration and restart if needed"""
        try:
            self.logger.info("Updating enhanced configuration")
            
            # Validate new configuration
            # Note: Enhanced validation would be implemented here
            
            # Save new configuration
            self.config_loader.save_enhanced_config()
            
            # Restart service to apply new configuration
            await self.restart()
            
            self.logger.info("Enhanced configuration updated successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to update enhanced configuration: {e}")
            return False
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get enhanced service metrics"""
        return {
            "system": {
                "uptime": asyncio.get_event_loop().time() - self.startup_time if self.startup_time else 0,
                "active_lanes": len(self.active_lanes),
                "total_lanes": len(self.lanes),
                "healthy": self.healthy
            },
            "lanes": self.lane_manager.get_lane_metrics() if self.lane_manager else {},
            "connections": self.connection_manager.get_connection_metrics() if self.connection_manager else {},
            "streaming": self.streaming_pipeline_manager.get_metrics() if self.streaming_pipeline_manager else {},
            "sessions": self.session_manager.get_metrics() if self.session_manager else {}
        } 