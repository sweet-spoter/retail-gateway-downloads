# Gulfcoast Gateway Service

A Windows service that acts as an adapter to connect devices via TCP, UDP, multicast, and serial protocols, with output capabilities to various destinations including APIs.

## Architecture Overview

The service has been refactored to follow modern software engineering practices with improved maintainability, testability, and scalability.

### Key Improvements

1. **Separation of Concerns**: Clear boundaries between service management, business logic, and data handling
2. **Dependency Injection**: Loose coupling between components for better testability
3. **Type Safety**: Pydantic models for configuration validation and type checking
4. **Structured Logging**: Enhanced logging with correlation IDs for better tracing
5. **Error Handling**: Custom exception classes and proper error management
6. **Health Monitoring**: Connection health checks and service monitoring
7. **Configuration Management**: Validated configuration with runtime updates

## Project Structure

```
gateway_service_latest/
├── core/                    # Core application logic
│   ├── container.py        # Dependency injection container
│   ├── exceptions.py       # Custom exception classes
│   ├── constants.py        # Application constants
│   ├── interfaces.py       # Abstract base classes
│   ├── logging_config.py   # Logging configuration
│   └── correlation.py      # Correlation ID management
├── models/                  # Data models
│   ├── device_config.py    # Configuration models
│   └── connection_config.py # Connection models
├── services/               # Business logic services
│   ├── service_manager.py  # Windows service management
│   ├── application_service.py # Core application logic
│   └── connection_manager.py # Connection management
├── sockets/                # Socket implementations
├── event_manager/          # Event management
├── config/                 # Configuration management
├── formatting/             # Data formatting
├── api/                    # API integrations
├── server/                 # Server logic
├── tests/                  # Unit tests
├── main.py                 # Application entry point
└── requirements.txt        # Dependencies
```

## Features

### Supported Protocols
- **TCP**: Client and server connections
- **UDP**: Client and server connections  
- **Multicast**: Group communication
- **Serial**: Serial port communication (planned)

### Device Management
- Automatic device discovery
- Connection health monitoring
- Graceful reconnection with exponential backoff
- Device configuration validation

### Event System
- Type-safe event bus
- Correlation ID tracking
- Asynchronous event processing
- Event filtering and routing

### Configuration
- JSON-based configuration
- Runtime configuration updates
- Configuration validation
- Environment-specific settings

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Configure the service:
   - Edit `config/config.json` with your device configurations
   - Set appropriate logging levels and discovery settings

3. Run in console mode:
```bash
python main.py
```

4. Install as Windows service:
```bash
python main.py install
python main.py start
```

## Configuration

The service uses a JSON configuration file with the following structure:

```json
{
    "debug": false,
    "discover_remote_ip": false,
    "input_configs": [
        {
            "socket_type": "tcp",
            "connection_type": "listen",
            "host": "0.0.0.0",
            "port": 5999,
            "register": "101",
            "device": {
                "name": "infogenesis",
                "type": "handshake",
                "terminals": [
                    {
                        "term_id": 101,
                        "term_ip": "192.168.1.0/24"
                    }
                ]
            },
            "filter": {
                "date": [0, 8],
                "time": [9, 17],
                "terminal": [18, 21],
                "description": [22, -13],
                "quantity": [-12, -9],
                "price": [-8, null]
            }
        }
    ],
    "output_configs": [
        {
            "socket_type": "tcp",
            "connection_type": "connect",
            "host": "127.0.0.1",
            "port": 5002,
            "register": "101",
            "device": {
                "name": "api_endpoint",
                "type": "api"
            }
        }
    ]
}
```

## Testing

Run the test suite:
```bash
pytest tests/
```

Run specific test categories:
```bash
pytest tests/test_config.py
pytest tests/test_event_bus.py
```

## API Integration

The service supports API output connections. To add API integration:

1. Create API client implementations in the `api/` directory
2. Add API configuration to output_configs
3. Implement API-specific data formatting

Example API configuration:
```json
{
    "socket_type": "api",
    "connection_type": "connect",
    "host": "https://api.example.com",
    "port": 443,
    "register": "api_101",
    "device": {
        "name": "rest_api",
        "type": "api",
        "auth": {
            "type": "bearer",
            "token": "your_api_token"
        },
        "endpoints": {
            "data": "/api/v1/data",
            "health": "/api/v1/health"
        }
    }
}
```

## Logging

The service uses structured logging with correlation IDs. Log files are stored in the `logs/` directory with automatic rotation.

Log levels:
- **DEBUG**: Detailed debugging information
- **INFO**: General operational messages
- **WARNING**: Warning conditions
- **ERROR**: Error conditions
- **CRITICAL**: Critical errors

## Monitoring

The service provides health monitoring capabilities:

- Connection status monitoring
- Service health checks
- Performance metrics
- Error tracking with correlation IDs

## Development

### Adding New Protocols

1. Implement the protocol in the `sockets/` directory
2. Add protocol factory method in `socket_factory.py`
3. Update configuration models if needed
4. Add tests for the new protocol

### Adding New Device Types

1. Create device handler in `formatting/` directory
2. Update device configuration models
3. Add device-specific event handlers
4. Implement device validation logic

## Troubleshooting

### Common Issues

1. **Configuration Errors**: Check JSON syntax and required fields
2. **Connection Failures**: Verify network connectivity and firewall settings
3. **Service Won't Start**: Check Windows Event Logs for detailed error messages
4. **Performance Issues**: Monitor log files for bottlenecks and connection issues

### Debug Mode

Enable debug mode in configuration to get detailed logging:
```json
{
    "debug": true
}
```

## Contributing

1. Follow the established code structure
2. Add tests for new features
3. Update documentation
4. Use type hints and follow PEP 8
5. Add proper error handling and logging

## License

[Add your license information here] 
