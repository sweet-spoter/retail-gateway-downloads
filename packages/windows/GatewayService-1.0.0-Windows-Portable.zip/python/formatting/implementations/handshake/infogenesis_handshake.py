"""
Infogenesis handshake implementation based on the working infogenesis.py logic.
"""

import datetime
import asyncio
from typing import Dict, Any, Optional

class InfoGenesisMsg:
    """InfoGenesis message parser for the specific message format."""
    
    def __init__(self, strdata):
        self.msg_date = strdata[7:15]
        self.msg_time = strdata[15:21]
        self.msg_evt_terminal = strdata[21:30]
        self.msg_profit_center = strdata[30:39]
        self.msg_employee = strdata[39:48]
        self.msg_line = strdata[48:88]
        self.msg_line_number = strdata[88:91]
        self.msg_indicator = self.msg_line[:3]
    
    def __repr__(self):
        return (f"InfoGenesisMsg(date={self.msg_date}, time={self.msg_time}, "
                f"terminal={self.msg_evt_terminal}, profit_center={self.msg_profit_center}, "
                f"employee={self.msg_employee}, line={self.msg_line}, "
                f"line_number={self.msg_line_number}, indicator={self.msg_indicator})")

class InfogenesisHandshake:
    """
    Infogenesis handshake implementation based on the working infogenesis.py logic.
    This class handles the specific handshake protocol used by Infogenesis devices.
    """
    
    def __init__(self, terminal_id: str, terminal_ip: str):
        self.terminal_id = terminal_id
        self.terminal_ip = terminal_ip
        
        # Terminal state (matching the working implementation)
        self.terminals = {
            "terminal_id": {},
            "raw_data": {},
            "pem_timer": {},
            "pcm_timer": {},
            "parse_data": {},
            "split_msg": {},
            "sam_cmd": {},
            "hs_number": {},
            "scm_ack": {}
        }
        
        # Initialize terminal state
        self.reset(self.terminal_ip)
        self.terminals['terminal_id'][self.terminal_ip] = self.terminal_id
    
    def reset(self, terminal_ip: str):
        """Reset terminal state (matching the working implementation)."""
        self.terminals['terminal_id'][terminal_ip] = ""
        self.terminals['raw_data'][terminal_ip] = ""
        self.terminals['parse_data'][terminal_ip] = None
        self.terminals['split_msg'][terminal_ip] = []
        self.terminals['pem_timer'][terminal_ip] = datetime.datetime.now()
        self.terminals['pcm_timer'][terminal_ip] = datetime.datetime.now()
        self.terminals['scm_ack'][terminal_ip] = False
    
    def construct_scm_command(self, register: str, date_time_str: str = None) -> str:
        """
        Construct SCM command (matching the working implementation).
        
        Args:
            register: Register number
            date_time_str: DateTime string (optional)
            
        Returns:
            str: SCM command string
        """
        if date_time_str is None:
            date_time_str = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        
        base_command = f"\x02SCM1  {date_time_str}0000000010"
        
        try:
            term = int(register)
        except ValueError:
            print(f"Error: 'register' value {register} cannot be converted to an integer.")
            term = 0
        
        if self.terminals['scm_ack'][self.terminal_ip]:
            command = f"{base_command}00{term:09d}\x03"
        else:
            self.terminals['scm_ack'][self.terminal_ip] = False
            command = f"{base_command}01{term:09d}\x03"
        
        return command
    
    def construct_sam_command(self, hs_number: str) -> str:
        """
        Construct SAM command (matching the working implementation).
        
        Args:
            hs_number: Handshake number
            
        Returns:
            str: SAM command string
        """
        now = datetime.datetime.now()
        return f"\x02SAM1  {now:%Y%m%d%H%M%S}{hs_number:0>9}\x03"
    
    def contains_special_characters(self, input_string: str) -> bool:
        """
        Check if string contains STX/ETX characters (matching working implementation).
        
        Args:
            input_string: String to check
            
        Returns:
            bool: True if contains STX and ETX
        """
        hex_02 = '\x02'  # STX
        hex_03 = '\x03'  # ETX
        
        contains_hex_02 = hex_02 in input_string
        contains_hex_03 = hex_03 in input_string
        
        return contains_hex_02 and contains_hex_03
    
    def process_message_stream(self, stream: str) -> str:
        """
        Process message stream (matching working implementation).
        
        Args:
            stream: Message stream
            
        Returns:
            str: Processed message
        """
        start_marker = '╗'
        end_marker = '╚'
        buffer = ""
        messages = []

        def extract_complete_messages(buffer):
            complete_messages = []
            while start_marker in buffer and end_marker in buffer:
                start_index = buffer.find(start_marker)
                end_index = buffer.find(end_marker, start_index) + 1
                complete_message = buffer[start_index:end_index]
                complete_messages.append(complete_message)
                buffer = buffer[end_index:]
            return complete_messages, buffer

        def handle_complete_message(message):
            print(f"Processed message: {message}")

        buffer += stream
        complete_messages, buffer = extract_complete_messages(buffer)
        
        for message in complete_messages:
            handle_complete_message(message)
        
        return buffer
    
    def add_key_if_empty(self, original_dict: Optional[Dict], key: str, value: str) -> Dict[str, str]:
        """
        Add key if dictionary is empty (matching working implementation).
        
        Args:
            original_dict: Original dictionary
            key: Key to add
            value: Value to add
            
        Returns:
            Dict: Updated dictionary
        """
        if original_dict is None or not original_dict:
            new_dict = {}
            new_dict[key] = value
            return new_dict
        else:
            return original_dict.copy()
    
    def manage_handshake_data(self, data: str, register: str) -> Dict[str, Any]:
        """
        Manage handshake data (matching working implementation logic).
        
        Args:
            data: Raw data from device
            register: Register number
            
        Returns:
            Dict: Processing result
        """
        self.terminals['raw_data'][self.terminal_ip] = self.process_message_stream(data)
        print(f"Handshake arrival data {self.terminals['raw_data'][self.terminal_ip]}")
        
        result = {
            "processed": False,
            "message_type": None,
            "scm_command": None,
            "sam_command": None,
            "parsed_message": None
        }
        
        if self.contains_special_characters(self.terminals['raw_data'][self.terminal_ip]):
            # Extract indicator (first 3 characters after STX)
            raw_data = self.terminals['raw_data'][self.terminal_ip]
            if len(raw_data) >= 4:
                indicator = raw_data[1:4].upper()
                
                if indicator == "PEM":
                    # Process PEM message
                    result["message_type"] = "PEM"
                    result["processed"] = True
                    
                    if len(raw_data) >= 88:
                        self.terminals['parse_data'][self.terminal_ip] = InfoGenesisMsg(raw_data)
                        result["parsed_message"] = str(self.terminals['parse_data'][self.terminal_ip])
                
                elif indicator == "PAM":
                    # Process PAM message (acknowledgment)
                    result["message_type"] = "PAM"
                    result["processed"] = True
                    self.terminals['pem_timer'][self.terminal_ip] = datetime.datetime.now()
                    self.terminals['scm_ack'][self.terminal_ip] = True
                    print("PAM command arrived")
                
                elif indicator == "PCM":
                    # Process PCM message (handshake number)
                    result["message_type"] = "PCM"
                    result["processed"] = True
                    
                    if len(raw_data) >= 30:
                        self.terminals['hs_number'][self.terminal_ip] = raw_data[21:30]
                        hs_number = self.terminals['hs_number'][self.terminal_ip]
                        
                        # Construct SAM command
                        sam_command = self.construct_sam_command(hs_number)
                        self.terminals['sam_cmd'][self.terminal_ip] = sam_command
                        result["sam_command"] = sam_command
                        
                        print(f"PCM command arrived with hs_number: {hs_number}")
        
        return result
    
    def get_terminal_state(self) -> Dict[str, Any]:
        """
        Get current terminal state.
        
        Returns:
            Dict: Terminal state information
        """
        return {
            "terminal_id": self.terminal_id,
            "terminal_ip": self.terminal_ip,
            "scm_ack": self.terminals['scm_ack'].get(self.terminal_ip, False),
            "hs_number": self.terminals['hs_number'].get(self.terminal_ip),
            "pem_timer": self.terminals['pem_timer'].get(self.terminal_ip),
            "pcm_timer": self.terminals['pcm_timer'].get(self.terminal_ip),
            "parse_data": self.terminals['parse_data'].get(self.terminal_ip),
            "raw_data": self.terminals['raw_data'].get(self.terminal_ip, "")
        }
    
    def is_handshake_complete(self) -> bool:
        """
        Check if handshake is complete.
        
        Returns:
            bool: True if handshake is complete
        """
        return self.terminals['scm_ack'].get(self.terminal_ip, False) 