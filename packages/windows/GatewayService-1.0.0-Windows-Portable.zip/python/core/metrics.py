from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from collections import defaultdict, deque
import time
import threading
from core.logging_config import get_logger

@dataclass
class MetricPoint:
    """Individual metric data point"""
    value: float
    timestamp: float
    labels: Dict[str, str] = field(default_factory=dict)

class Metric:
    """Base metric class"""
    
    def __init__(self, name: str, description: str = "", labels: List[str] = None):
        self.name = name
        self.description = description
        self.labels = labels or []
        self.data_points: deque = deque(maxlen=1000)  # Keep last 1000 points
        self._lock = threading.Lock()
    
    def record(self, value: float, labels: Dict[str, str] = None):
        """Record a metric value"""
        with self._lock:
            self.data_points.append(MetricPoint(
                value=value,
                timestamp=time.time(),
                labels=labels or {}
            ))
    
    def get_latest(self) -> Optional[float]:
        """Get the latest metric value"""
        with self._lock:
            if not self.data_points:
                return None
            return self.data_points[-1].value
    
    def get_summary(self) -> Dict[str, Any]:
        """Get metric summary statistics"""
        with self._lock:
            if not self.data_points:
                return {
                    "name": self.name,
                    "description": self.description,
                    "count": 0,
                    "min": None,
                    "max": None,
                    "avg": None,
                    "latest": None
                }
            
            values = [point.value for point in self.data_points]
            return {
                "name": self.name,
                "description": self.description,
                "count": len(values),
                "min": min(values),
                "max": max(values),
                "avg": sum(values) / len(values),
                "latest": values[-1]
            }

class Counter(Metric):
    """Counter metric that only increases"""
    
    def __init__(self, name: str, description: str = "", labels: List[str] = None):
        super().__init__(name, description, labels)
        self._total = 0
    
    def increment(self, value: float = 1, labels: Dict[str, str] = None):
        """Increment the counter"""
        self._total += value
        self.record(self._total, labels)
    
    def get_total(self) -> float:
        """Get the total counter value"""
        return self._total

class Gauge(Metric):
    """Gauge metric that can go up and down"""
    
    def set(self, value: float, labels: Dict[str, str] = None):
        """Set the gauge value"""
        self.record(value, labels)

class Histogram(Metric):
    """Histogram metric for distribution analysis"""
    
    def __init__(self, name: str, description: str = "", labels: List[str] = None, buckets: List[float] = None):
        super().__init__(name, description, labels)
        self.buckets = buckets or [0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 25.0, 50.0, 100.0]
        self.bucket_counts = defaultdict(int)
    
    def observe(self, value: float, labels: Dict[str, str] = None):
        """Observe a value for histogram"""
        self.record(value, labels)
        
        # Update bucket counts
        for bucket in self.buckets:
            if value <= bucket:
                self.bucket_counts[bucket] += 1
                break
    
    def get_bucket_counts(self) -> Dict[float, int]:
        """Get bucket counts"""
        return dict(self.bucket_counts)

class MetricsRegistry:
    """Central metrics registry"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.metrics: Dict[str, Metric] = {}
        self._lock = threading.Lock()
    
    def counter(self, name: str, description: str = "", labels: List[str] = None) -> Counter:
        """Get or create a counter metric"""
        with self._lock:
            if name not in self.metrics:
                self.metrics[name] = Counter(name, description, labels)
            return self.metrics[name]
    
    def gauge(self, name: str, description: str = "", labels: List[str] = None) -> Gauge:
        """Get or create a gauge metric"""
        with self._lock:
            if name not in self.metrics:
                self.metrics[name] = Gauge(name, description, labels)
            return self.metrics[name]
    
    def histogram(self, name: str, description: str = "", labels: List[str] = None, buckets: List[float] = None) -> Histogram:
        """Get or create a histogram metric"""
        with self._lock:
            if name not in self.metrics:
                self.metrics[name] = Histogram(name, description, labels, buckets)
            return self.metrics[name]
    
    def get_metric(self, name: str) -> Optional[Metric]:
        """Get a metric by name"""
        return self.metrics.get(name)
    
    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Get all metrics with their summaries"""
        return {
            name: metric.get_summary() 
            for name, metric in self.metrics.items()
        }
    
    def reset(self):
        """Reset all metrics"""
        with self._lock:
            self.metrics.clear()

# Global metrics registry
_metrics_registry = MetricsRegistry()

def get_metrics_registry() -> MetricsRegistry:
    """Get the global metrics registry"""
    return _metrics_registry

# Common metrics
def get_connection_metrics():
    """Get connection-related metrics"""
    registry = get_metrics_registry()
    return {
        "active_connections": registry.gauge("connections_active", "Number of active connections"),
        "total_connections": registry.gauge("connections_total", "Total number of configured connections"),
        "connection_errors": registry.counter("connections_errors", "Number of connection errors"),
        "connection_latency": registry.histogram("connection_latency_ms", "Connection latency in milliseconds"),
        "messages_sent": registry.counter("messages_sent", "Number of messages sent"),
        "messages_received": registry.counter("messages_received", "Number of messages received"),
        "message_processing_time": registry.histogram("message_processing_time_ms", "Message processing time in milliseconds")
    }

def get_system_metrics():
    """Get system-related metrics"""
    registry = get_metrics_registry()
    return {
        "memory_usage_mb": registry.gauge("memory_usage_mb", "Memory usage in MB"),
        "cpu_usage_percent": registry.gauge("cpu_usage_percent", "CPU usage percentage"),
        "uptime_seconds": registry.gauge("uptime_seconds", "Service uptime in seconds"),
        "startup_time": registry.gauge("startup_time", "Service startup timestamp")
    }

def get_business_metrics():
    """Get business-related metrics"""
    registry = get_metrics_registry()
    return {
        "devices_connected": registry.gauge("devices_connected", "Number of connected devices"),
        "transactions_processed": registry.counter("transactions_processed", "Number of transactions processed"),
        "transaction_success_rate": registry.gauge("transaction_success_rate", "Transaction success rate percentage"),
        "average_response_time": registry.histogram("response_time_ms", "Average response time in milliseconds")
    } 