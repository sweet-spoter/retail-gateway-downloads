# Gateway Service Web Application

A modern React-based web application for configuring and managing the Gateway Service. This application provides a user-friendly interface for device management, configuration, monitoring, and service administration.

## Features

### 🔐 Authentication
- Secure login system with JWT tokens
- Role-based access control
- Session management
- Protected routes

### 📊 Dashboard
- Real-time service health monitoring
- Performance metrics and statistics
- Service status overview
- Quick action buttons for service control

### 🔧 Device Management
- Device discovery and configuration
- Connection status monitoring
- Device health checks
- Configuration templates

### ⚙️ Configuration Management
- Visual configuration interface
- Import/export configurations
- Configuration validation
- Template management

### 📈 Monitoring & Analytics
- Real-time metrics display
- Health check status
- Performance analytics
- Alert management

### 🛠️ Service Administration
- Start/stop/restart service
- Service status monitoring
- Log management
- System health checks

## Technology Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS
- **State Management**: React Query + Context API
- **Routing**: React Router v6
- **Forms**: React Hook Form
- **HTTP Client**: Axios
- **Icons**: Heroicons + Lucide React
- **Charts**: Recharts
- **Notifications**: React Hot Toast
- **PWA**: Workbox

## Getting Started

### Prerequisites

- Node.js 16+ 
- npm or yarn
- Gateway Service running on localhost:8080

### Installation

1. **Clone the repository**
   ```bash
   cd web-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```

4. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Building for Production

```bash
npm run build
```

The build artifacts will be stored in the `build/` directory.

### PWA Build

```bash
npm run build-pwa
```

This creates a Progressive Web App with service worker for offline capabilities.

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── Layout/         # Layout components
│   ├── Forms/          # Form components
│   └── UI/             # Generic UI components
├── contexts/           # React contexts
│   ├── AuthContext.tsx # Authentication context
│   └── DeviceContext.tsx # Device management context
├── hooks/              # Custom React hooks
│   └── useAuth.ts      # Authentication hook
├── pages/              # Page components
│   ├── Auth/           # Authentication pages
│   ├── Dashboard/      # Dashboard page
│   ├── Devices/        # Device management pages
│   ├── Configuration/  # Configuration pages
│   ├── Monitoring/     # Monitoring pages
│   └── Settings/       # Settings pages
├── services/           # API services
│   └── api.ts          # API client and endpoints
├── types/              # TypeScript type definitions
├── utils/              # Utility functions
├── App.tsx             # Main application component
└── index.tsx           # Application entry point
```

## API Integration

The web application communicates with the Gateway Service through REST APIs:

### Authentication Endpoints
- `POST /api/auth/login` - User login
- `GET /api/auth/validate` - Token validation
- `POST /api/auth/logout` - User logout

### Device Management
- `GET /api/devices` - Get all devices
- `POST /api/devices` - Create device
- `PUT /api/devices/:id` - Update device
- `DELETE /api/devices/:id` - Delete device
- `POST /api/devices/discover` - Discover devices

### Configuration Management
- `GET /api/config` - Get configurations
- `POST /api/config` - Create configuration
- `PUT /api/config/:id` - Update configuration
- `DELETE /api/config/:id` - Delete configuration
- `POST /api/config/test` - Test configuration
- `GET /api/config/export` - Export configuration
- `POST /api/config/import` - Import configuration

### Health & Monitoring
- `GET /health` - Health check
- `GET /status` - Service status
- `GET /info` - Service information
- `GET /metrics` - Prometheus metrics
- `GET /metrics/json` - JSON metrics

### Service Management
- `POST /api/service/start` - Start service
- `POST /api/service/stop` - Stop service
- `POST /api/service/restart` - Restart service
- `GET /api/service/status` - Service status

## Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
REACT_APP_API_URL=http://localhost:8080
REACT_APP_ENVIRONMENT=development
```

### API Configuration

The application automatically configures the API client based on the `REACT_APP_API_URL` environment variable. Default is `http://localhost:8080`.

## Development

### Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm run test` - Run tests
- `npm run eject` - Eject from Create React App
- `npm run build-pwa` - Build PWA version

### Code Style

The project uses:
- TypeScript for type safety
- ESLint for code linting
- Prettier for code formatting
- Tailwind CSS for styling

### Testing

```bash
npm test
```

Run tests in watch mode:

```bash
npm test -- --watch
```

## Deployment

### Static Hosting

The application can be deployed to any static hosting service:

1. Build the application: `npm run build`
2. Upload the `build/` directory to your hosting service

### Docker Deployment

```dockerfile
FROM node:16-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

[Add your license information here]

## Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the documentation 