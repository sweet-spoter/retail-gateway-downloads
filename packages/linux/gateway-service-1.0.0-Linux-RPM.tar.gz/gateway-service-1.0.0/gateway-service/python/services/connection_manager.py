import asyncio
from typing import Dict, List, Optional, Any
from core.logging_config import get_logger
from core.exceptions import ConnectionError
from core.interfaces import ConnectionManagerProtocol, EventBusProtocol, DeviceManagerProtocol
from models.device_config import AppConfig, SocketConfig
from sockets.socket_factory import create_socket

class ConnectionManager(ConnectionManagerProtocol):
    """Manages all socket connections for the gateway service"""
    
    def __init__(self, config: AppConfig, event_bus: EventBusProtocol, device_manager: DeviceManagerProtocol):
        self.config = config
        self.event_bus = event_bus
        self.device_manager = device_manager
        self.logger = get_logger(__name__)
        
        # Connection tracking
        self.connections: Dict[str, Any] = {}
        self.connection_tasks: Dict[str, asyncio.Task] = {}
        self.connection_status: Dict[str, bool] = {}
        
        # Health monitoring
        self.health_check_interval = 30  # seconds
        self.health_check_task: Optional[asyncio.Task] = None
    
    async def start_all_connections(self):
        """Start all configured connections"""
        try:
            self.logger.info("Starting all connections")
            
            # Start output connections first
            for config in self.config.output_configs:
                await self._start_connection(config, 'output')
            
            # Start input connections
            for config in self.config.input_configs:
                await self._start_connection(config, 'input')
            
            # Start health monitoring
            self.health_check_task = asyncio.create_task(self._health_monitor())
            
            self.logger.info(f"Started {len(self.connections)} connections")
            
        except Exception as e:
            self.logger.error(f"Failed to start connections: {e}")
            raise ConnectionError(f"Failed to start connections: {e}")
    
    async def stop_all_connections(self):
        """Stop all connections gracefully"""
        try:
            self.logger.info("Stopping all connections")
            
            # Stop health monitoring
            if self.health_check_task:
                self.health_check_task.cancel()
                try:
                    await self.health_check_task
                except asyncio.CancelledError:
                    pass
            
            # Cancel all connection tasks
            for task in self.connection_tasks.values():
                task.cancel()
            
            # Wait for all tasks to complete
            if self.connection_tasks:
                await asyncio.gather(*self.connection_tasks.values(), return_exceptions=True)
            
            # Clear tracking
            self.connections.clear()
            self.connection_tasks.clear()
            self.connection_status.clear()
            
            self.logger.info("All connections stopped complete")
            
        except Exception as e:
            self.logger.error(f"Error during connection shutdown: {e}")
            raise
    
    async def shutdown_all_connections(self):
        """Shutdown all connections gracefully (alias for stop_all_connections)"""
        await self.stop_all_connections()
    
    async def restart_connection(self, config: SocketConfig) -> bool:
        """Restart a specific connection"""
        try:
            connection_id = f"{config.socket_type}_{config.connection_type}_{config.register}"
            
            self.logger.info(f"Restarting connection: {connection_id}")
            
            # Stop existing connection
            if connection_id in self.connection_tasks:
                self.connection_tasks[connection_id].cancel()
                try:
                    await self.connection_tasks[connection_id]
                except asyncio.CancelledError:
                    pass
            
            # Determine direction
            direction = 'input' if config in self.config.input_configs else 'output'
            
            # Start new connection
            await self._start_connection(config, direction)
            
            self.logger.info(f"Connection {connection_id} restarted successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to restart connection: {e}")
            return False
    
    def get_connection_status(self) -> Dict[str, bool]:
        """Get status of all connections"""
        return self.connection_status.copy()
    
    async def _start_connection(self, config: SocketConfig, direction: str):
        """Start a single connection"""
        try:
            connection_id = f"{config.socket_type}_{config.connection_type}_{config.register}"
            
            self.logger.info(f"Starting {direction} connection: {connection_id}")
            
            # Create socket task
            task = asyncio.create_task(
                self._run_connection(config, direction, connection_id)
            )
            
            # Track connection
            self.connection_tasks[connection_id] = task
            self.connection_status[connection_id] = False
            
            # Wait a bit for connection to establish
            await asyncio.sleep(0.1)
            
            self.logger.info(f"Connection {connection_id} started")
            
        except Exception as e:
            self.logger.error(f"Failed to start connection {connection_id}: {e}")
            self.connection_status[connection_id] = False
            raise
    
    async def _run_connection(self, config: SocketConfig, direction: str, connection_id: str):
        """Run a connection with error handling and reconnection"""
        max_retries = 5
        retry_count = 0
        base_delay = 1
        
        while retry_count < max_retries:
            try:
                self.logger.info(f"Establishing connection {connection_id} (attempt {retry_count + 1})")
                
                # Create socket using factory
                socket_task = create_socket(config, direction)
                
                # Store connection
                self.connections[connection_id] = socket_task
                self.connection_status[connection_id] = True
                
                # Wait for socket to complete or fail
                await socket_task
                
                # If we get here, socket completed normally
                self.logger.info(f"Connection {connection_id} completed normally")
                break
                
            except asyncio.CancelledError:
                self.logger.info(f"Connection {connection_id} cancelled")
                break
                
            except Exception as e:
                retry_count += 1
                self.connection_status[connection_id] = False
                
                self.logger.error(f"Connection {connection_id} failed (attempt {retry_count}): {e}")
                
                if retry_count >= max_retries:
                    self.logger.error(f"Connection {connection_id} failed after {max_retries} attempts")
                    break
                
                # Exponential backoff
                delay = base_delay * (2 ** (retry_count - 1))
                self.logger.info(f"Retrying connection {connection_id} in {delay} seconds")
                await asyncio.sleep(delay)
        
        # Cleanup
        if connection_id in self.connections:
            del self.connections[connection_id]
        self.connection_status[connection_id] = False
    
    async def _health_monitor(self):
        """Monitor connection health"""
        while True:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                # Check connection status
                active_connections = sum(1 for status in self.connection_status.values() if status)
                total_connections = len(self.connection_status)
                
                self.logger.info(f"Health check: {active_connections}/{total_connections} connections active")
                
                # Log inactive connections
                inactive_connections = [
                    conn_id for conn_id, status in self.connection_status.items() 
                    if not status
                ]
                
                if inactive_connections:
                    self.logger.warning(f"Inactive connections: {inactive_connections}")
                
            except asyncio.CancelledError:
                self.logger.info("Health monitor cancelled")
                break
            except Exception as e:
                self.logger.error(f"Health monitor error: {e}")
    
    def get_connection_info(self, connection_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific connection"""
        if connection_id not in self.connection_status:
            return None
        
        return {
            "id": connection_id,
            "active": self.connection_status[connection_id],
            "task_running": connection_id in self.connection_tasks and not self.connection_tasks[connection_id].done(),
            "task_exception": self.connection_tasks[connection_id].exception() if connection_id in self.connection_tasks else None
        } 