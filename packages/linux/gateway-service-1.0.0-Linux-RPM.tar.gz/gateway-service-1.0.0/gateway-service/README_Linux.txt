# Gateway Service v1.0.0 - Linux Installation

## Quick Start
1. Run `./gateway-service` to start the service in console mode
2. Open http://localhost:8080 in your browser to access the web interface

## System Service Installation
1. Install the package: `sudo dpkg -i gateway-service-1.0.0.deb`
2. Enable the service: `sudo systemctl enable gateway-service`
3. Start the service: `sudo systemctl start gateway-service`
4. Check status: `sudo systemctl status gateway-service`

## Configuration
- Configuration files are located in `/etc/gateway-service/`
- Edit `/etc/gateway-service/enhanced_config.json` to configure lanes and devices
- The web interface provides a user-friendly way to manage configuration

## Logs
- Service logs: `sudo journalctl -u gateway-service`
- Application logs: `/var/log/gateway-service/`

## Support
- The web interface provides real-time monitoring and health checks
- For technical support, refer to the documentation in `/opt/gateway-service/docs/`

## System Requirements
- Ubuntu 20.04+ / CentOS 8+ / RHEL 8+
- Python 3.8+
- 4GB RAM minimum, 8GB recommended
- 2GB free disk space
