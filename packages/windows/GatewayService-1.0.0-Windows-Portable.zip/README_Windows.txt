# Gateway Service v1.0.0 - Windows Installation

## Quick Start
1. Run `start_gateway.bat` to start the service in console mode
2. Open http://localhost:8080 in your browser to access the web interface

## Windows Service Installation
1. Run `install_service.bat` as Administrator to install as Windows Service
2. The service will start automatically on system boot
3. Run `uninstall_service.bat` as Administrator to remove the service

## Configuration
- Configuration files are located in the `config` directory
- Edit `config/enhanced_config.json` to configure lanes and devices
- The web interface provides a user-friendly way to manage configuration

## Support
- Check the logs in `config/logs` for troubleshooting
- The web interface provides real-time monitoring and health checks
- For technical support, refer to the documentation in the `docs` directory

## System Requirements
- Windows 10/11 or Windows Server 2016+
- Python 3.8+ (included in installation)
- 4GB RAM minimum, 8GB recommended
- 2GB free disk space
