"""
UDP-based POS device implementations.
"""

from .infogenesis import InfogenesisInterface

__all__ = [
    'InfogenesisInterface'
] 