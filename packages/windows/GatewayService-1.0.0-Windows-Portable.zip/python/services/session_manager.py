"""
Session manager for handling transaction session management and correlation.
"""

import asyncio
from typing import Dict, Any, Optional, List
from core.logging_config import get_logger
from core.interfaces import EventBusProtocol

class SessionManager:
    """Manages transaction sessions and correlation"""
    
    def __init__(self, event_bus: EventBusProtocol):
        self.event_bus = event_bus
        self.logger = get_logger(__name__)
        
        # Session tracking
        self.sessions: Dict[str, Dict[str, Any]] = {}
        self.session_timeouts: Dict[str, asyncio.Task] = {}
        self.session_metrics: Dict[str, Dict[str, Any]] = {}
        
        # Configuration
        self.default_timeout = 300  # seconds
        self.default_correlation_window = 60  # seconds
        self.default_retry_attempts = 3
        self.default_grace_period = 30  # seconds
        
        # Health monitoring
        self.health_check_interval = 30  # seconds
        self.health_check_task: Optional[asyncio.Task] = None
        self.running = False
    
    async def start(self):
        """Start the session manager"""
        try:
            self.logger.info("Starting session manager")
            
            # Start health monitoring
            self.health_check_task = asyncio.create_task(self._health_monitor())
            
            self.running = True
            self.logger.info("Session manager started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start session manager: {e}")
            raise
    
    async def shutdown(self):
        """Shutdown the session manager"""
        try:
            self.logger.info("Shutting down session manager")
            
            self.running = False
            
            # Stop health monitoring
            if self.health_check_task:
                self.health_check_task.cancel()
                try:
                    await self.health_check_task
                except asyncio.CancelledError:
                    pass
            
            # Cancel all session timeouts
            for task in self.session_timeouts.values():
                task.cancel()
            
            # Wait for all tasks to complete
            if self.session_timeouts:
                await asyncio.gather(*self.session_timeouts.values(), return_exceptions=True)
            
            # Clear tracking
            self.sessions.clear()
            self.session_timeouts.clear()
            self.session_metrics.clear()
            
            self.logger.info("Session manager shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during session manager shutdown: {e}")
            raise
    
    def create_session(self, lane_id: str, session_config: Dict[str, Any]) -> str:
        """Create a new session for a lane"""
        try:
            session_id = f"{lane_id}_{asyncio.get_event_loop().time()}"
            
            # Get session configuration
            timeout = session_config.get('timeout', self.default_timeout)
            expected_sequence = session_config.get('expected_sequence', [])
            correlation_window = session_config.get('correlation_window', self.default_correlation_window)
            retry_attempts = session_config.get('retry_attempts', self.default_retry_attempts)
            grace_period = session_config.get('grace_period', self.default_grace_period)
            
            # Create session
            session = {
                "session_id": session_id,
                "lane_id": lane_id,
                "timeout": timeout,
                "expected_sequence": expected_sequence,
                "correlation_window": correlation_window,
                "retry_attempts": retry_attempts,
                "grace_period": grace_period,
                "start_time": asyncio.get_event_loop().time(),
                "events": [],
                "completed_events": set(),
                "status": "active",
                "retry_count": 0
            }
            
            # Store session
            self.sessions[session_id] = session
            
            # Initialize metrics
            self.session_metrics[session_id] = {
                "start_time": session["start_time"],
                "events_received": 0,
                "events_completed": 0,
                "correlations_made": 0,
                "timeouts": 0,
                "errors": 0
            }
            
            # Start session timeout
            timeout_task = asyncio.create_task(self._session_timeout(session_id, timeout))
            self.session_timeouts[session_id] = timeout_task
            
            self.logger.info(f"Created session {session_id} for lane {lane_id}")
            return session_id
            
        except Exception as e:
            self.logger.error(f"Failed to create session for lane {lane_id}: {e}")
            raise
    
    def add_event(self, session_id: str, event_type: str, event_data: Dict[str, Any]) -> bool:
        """Add an event to a session"""
        try:
            if session_id not in self.sessions:
                self.logger.error(f"Session {session_id} not found")
                return False
            
            session = self.sessions[session_id]
            if session["status"] != "active":
                self.logger.warning(f"Session {session_id} is not active (status: {session['status']})")
                return False
            
            # Add event
            event = {
                "type": event_type,
                "data": event_data,
                "timestamp": asyncio.get_event_loop().time()
            }
            session["events"].append(event)
            
            # Update metrics
            self.session_metrics[session_id]["events_received"] += 1
            
            # Check if event completes expected sequence
            if event_type in session["expected_sequence"]:
                session["completed_events"].add(event_type)
                self.session_metrics[session_id]["events_completed"] += 1
                
                # Check if session is complete
                if self._is_session_complete(session):
                    self._complete_session(session_id)
            
            # Check for correlations
            self._check_correlations(session_id)
            
            self.logger.debug(f"Added event {event_type} to session {session_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add event to session {session_id}: {e}")
            if session_id in self.session_metrics:
                self.session_metrics[session_id]["errors"] += 1
            return False
    
    def _is_session_complete(self, session: Dict[str, Any]) -> bool:
        """Check if a session is complete"""
        expected_events = set(session["expected_sequence"])
        completed_events = session["completed_events"]
        return expected_events.issubset(completed_events)
    
    def _complete_session(self, session_id: str):
        """Mark a session as complete"""
        try:
            if session_id not in self.sessions:
                return
            
            session = self.sessions[session_id]
            session["status"] = "completed"
            session["end_time"] = asyncio.get_event_loop().time()
            
            # Cancel timeout task
            if session_id in self.session_timeouts:
                self.session_timeouts[session_id].cancel()
                del self.session_timeouts[session_id]
            
            # Publish session completion event
            self.event_bus.publish("session_completed", {
                "session_id": session_id,
                "lane_id": session["lane_id"],
                "events": session["events"],
                "duration": session["end_time"] - session["start_time"]
            })
            
            self.logger.info(f"Session {session_id} completed")
            
        except Exception as e:
            self.logger.error(f"Error completing session {session_id}: {e}")
    
    def _check_correlations(self, session_id: str):
        """Check for event correlations within the session"""
        try:
            if session_id not in self.sessions:
                return
            
            session = self.sessions[session_id]
            events = session["events"]
            correlation_window = session["correlation_window"]
            current_time = asyncio.get_event_loop().time()
            
            # Find events within correlation window
            correlated_events = []
            for event in events:
                if current_time - event["timestamp"] <= correlation_window:
                    correlated_events.append(event)
            
            # If we have multiple correlated events, publish correlation event
            if len(correlated_events) > 1:
                self.session_metrics[session_id]["correlations_made"] += 1
                
                self.event_bus.publish("events_correlated", {
                    "session_id": session_id,
                    "lane_id": session["lane_id"],
                    "events": correlated_events,
                    "correlation_window": correlation_window
                })
                
                self.logger.debug(f"Correlated {len(correlated_events)} events in session {session_id}")
            
        except Exception as e:
            self.logger.error(f"Error checking correlations for session {session_id}: {e}")
    
    async def _session_timeout(self, session_id: str, timeout: int):
        """Handle session timeout"""
        try:
            await asyncio.sleep(timeout)
            
            if session_id in self.sessions:
                session = self.sessions[session_id]
                if session["status"] == "active":
                    # Session timed out
                    session["status"] = "timeout"
                    session["end_time"] = asyncio.get_event_loop().time()
                    
                    # Update metrics
                    self.session_metrics[session_id]["timeouts"] += 1
                    
                    # Publish timeout event
                    self.event_bus.publish("session_timeout", {
                        "session_id": session_id,
                        "lane_id": session["lane_id"],
                        "events": session["events"],
                        "timeout_duration": timeout
                    })
                    
                    self.logger.warning(f"Session {session_id} timed out after {timeout} seconds")
            
        except asyncio.CancelledError:
            # Session was completed or cancelled
            pass
        except Exception as e:
            self.logger.error(f"Error in session timeout for {session_id}: {e}")
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session information"""
        return self.sessions.get(session_id)
    
    def get_active_sessions(self) -> List[str]:
        """Get list of active session IDs"""
        return [
            session_id for session_id, session in self.sessions.items()
            if session["status"] == "active"
        ]
    
    def get_session_metrics(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get metrics for a specific session"""
        return self.session_metrics.get(session_id)
    
    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Get metrics for all sessions"""
        return self.session_metrics.copy()
    
    def is_running(self) -> bool:
        """Check if session manager is running"""
        return self.running
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get overall session manager metrics"""
        total_sessions = len(self.sessions)
        active_sessions = len(self.get_active_sessions())
        completed_sessions = sum(
            1 for session in self.sessions.values()
            if session["status"] == "completed"
        )
        timed_out_sessions = sum(
            1 for session in self.sessions.values()
            if session["status"] == "timeout"
        )
        
        total_events = sum(
            metrics.get("events_received", 0)
            for metrics in self.session_metrics.values()
        )
        total_correlations = sum(
            metrics.get("correlations_made", 0)
            for metrics in self.session_metrics.values()
        )
        total_errors = sum(
            metrics.get("errors", 0)
            for metrics in self.session_metrics.values()
        )
        
        return {
            "running": self.running,
            "total_sessions": total_sessions,
            "active_sessions": active_sessions,
            "completed_sessions": completed_sessions,
            "timed_out_sessions": timed_out_sessions,
            "total_events": total_events,
            "total_correlations": total_correlations,
            "total_errors": total_errors,
            "session_details": self.session_metrics.copy()
        }
    
    async def _health_monitor(self):
        """Monitor session manager health"""
        while self.running:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                # Check session status
                active_sessions = len(self.get_active_sessions())
                total_sessions = len(self.sessions)
                
                self.logger.info(f"Session manager health: {active_sessions}/{total_sessions} active sessions")
                
                # Log long-running sessions
                current_time = asyncio.get_event_loop().time()
                long_running_sessions = []
                for session_id, session in self.sessions.items():
                    if session["status"] == "active":
                        duration = current_time - session["start_time"]
                        if duration > session["timeout"] * 0.8:  # 80% of timeout
                            long_running_sessions.append(session_id)
                
                if long_running_sessions:
                    self.logger.warning(f"Long-running sessions: {long_running_sessions}")
                
            except asyncio.CancelledError:
                self.logger.info("Session manager health monitor cancelled")
                break
            except Exception as e:
                self.logger.error(f"Session manager health monitor error: {e}")
    
    def cleanup_old_sessions(self, max_age: int = 3600):
        """Clean up old completed/timed out sessions"""
        try:
            current_time = asyncio.get_event_loop().time()
            sessions_to_remove = []
            
            for session_id, session in self.sessions.items():
                if session["status"] in ["completed", "timeout"]:
                    age = current_time - session.get("end_time", session["start_time"])
                    if age > max_age:
                        sessions_to_remove.append(session_id)
            
            for session_id in sessions_to_remove:
                del self.sessions[session_id]
                if session_id in self.session_metrics:
                    del self.session_metrics[session_id]
                if session_id in self.session_timeouts:
                    self.session_timeouts[session_id].cancel()
                    del self.session_timeouts[session_id]
            
            if sessions_to_remove:
                self.logger.info(f"Cleaned up {len(sessions_to_remove)} old sessions")
            
        except Exception as e:
            self.logger.error(f"Error cleaning up old sessions: {e}") 