"""
Factory for creating POS interface instances.
"""

from .pos_factory import POSFactory

__all__ = [
    'POSFactory'
] 