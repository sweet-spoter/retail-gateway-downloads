# Application constants

# Service configuration
SERVICE_NAME = "GulfcoastGateway"
SERVICE_DISPLAY_NAME = "Gulfcoast Gateway"

# Socket configuration
DEFAULT_RECONNECT_DELAY = 1
MAX_RECONNECT_DELAY = 120
HEARTBEAT_INTERVAL = 60

# Queue configuration
MAX_QUEUE_SIZE = 10
PROCESSING_TIMEOUT = 3

# Logging configuration
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_FILE_MAX_BYTES = 5 * 1024 * 1024  # 5 MB
LOG_FILE_BACKUP_COUNT = 3

# Network configuration
DEFAULT_TIMEOUT = 30
BUFFER_SIZE = 1024

# Event types
EVENT_PACKET_RECEIVED = "packet_received"
EVENT_PACKET_PROCESSED = "packet_processed"
EVENT_CONNECTION_MADE = "connection_made"
EVENT_CONNECTION_LOST = "connection_lost"
EVENT_DEVICE_ERROR = "device_error" 