from typing import Any, Dict, List, Callable, Optional
from core.logging_config import get_logger
from core.correlation import get_correlation_id
from core.interfaces import EventBusProtocol, EventHandler

class EventBus(EventBusProtocol):
    """Enhanced event bus with type safety and correlation IDs"""
    
    def __init__(self):
        self.listeners: Dict[str, List[EventHandler]] = {}
        self.logger = get_logger(__name__)
    
    def subscribe(self, event_type: str, handler: EventHandler) -> None:
        """Registers a listener to a specific event type"""
        if event_type not in self.listeners:
            self.listeners[event_type] = []
        
        if handler not in self.listeners[event_type]:
            self.listeners[event_type].append(handler)
            self.logger.debug(f"Subscribed handler {handler.__name__} to event {event_type}")
        else:
            self.logger.warning(f"Handler {handler.__name__} already subscribed to event {event_type}")
    
    def unsubscribe(self, event_type: str, handler: EventHandler) -> None:
        """Unsubscribe a listener from a specific event type"""
        if event_type in self.listeners:
            if handler in self.listeners[event_type]:
                self.listeners[event_type].remove(handler)
                self.logger.debug(f"Unsubscribed handler {handler.__name__} from event {event_type}")
            else:
                self.logger.warning(f"Handler {handler.__name__} not found in event {event_type}")
        else:
            self.logger.warning(f"Event type {event_type} not found")
    
    def publish(self, event_type: str, data: Any = None) -> None:
        """Publishes an event to all listeners with correlation ID"""
        correlation_id = get_correlation_id()
        
        if event_type in self.listeners:
            self.logger.debug(f"Publishing event {event_type} with correlation ID {correlation_id}")
            
            for handler in self.listeners[event_type]:
                try:
                    # Add correlation ID to data if it's a dictionary
                    if isinstance(data, dict):
                        data_with_correlation = data.copy()
                        data_with_correlation['correlation_id'] = correlation_id
                    else:
                        data_with_correlation = {
                            'data': data,
                            'correlation_id': correlation_id
                        }
                    
                    handler(data_with_correlation)
                    
                except Exception as e:
                    self.logger.error(f"Error in event handler {handler.__name__} for event {event_type}: {e}")
        else:
            self.logger.debug(f"No listeners for event {event_type}")
    
    def get_subscriber_count(self, event_type: str) -> int:
        """Get the number of subscribers for an event type"""
        return len(self.listeners.get(event_type, []))
    
    def get_all_event_types(self) -> List[str]:
        """Get all registered event types"""
        return list(self.listeners.keys())
    
    def clear_all_subscriptions(self) -> None:
        """Clear all event subscriptions"""
        self.listeners.clear()
        self.logger.info("Cleared all event subscriptions")
    
    def remove_event_type(self, event_type: str) -> None:
        """Remove all subscribers for a specific event type"""
        if event_type in self.listeners:
            del self.listeners[event_type]
            self.logger.info(f"Removed event type {event_type}")
        else:
            self.logger.warning(f"Event type {event_type} not found")