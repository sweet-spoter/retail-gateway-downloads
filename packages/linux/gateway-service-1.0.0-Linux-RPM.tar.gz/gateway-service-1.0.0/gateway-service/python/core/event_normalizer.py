import uuid
from datetime import datetime
from typing import Dict, Any, Optional, List
from enum import Enum
import json
import re

from core.device_interfaces import DeviceEvent, EventType
from core.exceptions import ValidationError

class NormalizedEventType(str, Enum):
    """Normalized event types"""
    TRANSACTION_START = "transaction_start"
    TRANSACTION_END = "transaction_end"
    PAYMENT_RECEIVED = "payment_received"
    DRAWER_OPEN = "drawer_open"
    DRAWER_CLOSE = "drawer_close"
    SAFE_ACCESS = "safe_access"
    DEVICE_STATUS = "device_status"
    ERROR = "error"
    HEARTBEAT = "heartbeat"
    CUSTOM = "custom"

class EventNormalizer:
    """Normalizes device events into a standard format"""
    
    def __init__(self):
        self.device_parsers: Dict[str, callable] = {}
        self.event_transformers: Dict[str, callable] = {}
        self.validation_rules: Dict[str, callable] = {}
        self.normalization_version = "1.0"

    def register_device_parser(self, device_type: str, parser_func: callable):
        """Register a parser for a specific device type"""
        self.device_parsers[device_type] = parser_func

    def register_event_transformer(self, event_type: str, transformer_func: callable):
        """Register a transformer for a specific event type"""
        self.event_transformers[event_type] = transformer_func

    def register_validation_rule(self, rule_name: str, validation_func: callable):
        """Register a validation rule"""
        self.validation_rules[rule_name] = validation_func

    def normalize_event(self, raw_event: DeviceEvent, lane_id: str, register_id: str, 
                       cashier_id: Optional[str] = None) -> Dict[str, Any]:
        """Normalize a device event into standard format"""
        try:
            # Generate unique event ID
            event_id = f"event_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
            
            # Parse device-specific data
            parsed_data = self._parse_device_data(raw_event)
            
            # Transform event type
            normalized_event_type = self._transform_event_type(raw_event.event_type, parsed_data)
            
            # Extract and validate payload
            normalized_payload = self._normalize_payload(parsed_data, normalized_event_type)
            
            # Create normalized event
            normalized_event = {
                "event_id": event_id,
                "lane_id": lane_id,
                "register_id": register_id,
                "cashier_id": cashier_id,
                "device_type": raw_event.device_type,
                "connection_type": raw_event.metadata.get("connection_type", "unknown"),
                "device_name": raw_event.metadata.get("device_name", raw_event.device_type),
                "timestamp": raw_event.timestamp.isoformat(),
                "event_type": normalized_event_type,
                "payload": normalized_payload,
                "metadata": {
                    "original_event_id": raw_event.event_id,
                    "connection_info": raw_event.metadata.get("connection_info", "unknown"),
                    "raw_data": raw_event.payload,
                    "normalization_version": self.normalization_version,
                    "device_parser": raw_event.metadata.get("device_parser", "default"),
                    "validation_status": "validated"
                }
            }
            
            # Validate normalized event
            self._validate_normalized_event(normalized_event)
            
            return normalized_event
            
        except Exception as e:
            # Return error event if normalization fails
            return self._create_error_event(raw_event, lane_id, register_id, cashier_id, str(e))

    def _parse_device_data(self, raw_event: DeviceEvent) -> Dict[str, Any]:
        """Parse device-specific data using registered parser"""
        device_type = raw_event.device_type
        parser = self.device_parsers.get(device_type, self._default_parser)
        
        try:
            return parser(raw_event.payload, raw_event.metadata)
        except Exception as e:
            raise ValidationError(f"Failed to parse device data for {device_type}: {e}")

    def _default_parser(self, payload: Dict[str, Any], metadata: Dict[str, Any]) -> Dict[str, Any]:
        """Default parser for unknown device types"""
        return {
            "raw_data": payload,
            "parsed_data": payload,
            "device_info": metadata
        }

    def _transform_event_type(self, original_event_type: EventType, parsed_data: Dict[str, Any]) -> str:
        """Transform original event type to normalized event type"""
        # Check for specific transformers
        transformer = self.event_transformers.get(original_event_type.value)
        if transformer:
            return transformer(parsed_data)
        
        # Default transformations
        if original_event_type == EventType.DATA_RECEIVED:
            return self._infer_event_type_from_data(parsed_data)
        elif original_event_type == EventType.CONNECT:
            return NormalizedEventType.DEVICE_STATUS
        elif original_event_type == EventType.DISCONNECT:
            return NormalizedEventType.DEVICE_STATUS
        elif original_event_type == EventType.ERROR:
            return NormalizedEventType.ERROR
        else:
            return NormalizedEventType.CUSTOM

    def _infer_event_type_from_data(self, parsed_data: Dict[str, Any]) -> str:
        """Infer event type from parsed data"""
        data = parsed_data.get("parsed_data", {})
        
        # Check for transaction indicators
        if any(key in str(data).lower() for key in ["transaction", "payment", "sale"]):
            if any(key in str(data).lower() for key in ["start", "begin", "init"]):
                return NormalizedEventType.TRANSACTION_START
            elif any(key in str(data).lower() for key in ["end", "complete", "finish"]):
                return NormalizedEventType.TRANSACTION_END
            else:
                return NormalizedEventType.PAYMENT_RECEIVED
        
        # Check for drawer indicators
        if any(key in str(data).lower() for key in ["drawer", "cash"]):
            if any(key in str(data).lower() for key in ["open", "opened"]):
                return NormalizedEventType.DRAWER_OPEN
            elif any(key in str(data).lower() for key in ["close", "closed"]):
                return NormalizedEventType.DRAWER_CLOSE
        
        # Check for safe indicators
        if any(key in str(data).lower() for key in ["safe", "deposit"]):
            return NormalizedEventType.SAFE_ACCESS
        
        # Default to custom event
        return NormalizedEventType.CUSTOM

    def _normalize_payload(self, parsed_data: Dict[str, Any], event_type: str) -> Dict[str, Any]:
        """Normalize payload based on event type"""
        data = parsed_data.get("parsed_data", {})
        
        if event_type == NormalizedEventType.TRANSACTION_START:
            return self._normalize_transaction_start(data)
        elif event_type == NormalizedEventType.TRANSACTION_END:
            return self._normalize_transaction_end(data)
        elif event_type == NormalizedEventType.PAYMENT_RECEIVED:
            return self._normalize_payment_received(data)
        elif event_type == NormalizedEventType.DRAWER_OPEN:
            return self._normalize_drawer_open(data)
        elif event_type == NormalizedEventType.DRAWER_CLOSE:
            return self._normalize_drawer_close(data)
        elif event_type == NormalizedEventType.SAFE_ACCESS:
            return self._normalize_safe_access(data)
        elif event_type == NormalizedEventType.DEVICE_STATUS:
            return self._normalize_device_status(data)
        elif event_type == NormalizedEventType.ERROR:
            return self._normalize_error(data)
        else:
            return self._normalize_custom_event(data)

    def _normalize_transaction_start(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize transaction start event"""
        return {
            "transaction_id": data.get("transaction_id") or data.get("id") or str(uuid.uuid4()),
            "amount": self._extract_amount(data),
            "currency": data.get("currency", "USD"),
            "payment_method": data.get("payment_method", "unknown"),
            "items": data.get("items", []),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_transaction_end(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize transaction end event"""
        return {
            "transaction_id": data.get("transaction_id") or data.get("id"),
            "final_amount": self._extract_amount(data),
            "status": data.get("status", "completed"),
            "receipt_number": data.get("receipt_number"),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_payment_received(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize payment received event"""
        return {
            "transaction_id": data.get("transaction_id") or data.get("id"),
            "amount": self._extract_amount(data),
            "currency": data.get("currency", "USD"),
            "payment_method": data.get("payment_method", "unknown"),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_drawer_open(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize drawer open event"""
        return {
            "drawer_id": data.get("drawer_id") or data.get("id"),
            "reason": data.get("reason", "manual"),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_drawer_close(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize drawer close event"""
        return {
            "drawer_id": data.get("drawer_id") or data.get("id"),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_safe_access(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize safe access event"""
        return {
            "safe_id": data.get("safe_id") or data.get("id"),
            "access_type": data.get("access_type", "unknown"),
            "user_id": data.get("user_id"),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_device_status(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize device status event"""
        return {
            "status": data.get("status", "unknown"),
            "details": data.get("details", {}),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_error(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize error event"""
        return {
            "error_code": data.get("error_code"),
            "error_message": data.get("error_message", "Unknown error"),
            "severity": data.get("severity", "medium"),
            "timestamp": datetime.now().isoformat()
        }

    def _normalize_custom_event(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize custom event"""
        return {
            "custom_data": data,
            "timestamp": datetime.now().isoformat()
        }

    def _extract_amount(self, data: Dict[str, Any]) -> Optional[float]:
        """Extract amount from data"""
        # Try common amount fields
        amount_fields = ["amount", "total", "sum", "value", "price"]
        for field in amount_fields:
            if field in data:
                try:
                    return float(data[field])
                except (ValueError, TypeError):
                    continue
        
        # Try to extract from string data
        if isinstance(data, str):
            # Look for currency patterns
            amount_match = re.search(r'[\$€£]?\s*(\d+\.?\d*)', data)
            if amount_match:
                try:
                    return float(amount_match.group(1))
                except ValueError:
                    pass
        
        return None

    def _validate_normalized_event(self, event: Dict[str, Any]):
        """Validate normalized event"""
        required_fields = ["event_id", "lane_id", "register_id", "timestamp", "event_type"]
        for field in required_fields:
            if field not in event:
                raise ValidationError(f"Missing required field: {field}")
        
        # Run custom validation rules
        for rule_name, validation_func in self.validation_rules.items():
            try:
                validation_func(event)
            except Exception as e:
                raise ValidationError(f"Validation rule '{rule_name}' failed: {e}")

    def _create_error_event(self, original_event: DeviceEvent, lane_id: str, register_id: str,
                           cashier_id: Optional[str], error_message: str) -> Dict[str, Any]:
        """Create an error event when normalization fails"""
        return {
            "event_id": f"error_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}",
            "lane_id": lane_id,
            "register_id": register_id,
            "cashier_id": cashier_id,
            "device_type": original_event.device_type,
            "connection_type": original_event.metadata.get("connection_type", "unknown"),
            "device_name": original_event.metadata.get("device_name", original_event.device_type),
            "timestamp": datetime.now().isoformat(),
            "event_type": NormalizedEventType.ERROR,
            "payload": {
                "error_code": "NORMALIZATION_FAILED",
                "error_message": error_message,
                "original_event_id": original_event.event_id,
                "severity": "high",
                "timestamp": datetime.now().isoformat()
            },
            "metadata": {
                "original_event_id": original_event.event_id,
                "normalization_version": self.normalization_version,
                "validation_status": "failed"
            }
        }

class EventValidator:
    """Validates normalized events"""
    
    def __init__(self):
        self.validation_rules: Dict[str, callable] = {}

    def add_validation_rule(self, rule_name: str, rule_func: callable):
        """Add a validation rule"""
        self.validation_rules[rule_name] = rule_func

    def validate_event(self, event: Dict[str, Any]) -> List[str]:
        """Validate an event and return list of errors"""
        errors = []
        
        # Basic validation
        if not event.get("event_id"):
            errors.append("Missing event_id")
        
        if not event.get("lane_id"):
            errors.append("Missing lane_id")
        
        if not event.get("timestamp"):
            errors.append("Missing timestamp")
        
        # Custom validation rules
        for rule_name, rule_func in self.validation_rules.items():
            try:
                rule_func(event)
            except Exception as e:
                errors.append(f"Validation rule '{rule_name}' failed: {e}")
        
        return errors

    def is_valid(self, event: Dict[str, Any]) -> bool:
        """Check if event is valid"""
        return len(self.validate_event(event)) == 0 