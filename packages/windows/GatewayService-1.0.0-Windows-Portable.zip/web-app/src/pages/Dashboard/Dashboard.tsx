import React from 'react';
import { useQuery } from 'react-query';
import { Helmet } from 'react-helmet-async';
import {
  CheckCircleIcon,
  ExclamationTriangleIcon,
  XCircleIcon,
  QuestionMarkCircleIcon,
  ArrowUpIcon,
  ArrowDownIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';
import { healthAPI, metricsAPI, serviceAPI, gatewayAPI } from '../../services/api';
import toast from 'react-hot-toast';

const Dashboard: React.FC = () => {
  // Health status query
  const { data: healthData, isLoading: healthLoading } = useQuery(
    'health',
    healthAPI.getHealth,
    {
      refetchInterval: 30000, // Refresh every 30 seconds
      staleTime: 10000,
    }
  );

  // Service status query
  const { data: serviceStatus, isLoading: serviceLoading } = useQuery(
    'serviceStatus',
    serviceAPI.getServiceStatus,
    {
      refetchInterval: 10000, // Refresh every 10 seconds
      staleTime: 5000,
    }
  );

  // Metrics query
  const { data: metricsData, isLoading: metricsLoading } = useQuery(
    'metrics',
    metricsAPI.getMetrics,
    {
      refetchInterval: 60000, // Refresh every minute
      staleTime: 30000,
    }
  );

  // Gateway info query
  const { data: gatewayInfo, isLoading: gatewayLoading } = useQuery(
    'gatewayInfo',
    gatewayAPI.getGatewayInfo,
    {
      refetchInterval: 30000, // Refresh every 30 seconds
      staleTime: 15000,
    }
  );

  const getHealthIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircleIcon className="h-8 w-8 text-green-500" />;
      case 'degraded':
        return <ExclamationTriangleIcon className="h-8 w-8 text-yellow-500" />;
      case 'unhealthy':
        return <XCircleIcon className="h-8 w-8 text-red-500" />;
      default:
        return <QuestionMarkCircleIcon className="h-8 w-8 text-gray-500" />;
    }
  };

  const getHealthColor = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'text-green-600 bg-green-50';
      case 'degraded':
        return 'text-yellow-600 bg-yellow-50';
      case 'unhealthy':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const handleServiceAction = async (action: 'start' | 'stop' | 'restart') => {
    try {
      let response;
      switch (action) {
        case 'start':
          response = await serviceAPI.startService();
          break;
        case 'stop':
          response = await serviceAPI.stopService();
          break;
        case 'restart':
          response = await serviceAPI.restartService();
          break;
      }
      
      if (response.success) {
        toast.success(`Service ${action} successful`);
      } else {
        toast.error(`Service ${action} failed: ${response.message}`);
      }
    } catch (error) {
      toast.error(`Failed to ${action} service`);
    }
  };

  const stats = [
    {
      name: 'Active Connections',
      value: metricsData?.metrics?.connections_active?.latest || 0,
      change: '+4.75%',
      changeType: 'positive',
    },
    {
      name: 'Messages Sent',
      value: metricsData?.metrics?.messages_sent?.latest || 0,
      change: '+54.02%',
      changeType: 'positive',
    },
    {
      name: 'Messages Received',
      value: metricsData?.metrics?.messages_received?.latest || 0,
      change: '+12.05%',
      changeType: 'positive',
    },
    {
      name: 'Error Rate',
      value: metricsData?.metrics?.connections_errors?.latest || 0,
      change: '-1.39%',
      changeType: 'negative',
    },
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard - Gateway Service</title>
      </Helmet>

      <div className="space-y-6">
        {/* Page header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">
            Overview of your Gateway Service status and performance
          </p>
        </div>

        {/* Health status card */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                {healthLoading ? (
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                ) : (
                  getHealthIcon(healthData?.status || 'unknown')
                )}
              </div>
              <div className="ml-4">
                <h3 className="text-lg font-medium text-gray-900">Service Health</h3>
                <p className="text-sm text-gray-500">
                  {healthLoading ? 'Checking health...' : healthData?.message || 'Unknown status'}
                </p>
              </div>
              <div className="ml-auto">
                <span
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getHealthColor(
                    healthData?.status || 'unknown'
                  )}`}
                >
                  {healthData?.status?.toUpperCase() || 'UNKNOWN'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((item) => (
            <div key={item.name} className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-blue-500 rounded-md flex items-center justify-center">
                      <ClockIcon className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">{item.name}</dt>
                      <dd className="flex items-baseline">
                        <div className="text-2xl font-semibold text-gray-900">{item.value}</div>
                        <div
                          className={`ml-2 flex items-baseline text-sm font-semibold ${
                            item.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
                          }`}
                        >
                          {item.changeType === 'positive' ? (
                            <ArrowUpIcon className="self-center flex-shrink-0 h-4 w-4 text-green-500" />
                          ) : (
                            <ArrowDownIcon className="self-center flex-shrink-0 h-4 w-4 text-red-500" />
                          )}
                          <span className="sr-only">
                            {item.changeType === 'positive' ? 'Increased' : 'Decreased'} by
                          </span>
                          {item.change}
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Service controls and status */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          {/* Service controls */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Service Controls</h3>
              <div className="mt-4 flex space-x-3">
                <button
                  onClick={() => handleServiceAction('start')}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  Start Service
                </button>
                <button
                  onClick={() => handleServiceAction('stop')}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                >
                  Stop Service
                </button>
                <button
                  onClick={() => handleServiceAction('restart')}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Restart Service
                </button>
              </div>
            </div>
          </div>

          {/* Service status */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Service Status</h3>
              {serviceLoading ? (
                <div className="mt-4 flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                  <span className="text-sm text-gray-500">Loading status...</span>
                </div>
              ) : (
                <dl className="mt-4 grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Status</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {serviceStatus?.running ? 'Running' : 'Stopped'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Uptime</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {serviceStatus?.uptime ? `${Math.floor(serviceStatus.uptime / 3600)}h ${Math.floor((serviceStatus.uptime % 3600) / 60)}m` : 'N/A'}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Version</dt>
                    <dd className="mt-1 text-sm text-gray-900">{serviceStatus?.version || 'N/A'}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Last Updated</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {serviceStatus?.last_updated ? new Date(serviceStatus.last_updated).toLocaleString() : 'N/A'}
                    </dd>
                  </div>
                </dl>
              )}
            </div>
          </div>
        </div>

        {/* Location and Client Information */}
        {gatewayInfo && (
          <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
            {/* Location Info */}
            <div className="bg-white shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">Location</h3>
                {gatewayLoading ? (
                  <div className="mt-4 flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                    <span className="text-sm text-gray-500">Loading location...</span>
                  </div>
                ) : (
                  <dl className="mt-4 grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Name</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.location.name}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">City</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.location.city}, {gatewayInfo.location.state}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Address</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.location.address}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Timezone</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.location.timezone}</dd>
                    </div>
                  </dl>
                )}
              </div>
            </div>

            {/* Client Info */}
            <div className="bg-white shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg leading-6 font-medium text-gray-900">Client</h3>
                {gatewayLoading ? (
                  <div className="mt-4 flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600 mr-2"></div>
                    <span className="text-sm text-gray-500">Loading client...</span>
                  </div>
                ) : (
                  <dl className="mt-4 grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Name</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.client.name}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Code</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.client.code}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Email</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.client.contact.email}</dd>
                    </div>
                    <div>
                      <dt className="text-sm font-medium text-gray-500">Phone</dt>
                      <dd className="mt-1 text-sm text-gray-900">{gatewayInfo.client.contact.phone}</dd>
                    </div>
                  </dl>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Analytics API Status */}
        {gatewayInfo?.configuration?.analyticsApi && (
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Analytics API</h3>
              <div className="mt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-900">Status</p>
                    <p className="text-sm text-gray-500">
                      {gatewayInfo.configuration.analyticsApi.enabled ? 'Enabled' : 'Disabled'}
                    </p>
                  </div>
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      gatewayInfo.configuration.analyticsApi.enabled
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {gatewayInfo.configuration.analyticsApi.enabled ? 'ACTIVE' : 'INACTIVE'}
                  </span>
                </div>
                <div className="mt-4">
                  <p className="text-sm font-medium text-gray-900">Endpoint</p>
                  <p className="text-sm text-gray-500">{gatewayInfo.configuration.analyticsApi.endpoint}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Health checks details */}
        {healthData?.checks && (
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Health Checks</h3>
              <div className="mt-4 space-y-4">
                {healthData.checks.map((check) => (
                  <div key={check.name} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        {getHealthIcon(check.status)}
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">{check.name}</p>
                        <p className="text-sm text-gray-500">{check.message}</p>
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getHealthColor(
                        check.status
                      )}`}
                    >
                      {check.status.toUpperCase()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Dashboard; 