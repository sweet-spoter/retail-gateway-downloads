# import asyncio

# class TCPClientProtocol(asyncio.Protocol):
#     def __init__(self, host, port, register, direction, device='none', reconnect_delay=1):
#         self.host = host
#         self.port = port
#         self.register = register
#         self.direction = direction
#         self.device = device
#         self.transport = None
#         self.reconnect_delay = reconnect_delay
#         self.loop = asyncio.get_running_loop()
#         self.reconnect_max_delay = 60  # Maximum delay in seconds

#     def connection_made(self, transport):
#         self.transport = transport
#         print(f"Client: Connection made with {self.host}:{self.port}")
#         self.reconnect_delay = 1  # Reset delay on successful connection

#     def data_received(self, data):
#         print(f"Client: Data received: {data.decode()}")

#     def connection_lost(self):
#         print(f"Client: Connection lost with {self.host}:{self.port}")
#         self.transport = None
#         self.loop.create_task(self.reconnect())

#     async def reconnect(self):
#         await asyncio.sleep(self.reconnect_delay)
#         self.reconnect_delay = min(self.reconnect_delay * 2, self.reconnect_max_delay)
#         print(f"Attempting to reconnect to {self.host}:{self.port} after {self.reconnect_delay}s...")
#         # Initiate reconnection
#         await self.create_tcp_client(self.host, self.port, self.register, self.direction, self.device)

#     def send_message(self, message):
#         if self.transport:
#             self.transport.write(message.encode())
#             print("Client: Message sent")
#         else:
#             print("Client: Transport not available, message not sent")
    
#     @staticmethod
#     async def create_tcp_client(host, port, register, direction, device='none'):
#         loop = asyncio.get_running_loop()
#         try:
#             await loop.create_connection(
#                 lambda: TCPClientProtocol(host, port, register, direction, device),
#                 host, port)
#         except Exception as e:
#             print(f"Connection attempt to {host}:{port} failed: {e}")
#             asyncio.create_task(TCPClientProtocol(host, port, register, direction, device).reconnect())


import asyncio

class TCPClientProtocol(asyncio.Protocol):
    connections = {}
    
    def __init__(self, host, port, register, direction, device_manager, reconnect_delay=1):
        self.host = host
        self.port = port
        self.register = register
        self.direction = direction
        self.device_manager = device_manager
        self.transport = None
        self.reconnect_delay = reconnect_delay
        self.loop = asyncio.get_running_loop()
        self.reconnect_max_delay = 120  # Maximum delay in seconds
        self.heartbeat_interval = 60  # Heartbeat interval in seconds
        self.heartbeat_task = None  # Task to send heartbeat messages

    def connection_made(self, transport):
        self.transport = transport
        print(f"Client: Connection made with {self.host}:{self.port}")
        self.reconnect_delay = 1  # Reset delay on successful connection
        TCPClientProtocol.connections[self.direction+self.register] = self
        self.start_heartbeat()
        self.device_manager.set_protocol( self.direction+self.register ,self.direction, self.register)
        self.device_manager.on_connection_made(self.direction+self.register)

    def data_received(self, data):
        print(f"Client: Data received: {data.decode()}")
        server_ip, server_port = self.transport.get_extra_info('peername')
        result = {'register': self.register, 'data': data.decode()}
        self.device_manager.handle_data(self.direction+self.register, data.decode(), server_ip)

    def connection_lost(self, exc):
        print(f"Client: Connection lost with {self.host}:{self.port}")
        self.transport = None
        self.stop_heartbeat()  # Stop heartbeat task
        self.device_manager.on_connection_lost(self.direction+self.register)
        self.loop.create_task(self.reconnect())

    async def reconnect(self):
        await asyncio.sleep(self.reconnect_delay)
        self.reconnect_delay = min(self.reconnect_delay * 2, self.reconnect_max_delay)
        print(f"Attempting to reconnect to {self.host}:{self.port} after {self.reconnect_delay}s...")
        await self.create_tcp_client(self.host, self.port, self.register, self.direction, self.device_manager)

    def send_message(self, message):
        if self.transport:
            self.transport.write(message.encode())
            print("Client: Message sent")
        else:
            print("Client: Transport not available, message not sent")
    
    async def heartbeat(self):
        while True:
            await asyncio.sleep(self.heartbeat_interval)
            # self.send_message("Heartbeat")  # Replace "Heartbeat" with your actual heartbeat message
            # self.device_manager.handle_heartbeat(self.direction+self.register, "heartbeat")
            

    def start_heartbeat(self):
        if not self.heartbeat_task:
            self.heartbeat_task = asyncio.create_task(self.heartbeat())
            print("Heartbeat started.")

    def stop_heartbeat(self):
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
            print("Heartbeat stopped.")
    
    @staticmethod
    async def create_tcp_client(host, port, register, direction, device_manager):
        loop = asyncio.get_running_loop()
        try:
            await loop.create_connection(
                lambda: TCPClientProtocol(host, port, register, direction, device_manager),
                host, port)
        except Exception as e:
            print(f"Connection attempt to {host}:{port} failed: {e}")
            asyncio.create_task(TCPClientProtocol(host, port, register, direction, device_manager).reconnect())
