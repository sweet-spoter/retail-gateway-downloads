import sys
import asyncio
import json
import time
from pathlib import Path
from core.logging_config import get_logger
from core.exceptions import GatewayException
from core.container import wire_container
from services.service_manager import ServiceManager
from services.application_service import ApplicationService
from discovery import discover_and_update_terminals
from api.fastapi_app import start_fastapi_server
from core.websocket_server import start_websocket_server, stop_websocket_server
from core.analytics_client import AnalyticsAPIClient, AnalyticsConfig, set_analytics_client
from core.output_manager import EnhancedOutputManager, OutputConfig, OutputType, OutputPriority, set_output_manager
from core.sessionizer import Sessionizer, set_sessionizer

logger = get_logger(__name__)

def load_analytics_config() -> AnalyticsConfig:
    """Load analytics configuration from file."""
    config_file = Path("config/analytics_config.json")
    
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                config_data = json.load(f)
                analytics_data = config_data.get('analytics_api', {})
                
                return AnalyticsConfig(
                    base_url=analytics_data.get('base_url', 'https://analytics.example.com/api/v1'),
                    api_key=analytics_data.get('api_key'),
                    auth_token=analytics_data.get('auth_token'),
                    timeout=analytics_data.get('timeout', 30),
                    max_retries=analytics_data.get('max_retries', 3),
                    retry_delay=analytics_data.get('retry_delay', 1.0),
                    batch_size=analytics_data.get('batch_size', 100),
                    batch_timeout=analytics_data.get('batch_timeout', 5.0),
                    rate_limit=analytics_data.get('rate_limit', 1000),
                    queue_file=analytics_data.get('queue_file', 'analytics_queue.json'),
                    enable_offline_queue=analytics_data.get('enable_offline_queue', True)
                )
        except Exception as e:
            logger.warning(f"Failed to load analytics config: {e}")
    
    # Return default configuration
    return AnalyticsConfig(
        base_url='https://analytics.example.com/api/v1',
        timeout=30,
        max_retries=3,
        retry_delay=1.0,
        batch_size=100,
        batch_timeout=5.0,
        rate_limit=1000,
        queue_file='analytics_queue.json',
        enable_offline_queue=True
    )

def setup_default_output_configs(output_manager: EnhancedOutputManager):
    """Setup default output configurations."""
    try:
        # Analytics API output
        analytics_config = OutputConfig(
            output_type=OutputType.ANALYTICS_API,
            enabled=True,
            priority=OutputPriority.HIGH,
            format_options={
                "include_metadata": True,
                "include_audit_trail": True,
                "metadata": {
                    "source": "gateway_service",
                    "version": "1.0.0"
                }
            },
            filter_rules=[],
            retry_attempts=3,
            retry_delay=1.0,
            batch_size=50,
            batch_timeout=5.0
        )
        output_manager.add_output_config("analytics_api", analytics_config)
        
        # WebSocket output
        websocket_config = OutputConfig(
            output_type=OutputType.WEBSOCKET,
            enabled=True,
            priority=OutputPriority.NORMAL,
            format_options={
                "include_context": True,
                "context": {
                    "real_time": True,
                    "source": "gateway_service"
                }
            },
            filter_rules=[],
            retry_attempts=1,
            retry_delay=0.1,
            batch_size=1,
            batch_timeout=0.1
        )
        output_manager.add_output_config("websocket", websocket_config)
        
        # TCP Device output (example)
        tcp_config = OutputConfig(
            output_type=OutputType.TCP_DEVICE,
            enabled=False,  # Disabled by default
            priority=OutputPriority.NORMAL,
            format_options={
                "format": "json",
                "device_config": {
                    "host": "localhost",
                    "port": 8082,
                    "connection_id": "tcp_device_1"
                }
            },
            filter_rules=[],
            retry_attempts=3,
            retry_delay=1.0,
            batch_size=10,
            batch_timeout=2.0
        )
        output_manager.add_output_config("tcp_device", tcp_config)
        
        # UDP Device output (example)
        udp_config = OutputConfig(
            output_type=OutputType.UDP_DEVICE,
            enabled=False,  # Disabled by default
            priority=OutputPriority.LOW,
            format_options={
                "format": "json",
                "device_config": {
                    "host": "localhost",
                    "port": 8083
                }
            },
            filter_rules=[],
            retry_attempts=2,
            retry_delay=0.5,
            batch_size=5,
            batch_timeout=1.0
        )
        output_manager.add_output_config("udp_device", udp_config)
        
        # Multicast Device output (example)
        multicast_config = OutputConfig(
            output_type=OutputType.MULTICAST_DEVICE,
            enabled=False,  # Disabled by default
            priority=OutputPriority.LOW,
            format_options={
                "format": "json",
                "device_config": {
                    "group": "224.0.0.1",
                    "port": 8084
                }
            },
            filter_rules=[],
            retry_attempts=1,
            retry_delay=0.1,
            batch_size=1,
            batch_timeout=0.5
        )
        output_manager.add_output_config("multicast_device", multicast_config)
        
        logger.info("Default output configurations setup complete")
        
    except Exception as e:
        logger.error(f"Error setting up default output configs: {e}")

async def run_console():
    """Run the application in console mode"""
    websocket_server = None
    fastapi_server = None
    app_service = None
    analytics_client = None
    output_manager = None
    sessionizer = None
    
    try:
        logger.info("Starting in console mode")
        
        # Run IP discovery if enabled
        from config.config import _config
        if _config.get('discover_remote_ip', False):
            logger.info("Running IP discovery...")
            await asyncio.to_thread(discover_and_update_terminals, _config)
            logger.info("IP discovery completed")
        
        # Initialize application service
        app_service = ApplicationService()
        await app_service.start()
        
        # Start WebSocket server background tasks
        logger.info("Starting WebSocket server...")
        websocket_server = await start_websocket_server()
        logger.info("WebSocket server background tasks started")
        
        # Initialize and start analytics client
        logger.info("Initializing analytics client...")
        analytics_config = load_analytics_config()
        analytics_client = AnalyticsAPIClient(analytics_config)
        set_analytics_client(analytics_client)
        
        if analytics_config.base_url != 'https://analytics.example.com/api/v1':
            await analytics_client.start()
            logger.info("Analytics client started")
        else:
            logger.info("Analytics client configured but not started (using default URL)")
        
        # Initialize enhanced output manager
        logger.info("Initializing enhanced output manager...")
        output_manager = EnhancedOutputManager()
        setup_default_output_configs(output_manager)
        await output_manager.start()
        set_output_manager(output_manager)
        logger.info("Enhanced output manager started")
        
        # Initialize sessionizer
        logger.info("Initializing sessionizer...")
        sessionizer = Sessionizer(session_timeout=300.0, cleanup_interval=60.0)
        await sessionizer.start()
        set_sessionizer(sessionizer)
        logger.info("Sessionizer started")
        
        # Start FastAPI server
        logger.info("Starting FastAPI server...")
        fastapi_server = await start_fastapi_server(app_service, host="0.0.0.0", port=8080)
        
        # Run the FastAPI server
        await fastapi_server.serve()
        
    except KeyboardInterrupt:
        logger.info("Console interrupted, shutting down")
    except Exception as e:
        logger.error(f"Console mode error: {e}")
    finally:
        # Cleanup in reverse order
        if sessionizer:
            logger.info("Stopping sessionizer...")
            await sessionizer.stop()
        
        if output_manager:
            logger.info("Stopping enhanced output manager...")
            await output_manager.stop()
        
        if analytics_client and analytics_client.is_running:
            logger.info("Stopping analytics client...")
            await analytics_client.stop()
        
        if websocket_server:
            logger.info("Stopping WebSocket server...")
            await stop_websocket_server()
        
        if app_service:
            await app_service.shutdown()
        
        logger.info("Gateway Service shutdown complete")

def main():
    """Main entry point"""
    try:
        # Wire dependency injection container
        wire_container()
        
        if len(sys.argv) == 1:
            # Console mode
            asyncio.run(run_console())
        else:
            # Service mode - check if we're on Windows
            import platform
            if platform.system().lower() == "windows":
                try:
                    logger.info("Starting in Windows service mode")
                    import win32serviceutil
                    win32serviceutil.HandleCommandLine(ServiceManager)
                except ImportError:
                    logger.error("Windows service modules not available")
                    sys.exit(1)
            else:
                # Development mode on Mac/Linux
                logger.info("Starting in development mode (Mac/Linux)")
                service_manager = ServiceManager()
                service_manager.run_development()
            
    except Exception as e:
        logger.error(f"Application startup failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
