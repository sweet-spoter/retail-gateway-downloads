import asyncio
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
import logging

from models.lane_config import LaneConfig, SessionizerConfig
from core.event_normalizer import NormalizedEventType

logger = logging.getLogger(__name__)

class SessionState(str, Enum):
    """Session state enumeration"""
    IDLE = "idle"
    ACTIVE = "active"
    COMPLETING = "completing"
    COMPLETED = "completed"
    TIMEOUT = "timeout"
    ERROR = "error"

class SessionManager:
    """Manages transaction sessions and event correlation"""
    
    def __init__(self, lane_config: LaneConfig, event_callback: Optional[Callable] = None):
        self.lane_config = lane_config
        self.sessionizer_config = lane_config.sessionizer
        self.event_callback = event_callback
        
        self.lane_id = lane_config.lane_id
        self.register_id = lane_config.register_id
        self.cashier_id = lane_config.cashier_id
        
        self.active_sessions: Dict[str, 'TransactionSession'] = {}
        self.completed_sessions: List['TransactionSession'] = []
        self.session_timeout_task: Optional[asyncio.Task] = None
        self.is_running = False
        
        # Session statistics
        self.stats = {
            "total_sessions": 0,
            "completed_sessions": 0,
            "timeout_sessions": 0,
            "error_sessions": 0,
            "average_session_duration": 0.0
        }

    async def initialize(self):
        """Initialize the session manager"""
        try:
            logger.info(f"Initializing session manager for lane {self.lane_id}")
            
            # Validate sessionizer configuration
            if not self.sessionizer_config.enabled:
                logger.warning(f"Session manager disabled for lane {self.lane_id}")
                return
            
            # Initialize session timeout monitoring
            await self._start_timeout_monitoring()
            
            logger.info(f"Session manager initialized for lane {self.lane_id}")
            
        except Exception as e:
            logger.error(f"Failed to initialize session manager for lane {self.lane_id}: {e}")
            raise

    async def start(self):
        """Start the session manager"""
        try:
            if not self.sessionizer_config.enabled:
                logger.info(f"Session manager not enabled for lane {self.lane_id}")
                return
            
            self.is_running = True
            logger.info(f"Session manager started for lane {self.lane_id}")
            
        except Exception as e:
            logger.error(f"Failed to start session manager for lane {self.lane_id}: {e}")
            raise

    async def stop(self):
        """Stop the session manager"""
        try:
            self.is_running = False
            
            # Complete all active sessions
            for session_id in list(self.active_sessions.keys()):
                await self._complete_session(session_id, "manager_stop")
            
            # Stop timeout monitoring
            await self._stop_timeout_monitoring()
            
            logger.info(f"Session manager stopped for lane {self.lane_id}")
            
        except Exception as e:
            logger.error(f"Error stopping session manager for lane {self.lane_id}: {e}")

    async def shutdown(self):
        """Shutdown the session manager"""
        try:
            await self.stop()
            
            # Clear all sessions
            self.active_sessions.clear()
            self.completed_sessions.clear()
            
            logger.info(f"Session manager shutdown complete for lane {self.lane_id}")
            
        except Exception as e:
            logger.error(f"Error shutting down session manager for lane {self.lane_id}: {e}")

    async def process_event(self, normalized_event: Dict[str, Any]) -> bool:
        """Process a normalized event"""
        try:
            if not self.is_running or not self.sessionizer_config.enabled:
                return True  # Skip session management if disabled
            
            event_type = normalized_event.get("event_type")
            event_id = normalized_event.get("event_id")
            
            logger.debug(f"Processing event {event_id} of type {event_type} in lane {self.lane_id}")
            
            # Handle different event types
            if event_type == NormalizedEventType.TRANSACTION_START:
                await self._handle_transaction_start(normalized_event)
            elif event_type == NormalizedEventType.TRANSACTION_END:
                await self._handle_transaction_end(normalized_event)
            elif event_type in [
                NormalizedEventType.PAYMENT_RECEIVED,
                NormalizedEventType.DRAWER_OPEN,
                NormalizedEventType.DRAWER_CLOSE,
                NormalizedEventType.SAFE_ACCESS
            ]:
                await self._handle_transaction_event(normalized_event)
            else:
                # Pass through other events
                await self._send_event(normalized_event)
            
            return True
            
        except Exception as e:
            logger.error(f"Error processing event in session manager for lane {self.lane_id}: {e}")
            return False

    async def _handle_transaction_start(self, event: Dict[str, Any]):
        """Handle transaction start event"""
        try:
            transaction_id = event.get("payload", {}).get("transaction_id")
            
            if not transaction_id:
                logger.warning(f"Transaction start event missing transaction_id in lane {self.lane_id}")
                return
            
            # Check if session already exists
            if transaction_id in self.active_sessions:
                logger.warning(f"Session already exists for transaction {transaction_id} in lane {self.lane_id}")
                return
            
            # Create new session
            session = TransactionSession(
                session_id=transaction_id,
                lane_id=self.lane_id,
                register_id=self.register_id,
                cashier_id=self.cashier_id,
                config=self.sessionizer_config,
                event_callback=self.event_callback
            )
            
            await session.initialize()
            self.active_sessions[transaction_id] = session
            self.stats["total_sessions"] += 1
            
            logger.info(f"Created session {transaction_id} for lane {self.lane_id}")
            
            # Send live event
            await self._send_live_event(event, "session_started")
            
        except Exception as e:
            logger.error(f"Error handling transaction start in lane {self.lane_id}: {e}")

    async def _handle_transaction_end(self, event: Dict[str, Any]):
        """Handle transaction end event"""
        try:
            transaction_id = event.get("payload", {}).get("transaction_id")
            
            if not transaction_id:
                logger.warning(f"Transaction end event missing transaction_id in lane {self.lane_id}")
                return
            
            # Complete the session
            await self._complete_session(transaction_id, "transaction_end")
            
        except Exception as e:
            logger.error(f"Error handling transaction end in lane {self.lane_id}: {e}")

    async def _handle_transaction_event(self, event: Dict[str, Any]):
        """Handle transaction-related events"""
        try:
            # Try to find the session by transaction_id
            transaction_id = event.get("payload", {}).get("transaction_id")
            
            if transaction_id and transaction_id in self.active_sessions:
                # Add event to existing session
                session = self.active_sessions[transaction_id]
                await session.add_event(event)
            else:
                # Try to correlate by time window
                correlated_session = await self._correlate_event_to_session(event)
                
                if correlated_session:
                    await correlated_session.add_event(event)
                else:
                    # Send as standalone event
                    await self._send_event(event)
            
        except Exception as e:
            logger.error(f"Error handling transaction event in lane {self.lane_id}: {e}")

    async def _correlate_event_to_session(self, event: Dict[str, Any]) -> Optional['TransactionSession']:
        """Correlate an event to an existing session based on time window"""
        try:
            event_timestamp = datetime.fromisoformat(event.get("timestamp"))
            correlation_window = timedelta(seconds=self.sessionizer_config.correlation_window)
            
            for session in self.active_sessions.values():
                if session.state == SessionState.ACTIVE:
                    # Check if event falls within correlation window
                    if abs(event_timestamp - session.last_event_time) <= correlation_window:
                        logger.debug(f"Correlated event to session {session.session_id} in lane {self.lane_id}")
                        return session
            
            return None
            
        except Exception as e:
            logger.error(f"Error correlating event to session in lane {self.lane_id}: {e}")
            return None

    async def _complete_session(self, session_id: str, reason: str):
        """Complete a session"""
        try:
            if session_id not in self.active_sessions:
                logger.warning(f"Session {session_id} not found for completion in lane {self.lane_id}")
                return
            
            session = self.active_sessions[session_id]
            await session.complete(reason)
            
            # Move to completed sessions
            self.completed_sessions.append(session)
            del self.active_sessions[session_id]
            
            # Update statistics
            self.stats["completed_sessions"] += 1
            if session.state == SessionState.TIMEOUT:
                self.stats["timeout_sessions"] += 1
            elif session.state == SessionState.ERROR:
                self.stats["error_sessions"] += 1
            
            # Update average session duration
            self._update_session_stats()
            
            logger.info(f"Completed session {session_id} in lane {self.lane_id} (reason: {reason})")
            
            # Send transaction bundle
            await self._send_transaction_bundle(session)
            
        except Exception as e:
            logger.error(f"Error completing session {session_id} in lane {self.lane_id}: {e}")

    async def _start_timeout_monitoring(self):
        """Start session timeout monitoring"""
        try:
            if self.session_timeout_task and not self.session_timeout_task.done():
                return
            
            self.session_timeout_task = asyncio.create_task(self._timeout_monitor_loop())
            logger.debug(f"Started timeout monitoring for lane {self.lane_id}")
            
        except Exception as e:
            logger.error(f"Error starting timeout monitoring for lane {self.lane_id}: {e}")

    async def _stop_timeout_monitoring(self):
        """Stop session timeout monitoring"""
        try:
            if self.session_timeout_task:
                self.session_timeout_task.cancel()
                try:
                    await self.session_timeout_task
                except asyncio.CancelledError:
                    pass
                self.session_timeout_task = None
                logger.debug(f"Stopped timeout monitoring for lane {self.lane_id}")
                
        except Exception as e:
            logger.error(f"Error stopping timeout monitoring for lane {self.lane_id}: {e}")

    async def _timeout_monitor_loop(self):
        """Monitor for session timeouts"""
        while self.is_running:
            try:
                await asyncio.sleep(10)  # Check every 10 seconds
                
                current_time = datetime.now()
                timeout_sessions = []
                
                for session_id, session in self.active_sessions.items():
                    if session.should_timeout(current_time):
                        timeout_sessions.append(session_id)
                
                # Complete timed out sessions
                for session_id in timeout_sessions:
                    await self._complete_session(session_id, "timeout")
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in timeout monitor loop for lane {self.lane_id}: {e}")

    async def _send_live_event(self, event: Dict[str, Any], action: str):
        """Send a live event"""
        try:
            live_event = {
                **event,
                "session_action": action,
                "timestamp": datetime.now().isoformat()
            }
            
            await self._send_event(live_event)
            
        except Exception as e:
            logger.error(f"Error sending live event in lane {self.lane_id}: {e}")

    async def _send_transaction_bundle(self, session: 'TransactionSession'):
        """Send a transaction bundle"""
        try:
            bundle = session.create_transaction_bundle()
            await self._send_event(bundle)
            
        except Exception as e:
            logger.error(f"Error sending transaction bundle in lane {self.lane_id}: {e}")

    async def _send_event(self, event: Dict[str, Any]):
        """Send an event via callback"""
        try:
            if self.event_callback:
                await self.event_callback(event)
            
        except Exception as e:
            logger.error(f"Error sending event in lane {self.lane_id}: {e}")

    def _update_session_stats(self):
        """Update session statistics"""
        try:
            if self.completed_sessions:
                total_duration = sum(
                    session.duration.total_seconds() 
                    for session in self.completed_sessions 
                    if session.duration
                )
                self.stats["average_session_duration"] = total_duration / len(self.completed_sessions)
                
        except Exception as e:
            logger.error(f"Error updating session stats for lane {self.lane_id}: {e}")

    def get_session_stats(self) -> Dict[str, Any]:
        """Get session statistics"""
        return {
            **self.stats,
            "active_sessions": len(self.active_sessions),
            "completed_sessions_count": len(self.completed_sessions)
        }

    def get_active_sessions(self) -> Dict[str, Dict[str, Any]]:
        """Get information about active sessions"""
        return {
            session_id: {
                "state": session.state.value,
                "start_time": session.start_time.isoformat(),
                "last_event_time": session.last_event_time.isoformat(),
                "event_count": len(session.events)
            }
            for session_id, session in self.active_sessions.items()
        }

class TransactionSession:
    """Represents a single transaction session"""
    
    def __init__(
        self,
        session_id: str,
        lane_id: str,
        register_id: str,
        cashier_id: Optional[str],
        config: SessionizerConfig,
        event_callback: Optional[Callable] = None
    ):
        self.session_id = session_id
        self.lane_id = lane_id
        self.register_id = register_id
        self.cashier_id = cashier_id
        self.config = config
        self.event_callback = event_callback
        
        self.state = SessionState.IDLE
        self.start_time = datetime.now()
        self.last_event_time = self.start_time
        self.end_time: Optional[datetime] = None
        self.events: List[Dict[str, Any]] = []
        self.completion_reason: Optional[str] = None
        
        # Session metadata
        self.metadata = {
            "session_id": session_id,
            "lane_id": lane_id,
            "register_id": register_id,
            "cashier_id": cashier_id,
            "start_time": self.start_time.isoformat(),
            "expected_sequence": config.expected_sequence,
            "correlation_window": config.correlation_window
        }

    async def initialize(self):
        """Initialize the session"""
        try:
            self.state = SessionState.ACTIVE
            logger.debug(f"Initialized session {self.session_id} in lane {self.lane_id}")
            
        except Exception as e:
            self.state = SessionState.ERROR
            logger.error(f"Error initializing session {self.session_id} in lane {self.lane_id}: {e}")
            raise

    async def add_event(self, event: Dict[str, Any]):
        """Add an event to the session"""
        try:
            if self.state not in [SessionState.ACTIVE, SessionState.COMPLETING]:
                logger.warning(f"Cannot add event to session {self.session_id} in state {self.state}")
                return
            
            # Add event to session
            self.events.append(event)
            self.last_event_time = datetime.fromisoformat(event.get("timestamp"))
            
            # Check if session should complete
            if self._should_complete():
                await self.complete("sequence_complete")
            
            logger.debug(f"Added event to session {self.session_id} in lane {self.lane_id}")
            
        except Exception as e:
            logger.error(f"Error adding event to session {self.session_id} in lane {self.lane_id}: {e}")

    async def complete(self, reason: str):
        """Complete the session"""
        try:
            self.state = SessionState.COMPLETING
            self.end_time = datetime.now()
            self.completion_reason = reason
            
            # Validate session completeness
            if self._validate_session():
                self.state = SessionState.COMPLETED
            else:
                self.state = SessionState.ERROR
                logger.warning(f"Session {self.session_id} validation failed in lane {self.lane_id}")
            
            logger.info(f"Completed session {self.session_id} in lane {self.lane_id} (reason: {reason})")
            
        except Exception as e:
            self.state = SessionState.ERROR
            logger.error(f"Error completing session {self.session_id} in lane {self.lane_id}: {e}")

    def should_timeout(self, current_time: datetime) -> bool:
        """Check if session should timeout"""
        if self.state != SessionState.ACTIVE:
            return False
        
        timeout_duration = timedelta(seconds=self.config.timeout)
        return (current_time - self.last_event_time) > timeout_duration

    def _should_complete(self) -> bool:
        """Check if session should complete based on expected sequence"""
        if not self.config.expected_sequence:
            return False
        
        # Check if we have events for all expected device types
        event_device_types = {event.get("device_type") for event in self.events}
        expected_device_types = set(self.config.expected_sequence)
        
        return expected_device_types.issubset(event_device_types)

    def _validate_session(self) -> bool:
        """Validate session completeness and data integrity"""
        try:
            # Basic validation
            if not self.events:
                return False
            
            # Check for required events based on expected sequence
            if self.config.expected_sequence:
                event_device_types = {event.get("device_type") for event in self.events}
                expected_device_types = set(self.config.expected_sequence)
                
                if not expected_device_types.issubset(event_device_types):
                    logger.warning(f"Session {self.session_id} missing expected device events: {expected_device_types - event_device_types}")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Error validating session {self.session_id}: {e}")
            return False

    def create_transaction_bundle(self) -> Dict[str, Any]:
        """Create a transaction bundle from the session"""
        try:
            bundle = {
                "bundle_id": str(uuid.uuid4()),
                "session_id": self.session_id,
                "lane_id": self.lane_id,
                "register_id": self.register_id,
                "cashier_id": self.cashier_id,
                "start_time": self.start_time.isoformat(),
                "end_time": self.end_time.isoformat() if self.end_time else None,
                "duration": self.duration.total_seconds() if self.duration else None,
                "state": self.state.value,
                "completion_reason": self.completion_reason,
                "event_count": len(self.events),
                "events": self.events,
                "metadata": self.metadata,
                "bundle_type": "transaction_bundle",
                "timestamp": datetime.now().isoformat()
            }
            
            return bundle
            
        except Exception as e:
            logger.error(f"Error creating transaction bundle for session {self.session_id}: {e}")
            return {}

    @property
    def duration(self) -> Optional[timedelta]:
        """Get session duration"""
        if self.end_time:
            return self.end_time - self.start_time
        return None 