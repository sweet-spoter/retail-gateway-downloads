"""
FastAPI application for the Gateway Service.
"""

import asyncio
import logging
from typing import Optional
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

logger = logging.getLogger(__name__)

def create_fastapi_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="Retail Gateway Platform API",
        description="API for the Retail Gateway Platform",
        version="1.0.0"
    )
    
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    @app.get("/health")
    async def health_check():
        """Health check endpoint."""
        return {"status": "healthy", "service": "retail-gateway-platform"}
    
    @app.get("/")
    async def root():
        """Root endpoint."""
        return {"message": "Retail Gateway Platform API", "version": "1.0.0"}
    
    return app

async def start_fastapi_server(app_service, host: str = "0.0.0.0", port: int = 8080):
    """Start the FastAPI server."""
    try:
        app = create_fastapi_app()
        
        # Configure uvicorn server
        config = uvicorn.Config(
            app=app,
            host=host,
            port=port,
            log_level="info"
        )
        
        server = uvicorn.Server(config)
        logger.info(f"Starting FastAPI server on {host}:{port}")
        
        return server
        
    except Exception as e:
        logger.error(f"Failed to start FastAPI server: {e}")
        raise
