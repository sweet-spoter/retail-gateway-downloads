"""
Smarttill cash drawer interface using .NET Core SDK.
Integrates with the gateway service architecture.
"""

from ....base.pos_interface import POSInterface
from .smartill_wrapper import SmarttillWrapper

class SmarttillInterface(POSInterface):
    """
    Smarttill cash drawer interface using .NET Core SDK.
    Integrates with the gateway service architecture.
    """
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.wrapper = SmarttillWrapper()
        self.connection_type = config.get('connection_type', 'ethernet')
        self.device_id = config.get('device_id')
        self.port = config.get('port', 8086)
        self.connection_params = self._extract_connection_params(config)
    
    def _extract_connection_params(self, config: dict) -> dict:
        """Extract connection parameters from config"""
        return {
            'device_id': config.get('device_id'),
            'port': config.get('port', 8086),
            'connection_type': config.get('connection_type', 'ethernet')
        }
    
    def _format_device_data(self, data: bytes) -> dict:
        """
        Format Smarttill-specific data.
        Convert raw data to standardized format.
        """
        try:
            # Smarttill typically sends structured data
            # Parse the data based on Smarttill protocol
            if data:
                # Example: Parse Smarttill message format
                message = data.decode('utf-8', errors='ignore')
                
                return {
                    'device_type': self.device_type,
                    'device_id': self.device_id,
                    'message_type': 'smarttill_data',
                    'data': message,
                    'timestamp': self._get_timestamp()
                }
            else:
                return {
                    'device_type': self.device_type,
                    'device_id': self.device_id,
                    'message_type': 'empty_data',
                    'timestamp': self._get_timestamp()
                }
                
        except Exception as e:
            return {
                'error': str(e),
                'device_type': self.device_type,
                'device_id': self.device_id,
                'timestamp': self._get_timestamp()
            }
    
    def validate_connection(self) -> bool:
        """
        Validate Smarttill connection.
        Use wrapper to check connection status.
        """
        try:
            return self.wrapper.is_connected()
        except Exception as e:
            print(f"Smarttill connection validation failed: {e}")
            return False
    
    def connect_device(self) -> bool:
        """Connect to Smarttill device using wrapper"""
        try:
            if self.connection_type == 'ethernet':
                return self.wrapper.connect_ethernet(
                    self.connection_params['device_id'],
                    self.connection_params['port']
                )
            else:
                print(f"Unsupported connection type: {self.connection_type}")
                return False
        except Exception as e:
            print(f"Smarttill device connection failed: {e}")
            return False
    
    def disconnect_device(self):
        """Disconnect from Smarttill device"""
        try:
            self.wrapper.disconnect()
        except Exception as e:
            print(f"Smarttill device disconnection failed: {e}")
    
    def get_device_status(self) -> dict:
        """Get comprehensive Smarttill device status"""
        try:
            status = self.wrapper.get_status()
            return {
                'device_type': self.device_type,
                'device_id': self.device_id,
                'connected': self.validate_connection(),
                'status': status,
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'error': str(e),
                'device_type': self.device_type,
                'device_id': self.device_id,
                'connected': False,
                'timestamp': self._get_timestamp()
            }
    
    def perform_sale(self, receipt_number: int, cashier_id: int, amount_pence: int, change_pence: int = 0) -> dict:
        """Perform a sale transaction"""
        try:
            success = self.wrapper.do_sale(receipt_number, cashier_id, amount_pence, change_pence)
            return {
                'success': success,
                'receipt_number': receipt_number,
                'amount_pence': amount_pence,
                'change_pence': change_pence,
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'receipt_number': receipt_number,
                'timestamp': self._get_timestamp()
            }
    
    def perform_topup(self, receipt_number: int, cashier_id: int) -> dict:
        """Perform a topup transaction"""
        try:
            success = self.wrapper.do_topup(receipt_number, cashier_id)
            return {
                'success': success,
                'receipt_number': receipt_number,
                'transaction_type': 'topup',
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'receipt_number': receipt_number,
                'timestamp': self._get_timestamp()
            }
    
    def perform_pickup(self, receipt_number: int, cashier_id: int) -> dict:
        """Perform a pickup transaction"""
        try:
            success = self.wrapper.do_pickup(receipt_number, cashier_id)
            return {
                'success': success,
                'receipt_number': receipt_number,
                'transaction_type': 'pickup',
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'receipt_number': receipt_number,
                'timestamp': self._get_timestamp()
            }
    
    def perform_reset(self, receipt_number: int, cashier_id: int) -> dict:
        """Perform a reset transaction"""
        try:
            success = self.wrapper.do_reset(receipt_number, cashier_id)
            return {
                'success': success,
                'receipt_number': receipt_number,
                'transaction_type': 'reset',
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'receipt_number': receipt_number,
                'timestamp': self._get_timestamp()
            }
    
    def open_drawer(self) -> dict:
        """Open the cash drawer"""
        try:
            success = self.wrapper.open_drawer()
            return {
                'success': success,
                'action': 'open_drawer',
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'action': 'open_drawer',
                'timestamp': self._get_timestamp()
            }
    
    def get_till_info(self) -> dict:
        """Get till information"""
        try:
            status = self.wrapper.get_status()
            return {
                'device_type': self.device_type,
                'device_id': self.device_id,
                'till_value_pence': status.get('till_value_pence', 0),
                'till_value_pounds': status.get('till_value_pence', 0) / 100.0,
                'drawer_open': status.get('drawer_open', False),
                'weighing': status.get('weighing', False),
                'firmware_version': status.get('firmware_version', 'Unknown'),
                'timestamp': self._get_timestamp()
            }
        except Exception as e:
            return {
                'error': str(e),
                'device_type': self.device_type,
                'device_id': self.device_id,
                'timestamp': self._get_timestamp()
            }
    
    def cleanup(self):
        """Cleanup Smarttill resources"""
        try:
            self.wrapper.cleanup()
            print("✓ Smarttill interface cleanup completed")
        except Exception as e:
            print(f"⚠️  Error during Smarttill cleanup: {e}")
    
    def __del__(self):
        """Destructor to ensure cleanup"""
        try:
            self.cleanup()
        except Exception as e:
            print(f"⚠️  Error during Smarttill destructor: {e}")
