# Gateway Lane Service Installer

## System Requirements
- Windows 10 or later (64-bit)
- 4GB RAM minimum
- 10GB free disk space
- Administrator privileges for installation

## Installation
1. Run `validate-requirements.bat` to check system compatibility
2. Run `install.bat` as Administrator
3. Choose your preferred startup method:
   - **Windows Service**: Run `start_service.bat` as Administrator (recommended)
   - **Manual Mode**: Run `start_gateway.bat` (for testing/development)

## Configuration
The installer includes a default `config.json` with one lane configured for testing.
Edit `config.json` to add more lanes or modify existing ones as needed.

**Default Configuration:**
- Input: UDP listener on port 5999 (register 101)
- Output: TCP listener on port 5002 (register 101)
- Terminal: Single terminal (ID: 101, IP: 127.0.0.1)

## Service Management
- **Service Name**: Gateway Lane Service
- **Service ID**: GatewayLaneService
- **Install Location**: C:\Program Files\GatewayLaneService
- **Startup Type**: Automatic (when installed as service)

## Running Modes
- **Windows Service Mode**: Runs as a proper Windows service (recommended for production)
- **Manual Mode**: Runs as a standalone application (useful for testing)

## Uninstallation
Run `uninstall.bat` as Administrator to remove the service and all files.

## Troubleshooting
- If service fails to start, check Windows Event Viewer for error details
- For manual mode issues, check the console output
- Ensure all required ports (8080, 5999, 4376, 9000) are available
