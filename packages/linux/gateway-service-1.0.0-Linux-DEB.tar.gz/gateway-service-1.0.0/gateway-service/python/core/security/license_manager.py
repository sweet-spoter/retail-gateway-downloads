"""
License Management System with Security Features

This module provides:
- Hardware fingerprinting
- License encryption/decryption
- Digital signature validation
- Offline license validation
- License file management
"""

import hashlib
import hmac
import json
import os
import platform
import subprocess
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
import base64

class HardwareFingerprinter:
    """Generate unique hardware fingerprint for license validation"""
    
    @staticmethod
    def get_cpu_info() -> str:
        """Get CPU information"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(['wmic', 'cpu', 'get', 'ProcessorId'], 
                                      capture_output=True, text=True)
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    return lines[1].strip()
            else:
                # Linux/Mac CPU info
                with open('/proc/cpuinfo', 'r') as f:
                    for line in f:
                        if line.startswith('processor'):
                            return hashlib.md5(line.encode()).hexdigest()
        except Exception:
            pass
        return "unknown_cpu"

    @staticmethod
    def get_mac_addresses() -> str:
        """Get MAC addresses of network interfaces"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(['getmac', '/fo', 'csv'], 
                                      capture_output=True, text=True)
                macs = []
                for line in result.stdout.split('\n')[1:]:
                    if line.strip():
                        mac = line.split(',')[0].strip('"')
                        if mac and mac != "N/A":
                            macs.append(mac)
                return hashlib.md5(','.join(macs).encode()).hexdigest()
            else:
                # Linux/Mac MAC addresses
                result = subprocess.run(['ifconfig'], capture_output=True, text=True)
                macs = []
                for line in result.stdout.split('\n'):
                    if 'ether' in line:
                        mac = line.split('ether')[1].split()[0]
                        macs.append(mac)
                return hashlib.md5(','.join(macs).encode()).hexdigest()
        except Exception:
            pass
        return "unknown_mac"

    @staticmethod
    def get_disk_serial() -> str:
        """Get disk serial number"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(['wmic', 'diskdrive', 'get', 'SerialNumber'], 
                                      capture_output=True, text=True)
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    return lines[1].strip()
            else:
                # Linux disk serial
                result = subprocess.run(['lsblk', '-no', 'SERIAL'], 
                                      capture_output=True, text=True)
                return hashlib.md5(result.stdout.encode()).hexdigest()
        except Exception:
            pass
        return "unknown_disk"

    @staticmethod
    def get_motherboard_serial() -> str:
        """Get motherboard serial number"""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(['wmic', 'baseboard', 'get', 'SerialNumber'], 
                                      capture_output=True, text=True)
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    return lines[1].strip()
            else:
                # Linux motherboard info
                with open('/sys/class/dmi/id/board_serial', 'r') as f:
                    return f.read().strip()
        except Exception:
            pass
        return "unknown_motherboard"

    @staticmethod
    def generate_hardware_fingerprint() -> str:
        """Generate unique hardware fingerprint"""
        components = [
            HardwareFingerprinter.get_cpu_info(),
            HardwareFingerprinter.get_mac_addresses(),
            HardwareFingerprinter.get_disk_serial(),
            HardwareFingerprinter.get_motherboard_serial(),
            platform.machine(),
            platform.processor()
        ]
        
        fingerprint_data = '|'.join(components)
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()

class LicenseEncryption:
    """Handle license encryption and decryption"""
    
    def __init__(self, encryption_key: Optional[str] = None):
        if encryption_key:
            self.key = base64.urlsafe_b64encode(encryption_key.encode())
        else:
            # Generate new key
            self.key = Fernet.generate_key()
        
        self.cipher = Fernet(self.key)
    
    def encrypt_license(self, license_data: Dict[str, Any]) -> str:
        """Encrypt license data"""
        license_json = json.dumps(license_data, sort_keys=True)
        encrypted_data = self.cipher.encrypt(license_json.encode())
        return base64.urlsafe_b64encode(encrypted_data).decode()
    
    def decrypt_license(self, encrypted_license: str) -> Dict[str, Any]:
        """Decrypt license data"""
        encrypted_data = base64.urlsafe_b64decode(encrypted_license.encode())
        decrypted_data = self.cipher.decrypt(encrypted_data)
        return json.loads(decrypted_data.decode())
    
    def get_encryption_key(self) -> str:
        """Get the encryption key"""
        return base64.urlsafe_b64decode(self.key).decode()

class DigitalSignature:
    """Handle digital signature creation and validation"""
    
    def __init__(self, private_key_path: Optional[str] = None, public_key_path: Optional[str] = None):
        self.private_key_path = private_key_path
        self.public_key_path = public_key_path
    
    def generate_key_pair(self) -> Tuple[str, str]:
        """Generate RSA key pair"""
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        
        public_key = private_key.public_key()
        
        # Serialize keys
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )
        
        public_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        
        return private_pem.decode(), public_pem.decode()
    
    def sign_data(self, data: str, private_key_pem: str) -> str:
        """Sign data with private key"""
        private_key = serialization.load_pem_private_key(
            private_key_pem.encode(),
            password=None
        )
        
        signature = private_key.sign(
            data.encode(),
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        return base64.urlsafe_b64encode(signature).decode()
    
    def verify_signature(self, data: str, signature: str, public_key_pem: str) -> bool:
        """Verify signature with public key"""
        try:
            public_key = serialization.load_pem_public_key(public_key_pem.encode())
            
            signature_bytes = base64.urlsafe_b64decode(signature.encode())
            
            public_key.verify(
                signature_bytes,
                data.encode(),
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            
            return True
        except Exception:
            return False

class LicenseManager:
    """Main license management class"""
    
    def __init__(self, license_file_path: str = "license.json"):
        self.license_file_path = license_file_path
        self.encryption = LicenseEncryption()
        self.signature = DigitalSignature()
        self.hardware_fingerprint = HardwareFingerprinter.generate_hardware_fingerprint()
    
    def create_license(self, license_data: Dict[str, Any], 
                      private_key_pem: str) -> Dict[str, Any]:
        """Create a new license with security features"""
        
        # Add hardware fingerprint
        license_data['hardware_fingerprint'] = self.hardware_fingerprint
        
        # Add creation timestamp
        license_data['created_at'] = datetime.utcnow().isoformat()
        
        # Create license string for signing
        license_string = json.dumps(license_data, sort_keys=True)
        
        # Sign the license
        signature = self.signature.sign_data(license_string, private_key_pem)
        
        # Encrypt the license
        encrypted_license = self.encryption.encrypt_license(license_data)
        
        # Create final license structure
        final_license = {
            "version": "2.0",
            "encrypted_license": encrypted_license,
            "signature": signature,
            "encryption_key": self.encryption.get_encryption_key(),
            "created_at": datetime.utcnow().isoformat()
        }
        
        return final_license
    
    def validate_license(self, license_data: Dict[str, Any], 
                        public_key_pem: str) -> Tuple[bool, str]:
        """Validate license with all security checks"""
        
        try:
            # Decrypt license
            encrypted_license = license_data.get('encrypted_license')
            if not encrypted_license:
                return False, "No encrypted license found"
            
            decrypted_license = self.encryption.decrypt_license(encrypted_license)
            
            # Verify hardware fingerprint
            stored_fingerprint = decrypted_license.get('hardware_fingerprint')
            current_fingerprint = HardwareFingerprinter.generate_hardware_fingerprint()
            
            if stored_fingerprint != current_fingerprint:
                return False, "Hardware fingerprint mismatch"
            
            # Verify signature
            license_string = json.dumps(decrypted_license, sort_keys=True)
            signature = license_data.get('signature')
            
            if not self.signature.verify_signature(license_string, signature, public_key_pem):
                return False, "Digital signature verification failed"
            
            # Check expiration
            expiration_date = decrypted_license.get('expiration_date')
            if expiration_date:
                exp_date = datetime.fromisoformat(expiration_date)
                if datetime.utcnow() > exp_date:
                    return False, "License has expired"
            
            # Check grace period
            grace_period_until = decrypted_license.get('grace_period_until')
            if grace_period_until:
                grace_date = datetime.fromisoformat(grace_period_until)
                if datetime.utcnow() > grace_date:
                    return False, "Grace period has expired"
            
            return True, "License is valid"
            
        except Exception as e:
            return False, f"License validation error: {str(e)}"
    
    def save_license(self, license_data: Dict[str, Any]) -> bool:
        """Save license to file"""
        try:
            with open(self.license_file_path, 'w') as f:
                json.dump(license_data, f, indent=2)
            return True
        except Exception:
            return False
    
    def load_license(self) -> Optional[Dict[str, Any]]:
        """Load license from file"""
        try:
            if os.path.exists(self.license_file_path):
                with open(self.license_file_path, 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return None
    
    def get_license_info(self, public_key_pem: str) -> Optional[Dict[str, Any]]:
        """Get license information without sensitive data"""
        license_data = self.load_license()
        if not license_data:
            return None
        
        is_valid, message = self.validate_license(license_data, public_key_pem)
        
        if not is_valid:
            return {"valid": False, "error": message}
        
        # Decrypt to get license info
        encrypted_license = license_data.get('encrypted_license')
        decrypted_license = self.encryption.decrypt_license(encrypted_license)
        
        # Return sanitized license info
        return {
            "valid": True,
            "license_type": decrypted_license.get('license_type'),
            "max_lanes": decrypted_license.get('max_lanes'),
            "features": decrypted_license.get('features'),
            "expiration_date": decrypted_license.get('expiration_date'),
            "grace_period_until": decrypted_license.get('grace_period_until'),
            "client_id": decrypted_license.get('client_id'),
            "hardware_fingerprint": decrypted_license.get('hardware_fingerprint')[:8] + "..."
        }
    
    def is_offline_capable(self, public_key_pem: str) -> bool:
        """Check if license supports offline operation"""
        license_data = self.load_license()
        if not license_data:
            return False
        
        is_valid, _ = self.validate_license(license_data, public_key_pem)
        if not is_valid:
            return False
        
        encrypted_license = license_data.get('encrypted_license')
        decrypted_license = self.encryption.decrypt_license(encrypted_license)
        
        features = decrypted_license.get('features', {})
        return features.get('offline_capable', False) 