"""
Enhanced Output Manager for Gateway Service.

This module provides a unified output management system that handles:
1. Analytics API Client - Sending data to external analytics services
2. WebSocket Server - Real-time data to web UI
3. Other Devices - TCP, UDP, multicast output to other devices

The output manager integrates with the sessionizer and provides output-specific
data formatting and filtering.
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

from core.logging_config import get_logger
from core.websocket_server import broadcast_message, WebSocketMessage, MessageType
from core.analytics_client import get_analytics_client, AnalyticsEndpoint
from core.metrics import get_metrics_registry

logger = get_logger(__name__)


class OutputType(str, Enum):
    """Types of output destinations."""
    ANALYTICS_API = "analytics_api"
    WEBSOCKET = "websocket"
    TCP_DEVICE = "tcp_device"
    UDP_DEVICE = "udp_device"
    MULTICAST_DEVICE = "multicast_device"


class OutputPriority(int, Enum):
    """Priority levels for output processing."""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4


@dataclass
class OutputConfig:
    """Configuration for an output destination."""
    output_type: OutputType
    enabled: bool = True
    priority: OutputPriority = OutputPriority.NORMAL
    format_options: Dict[str, Any] = field(default_factory=dict)
    filter_rules: List[Dict[str, Any]] = field(default_factory=list)
    retry_attempts: int = 3
    retry_delay: float = 1.0
    batch_size: int = 1
    batch_timeout: float = 5.0


@dataclass
class OutputMessage:
    """Message to be sent to output destinations."""
    data: Any
    output_type: OutputType
    priority: OutputPriority = OutputPriority.NORMAL
    message_id: Optional[str] = None
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    correlation_id: Optional[str] = None
    lane_id: Optional[str] = None
    register_id: Optional[str] = None
    cashier_id: Optional[str] = None


class OutputFormatter:
    """Handles data formatting for different output types."""
    
    @staticmethod
    def format_for_analytics(data: Any, config: OutputConfig) -> Dict[str, Any]:
        """Format data for analytics API."""
        formatted = {
            "data": data,
            "timestamp": time.time(),
            "metadata": {
                "source": "gateway_service",
                "version": "1.0.0"
            }
        }
        
        # Add format options
        if config.format_options.get("include_metadata", True):
            formatted["metadata"].update(config.format_options.get("metadata", {}))
        
        if config.format_options.get("include_audit_trail", False):
            formatted["audit_trail"] = {
                "processed_at": time.time(),
                "output_type": "analytics_api"
            }
        
        return formatted
    
    @staticmethod
    def format_for_websocket(data: Any, config: OutputConfig) -> Dict[str, Any]:
        """Format data for WebSocket transmission."""
        formatted = {
            "data": data,
            "timestamp": time.time(),
            "real_time": True
        }
        
        # Add format options
        if config.format_options.get("include_context", True):
            formatted["context"] = config.format_options.get("context", {})
        
        return formatted
    
    @staticmethod
    def format_for_device(data: Any, config: OutputConfig) -> str:
        """Format data for device output (TCP/UDP/Multicast)."""
        format_type = config.format_options.get("format", "json")
        
        if format_type == "json":
            return json.dumps(data, default=str)
        elif format_type == "csv":
            return OutputFormatter._to_csv(data)
        elif format_type == "xml":
            return OutputFormatter._to_xml(data)
        else:
            return str(data)
    
    @staticmethod
    def _to_csv(data: Any) -> str:
        """Convert data to CSV format."""
        if isinstance(data, dict):
            return ",".join([f"{k},{v}" for k, v in data.items()])
        elif isinstance(data, list):
            return "\n".join([OutputFormatter._to_csv(item) for item in data])
        else:
            return str(data)
    
    @staticmethod
    def _to_xml(data: Any) -> str:
        """Convert data to XML format."""
        if isinstance(data, dict):
            xml_parts = ["<data>"]
            for key, value in data.items():
                xml_parts.append(f"<{key}>{value}</{key}>")
            xml_parts.append("</data>")
            return "".join(xml_parts)
        else:
            return f"<data>{data}</data>"


class OutputFilter:
    """Handles filtering of output messages."""
    
    @staticmethod
    def should_send(message: OutputMessage, config: OutputConfig) -> bool:
        """Determine if a message should be sent based on filter rules."""
        if not config.filter_rules:
            return True
        
        for rule in config.filter_rules:
            if not OutputFilter._evaluate_rule(message, rule):
                return False
        
        return True
    
    @staticmethod
    def _evaluate_rule(message: OutputMessage, rule: Dict[str, Any]) -> bool:
        """Evaluate a single filter rule."""
        rule_type = rule.get("type")
        
        if rule_type == "field_exists":
            field = rule.get("field")
            return field in message.data if isinstance(message.data, dict) else False
        
        elif rule_type == "field_value":
            field = rule.get("field")
            value = rule.get("value")
            operator = rule.get("operator", "equals")
            
            if isinstance(message.data, dict) and field in message.data:
                field_value = message.data[field]
                return OutputFilter._compare_values(field_value, value, operator)
        
        elif rule_type == "priority":
            min_priority = rule.get("min_priority", OutputPriority.LOW)
            return message.priority >= min_priority
        
        elif rule_type == "timestamp":
            min_timestamp = rule.get("min_timestamp", 0)
            max_timestamp = rule.get("max_timestamp", float('inf'))
            return min_timestamp <= message.timestamp <= max_timestamp
        
        return True
    
    @staticmethod
    def _compare_values(actual: Any, expected: Any, operator: str) -> bool:
        """Compare values using the specified operator."""
        if operator == "equals":
            return actual == expected
        elif operator == "not_equals":
            return actual != expected
        elif operator == "greater_than":
            return actual > expected
        elif operator == "less_than":
            return actual < expected
        elif operator == "contains":
            return expected in str(actual)
        elif operator == "regex":
            import re
            return bool(re.search(expected, str(actual)))
        return False


class DeviceOutputManager:
    """Manages output to other devices via TCP, UDP, and multicast."""
    
    def __init__(self):
        self.connections: Dict[str, Any] = {}
        self.metrics = get_metrics_registry()
    
    async def send_tcp(self, host: str, port: int, data: str, connection_id: str = None) -> bool:
        """Send data via TCP connection."""
        try:
            import socket
            
            if connection_id is None:
                connection_id = f"tcp_{host}_{port}"
            
            # Create or reuse connection
            if connection_id not in self.connections:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect((host, port))
                self.connections[connection_id] = sock
            else:
                sock = self.connections[connection_id]
            
            # Send data
            sock.send(data.encode('utf-8'))
            
            # Update metrics
            self.metrics.counter("device_output_tcp_sent").increment()
            self.metrics.gauge("device_output_tcp_active_connections").set(len(self.connections))
            
            logger.debug(f"TCP data sent to {host}:{port}")
            return True
            
        except Exception as e:
            logger.error(f"TCP output error to {host}:{port}: {e}")
            self.metrics.counter("device_output_tcp_errors").increment()
            
            # Remove failed connection
            if connection_id in self.connections:
                del self.connections[connection_id]
            
            return False
    
    async def send_udp(self, host: str, port: int, data: str) -> bool:
        """Send data via UDP."""
        try:
            import socket
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.sendto(data.encode('utf-8'), (host, port))
            sock.close()
            
            # Update metrics
            self.metrics.counter("device_output_udp_sent").increment()
            
            logger.debug(f"UDP data sent to {host}:{port}")
            return True
            
        except Exception as e:
            logger.error(f"UDP output error to {host}:{port}: {e}")
            self.metrics.counter("device_output_udp_errors").increment()
            return False
    
    async def send_multicast(self, group: str, port: int, data: str) -> bool:
        """Send data via multicast."""
        try:
            import socket
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            sock.sendto(data.encode('utf-8'), (group, port))
            sock.close()
            
            # Update metrics
            self.metrics.counter("device_output_multicast_sent").increment()
            
            logger.debug(f"Multicast data sent to {group}:{port}")
            return True
            
        except Exception as e:
            logger.error(f"Multicast output error to {group}:{port}: {e}")
            self.metrics.counter("device_output_multicast_errors").increment()
            return False
    
    async def close_connections(self):
        """Close all TCP connections."""
        for connection_id, sock in self.connections.items():
            try:
                sock.close()
            except Exception as e:
                logger.warning(f"Error closing TCP connection {connection_id}: {e}")
        
        self.connections.clear()


class EnhancedOutputManager:
    """
    Enhanced output manager that handles all output destinations.
    
    Integrates with:
    - Analytics API Client for external data transmission
    - WebSocket Server for real-time UI updates
    - Device Output Manager for TCP/UDP/Multicast
    """
    
    def __init__(self):
        self.output_configs: Dict[str, OutputConfig] = {}
        self.device_manager = DeviceOutputManager()
        self.metrics = get_metrics_registry()
        self.is_running = False
        self.output_queue: asyncio.Queue = asyncio.Queue()
        self.batch_queues: Dict[str, List[OutputMessage]] = {}
        self.batch_timers: Dict[str, asyncio.Task] = {}
    
    def add_output_config(self, name: str, config: OutputConfig):
        """Add an output configuration."""
        self.output_configs[name] = config
        self.batch_queues[name] = []
        logger.info(f"Added output config: {name} ({config.output_type.value})")
    
    def remove_output_config(self, name: str):
        """Remove an output configuration."""
        if name in self.output_configs:
            del self.output_configs[name]
            if name in self.batch_queues:
                del self.batch_queues[name]
            if name in self.batch_timers:
                self.batch_timers[name].cancel()
                del self.batch_timers[name]
            logger.info(f"Removed output config: {name}")
    
    async def send_message(self, message: OutputMessage, output_name: str = None) -> bool:
        """Send a message to output destinations."""
        if not self.is_running:
            logger.warning("Output manager not running")
            return False
        
        # If specific output specified, send only to that output
        if output_name:
            if output_name in self.output_configs:
                return await self._process_message(message, output_name)
            else:
                logger.warning(f"Output config '{output_name}' not found")
                return False
        
        # Send to all enabled outputs
        results = []
        for name, config in self.output_configs.items():
            if config.enabled:
                result = await self._process_message(message, name)
                results.append(result)
        
        return any(results)
    
    async def _process_message(self, message: OutputMessage, output_name: str) -> bool:
        """Process a message for a specific output."""
        config = self.output_configs[output_name]
        
        # Check if message should be sent based on filters
        if not OutputFilter.should_send(message, config):
            logger.debug(f"Message filtered out for output {output_name}")
            return False
        
        # Handle batching
        if config.batch_size > 1:
            return await self._add_to_batch(message, output_name)
        else:
            return await self._send_immediate(message, output_name)
    
    async def _add_to_batch(self, message: OutputMessage, output_name: str) -> bool:
        """Add message to batch queue."""
        config = self.output_configs[output_name]
        batch_queue = self.batch_queues[output_name]
        
        batch_queue.append(message)
        
        # Start batch timer if not already running
        if output_name not in self.batch_timers or self.batch_timers[output_name].done():
            self.batch_timers[output_name] = asyncio.create_task(
                self._batch_timer(output_name, config.batch_timeout)
            )
        
        # Send batch if size reached
        if len(batch_queue) >= config.batch_size:
            await self._send_batch(output_name)
        
        return True
    
    async def _batch_timer(self, output_name: str, timeout: float):
        """Timer for batch processing."""
        await asyncio.sleep(timeout)
        await self._send_batch(output_name)
    
    async def _send_batch(self, output_name: str):
        """Send a batch of messages."""
        if output_name not in self.batch_queues:
            return
        
        batch_queue = self.batch_queues[output_name]
        if not batch_queue:
            return
        
        config = self.output_configs[output_name]
        messages = batch_queue.copy()
        batch_queue.clear()
        
        # Cancel timer
        if output_name in self.batch_timers:
            self.batch_timers[output_name].cancel()
            del self.batch_timers[output_name]
        
        # Send batch
        success = await self._send_batch_messages(messages, output_name)
        
        # Update metrics
        if success:
            self.metrics.counter("output_batch_sent").increment(labels={"output": output_name})
            self.metrics.gauge("output_batch_size").set(len(messages), labels={"output": output_name})
        else:
            self.metrics.counter("output_batch_errors").increment(labels={"output": output_name})
    
    async def _send_batch_messages(self, messages: List[OutputMessage], output_name: str) -> bool:
        """Send a batch of messages to the output."""
        config = self.output_configs[output_name]
        
        # Combine messages based on output type
        if config.output_type == OutputType.ANALYTICS_API:
            return await self._send_batch_to_analytics(messages, config)
        elif config.output_type == OutputType.WEBSOCKET:
            return await self._send_batch_to_websocket(messages, config)
        elif config.output_type in [OutputType.TCP_DEVICE, OutputType.UDP_DEVICE, OutputType.MULTICAST_DEVICE]:
            return await self._send_batch_to_device(messages, config)
        
        return False
    
    async def _send_immediate(self, message: OutputMessage, output_name: str) -> bool:
        """Send a message immediately."""
        config = self.output_configs[output_name]
        
        for attempt in range(config.retry_attempts):
            try:
                if config.output_type == OutputType.ANALYTICS_API:
                    success = await self._send_to_analytics(message, config)
                elif config.output_type == OutputType.WEBSOCKET:
                    success = await self._send_to_websocket(message, config)
                elif config.output_type in [OutputType.TCP_DEVICE, OutputType.UDP_DEVICE, OutputType.MULTICAST_DEVICE]:
                    success = await self._send_to_device(message, config)
                else:
                    logger.warning(f"Unknown output type: {config.output_type}")
                    return False
                
                if success:
                    self.metrics.counter("output_sent").increment(labels={"output": output_name})
                    return True
                
            except Exception as e:
                logger.error(f"Output error for {output_name} (attempt {attempt + 1}): {e}")
                self.metrics.counter("output_errors").increment(labels={"output": output_name})
                
                if attempt < config.retry_attempts - 1:
                    await asyncio.sleep(config.retry_delay)
        
        return False
    
    async def _send_to_analytics(self, message: OutputMessage, config: OutputConfig) -> bool:
        """Send message to analytics API."""
        analytics_client = get_analytics_client()
        if not analytics_client:
            logger.warning("Analytics client not available")
            return False
        
        # Format data for analytics
        formatted_data = OutputFormatter.format_for_analytics(message.data, config)
        
        # Determine endpoint based on message type
        endpoint = AnalyticsEndpoint.TRANSACTIONS  # Default
        if "transaction" in str(message.data).lower():
            endpoint = AnalyticsEndpoint.TRANSACTIONS
        elif "metric" in str(message.data).lower():
            endpoint = AnalyticsEndpoint.METRICS
        elif "event" in str(message.data).lower():
            endpoint = AnalyticsEndpoint.EVENTS
        elif "health" in str(message.data).lower():
            endpoint = AnalyticsEndpoint.HEALTH
        
        return await analytics_client.send_message(
            endpoint, 
            formatted_data, 
            priority=message.priority.value,
            message_id=message.message_id
        )
    
    async def _send_to_websocket(self, message: OutputMessage, config: OutputConfig) -> bool:
        """Send message to WebSocket clients."""
        # Format data for WebSocket
        formatted_data = OutputFormatter.format_for_websocket(message.data, config)
        
        # Create WebSocket message
        ws_message = WebSocketMessage(
            type=MessageType.TRANSACTION_EVENT,
            data=formatted_data,
            id=message.message_id
        )
        
        # Broadcast to WebSocket clients
        await broadcast_message(ws_message)
        return True
    
    async def _send_to_device(self, message: OutputMessage, config: OutputConfig) -> bool:
        """Send message to device output."""
        # Format data for device
        formatted_data = OutputFormatter.format_for_device(message.data, config)
        
        # Get device connection details from config
        device_config = config.format_options.get("device_config", {})
        
        if config.output_type == OutputType.TCP_DEVICE:
            host = device_config.get("host", "localhost")
            port = device_config.get("port", 8080)
            connection_id = device_config.get("connection_id")
            return await self.device_manager.send_tcp(host, port, formatted_data, connection_id)
        
        elif config.output_type == OutputType.UDP_DEVICE:
            host = device_config.get("host", "localhost")
            port = device_config.get("port", 8080)
            return await self.device_manager.send_udp(host, port, formatted_data)
        
        elif config.output_type == OutputType.MULTICAST_DEVICE:
            group = device_config.get("group", "224.0.0.1")
            port = device_config.get("port", 8080)
            return await self.device_manager.send_multicast(group, port, formatted_data)
        
        return False
    
    async def _send_batch_to_analytics(self, messages: List[OutputMessage], config: OutputConfig) -> bool:
        """Send batch to analytics API."""
        analytics_client = get_analytics_client()
        if not analytics_client:
            return False
        
        # Combine messages into batch
        batch_data = {
            "batch_id": f"batch_{int(time.time() * 1000)}",
            "timestamp": time.time(),
            "count": len(messages),
            "messages": [OutputFormatter.format_for_analytics(msg.data, config) for msg in messages]
        }
        
        return await analytics_client.send_message(
            AnalyticsEndpoint.TRANSACTIONS,
            batch_data,
            priority=OutputPriority.HIGH.value
        )
    
    async def _send_batch_to_websocket(self, messages: List[OutputMessage], config: OutputConfig) -> bool:
        """Send batch to WebSocket."""
        # Send each message individually for WebSocket
        success = True
        for message in messages:
            if not await self._send_to_websocket(message, config):
                success = False
        
        return success
    
    async def _send_batch_to_device(self, messages: List[OutputMessage], config: OutputConfig) -> bool:
        """Send batch to device."""
        # Combine messages into single payload
        combined_data = {
            "batch": True,
            "timestamp": time.time(),
            "count": len(messages),
            "messages": [msg.data for msg in messages]
        }
        
        # Create temporary message for batch
        batch_message = OutputMessage(
            data=combined_data,
            output_type=config.output_type,
            priority=OutputPriority.HIGH
        )
        
        return await self._send_to_device(batch_message, config)
    
    async def start(self):
        """Start the output manager."""
        self.is_running = True
        logger.info("Enhanced Output Manager started")
    
    async def stop(self):
        """Stop the output manager."""
        self.is_running = False
        
        # Cancel all batch timers
        for timer in self.batch_timers.values():
            timer.cancel()
        
        # Close device connections
        await self.device_manager.close_connections()
        
        logger.info("Enhanced Output Manager stopped")


# Global output manager instance
_output_manager: Optional[EnhancedOutputManager] = None


def get_output_manager() -> Optional[EnhancedOutputManager]:
    """Get the global output manager instance."""
    return _output_manager


def set_output_manager(manager: EnhancedOutputManager) -> None:
    """Set the global output manager instance."""
    global _output_manager
    _output_manager = manager


async def send_output_message(message: OutputMessage, output_name: str = None) -> bool:
    """Send a message using the global output manager."""
    manager = get_output_manager()
    if manager:
        return await manager.send_message(message, output_name)
    else:
        logger.warning("Output manager not available")
        return False 