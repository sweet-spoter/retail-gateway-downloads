"""
WebSocket Server for real-time communication with the web app using FastAPI.

This module provides a WebSocket server that handles:
- Client connections and disconnections
- Message broadcasting to connected clients
- Subscription management for different message types
- Authentication and security
- Error handling and recovery
"""

import asyncio
import json
import logging
import time
from typing import Dict, List, Set, Optional, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
from fastapi import WebSocket, WebSocketDisconnect
from fastapi.websockets import WebSocketState

logger = logging.getLogger(__name__)


class MessageType(str, Enum):
    """Types of messages that can be sent via WebSocket."""
    DEVICE_STATUS = "device_status"
    TRANSACTION_EVENT = "transaction_event"
    LANE_STATUS = "lane_status"
    HEALTH_UPDATE = "health_update"
    ERROR = "error"
    SYSTEM_ALERT = "system_alert"
    CONFIGURATION_UPDATE = "configuration_update"


@dataclass
class WebSocketMessage:
    """Structure for WebSocket messages."""
    type: MessageType
    data: Any
    timestamp: str = field(default_factory=lambda: time.time())
    id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary format."""
        return {
            "type": self.type.value,
            "data": self.data,
            "timestamp": self.timestamp,
            "id": self.id
        }

    def to_json(self) -> str:
        """Convert message to JSON string."""
        return json.dumps(self.to_dict())


@dataclass
class ClientInfo:
    """Information about a connected WebSocket client."""
    websocket: WebSocket
    client_id: str
    connected_at: float
    last_activity: float
    subscriptions: Set[MessageType] = field(default_factory=set)
    user_role: Optional[str] = None
    authenticated: bool = False


class WebSocketServer:
    """
    WebSocket server for real-time communication using FastAPI.
    
    Handles client connections, message broadcasting, and subscription management.
    """

    def __init__(self, max_connections: int = 100):
        self.max_connections = max_connections
        self.clients: Dict[str, ClientInfo] = {}
        self.subscriptions: Dict[MessageType, Set[str]] = {
            msg_type: set() for msg_type in MessageType
        }
        self.is_running = False
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.heartbeat_interval = 30  # seconds
        self.cleanup_interval = 60  # seconds

    async def connect(self, websocket: WebSocket) -> str:
        """Accept a new WebSocket connection."""
        if len(self.clients) >= self.max_connections:
            await websocket.close(code=1013, reason="Maximum connections reached")
            raise WebSocketDisconnect(code=1013, reason="Maximum connections reached")
        
        await websocket.accept()
        
        client_id = f"client_{int(time.time() * 1000)}_{id(websocket)}"
        
        client_info = ClientInfo(
            websocket=websocket,
            client_id=client_id,
            connected_at=time.time(),
            last_activity=time.time()
        )
        
        self.clients[client_id] = client_info
        logger.info(f"Client {client_id} connected. Total clients: {len(self.clients)}")
        
        # Send welcome message
        welcome_msg = WebSocketMessage(
            type=MessageType.SYSTEM_ALERT,
            data={
                "message": "Connected to Gateway Service WebSocket",
                "client_id": client_id,
                "server_time": time.time()
            }
        )
        await websocket.send_text(welcome_msg.to_json())
        
        return client_id

    async def disconnect(self, client_id: str):
        """Disconnect a client."""
        await self._remove_client(client_id)

    async def handle_client(self, websocket: WebSocket, client_id: str):
        """Handle client messages."""
        client_info = self.clients.get(client_id)
        if not client_info:
            return
        
        try:
            while True:
                # Receive message
                message = await websocket.receive_text()
                await self._handle_client_message(client_info, message)
                
        except WebSocketDisconnect:
            logger.info(f"Client {client_id} disconnected")
        except Exception as e:
            logger.error(f"Error handling client {client_id}: {e}")
        finally:
            await self._remove_client(client_id)

    async def _handle_client_message(self, client_info: ClientInfo, message: str) -> None:
        """Handle incoming message from a client."""
        try:
            client_info.last_activity = time.time()
            
            data = json.loads(message)
            msg_type = data.get("type")
            
            if msg_type == "subscribe":
                await self._handle_subscription(client_info, data)
            elif msg_type == "unsubscribe":
                await self._handle_unsubscription(client_info, data)
            elif msg_type == "ping":
                await self._send_pong(client_info)
            elif msg_type == "authenticate":
                await self._handle_authentication(client_info, data)
            else:
                logger.warning(f"Unknown message type from client {client_info.client_id}: {msg_type}")
                
        except json.JSONDecodeError:
            logger.warning(f"Invalid JSON from client {client_info.client_id}")
        except Exception as e:
            logger.error(f"Error handling message from client {client_info.client_id}: {e}")

    async def _handle_subscription(self, client_info: ClientInfo, data: Dict[str, Any]) -> None:
        """Handle client subscription to message types."""
        message_types = data.get("message_types", [])
        
        for msg_type_str in message_types:
            try:
                msg_type = MessageType(msg_type_str)
                client_info.subscriptions.add(msg_type)
                self.subscriptions[msg_type].add(client_info.client_id)
                logger.debug(f"Client {client_info.client_id} subscribed to {msg_type}")
            except ValueError:
                logger.warning(f"Invalid message type: {msg_type_str}")

    async def _handle_unsubscription(self, client_info: ClientInfo, data: Dict[str, Any]) -> None:
        """Handle client unsubscription from message types."""
        message_types = data.get("message_types", [])
        
        for msg_type_str in message_types:
            try:
                msg_type = MessageType(msg_type_str)
                client_info.subscriptions.discard(msg_type)
                self.subscriptions[msg_type].discard(client_info.client_id)
                logger.debug(f"Client {client_info.client_id} unsubscribed from {msg_type}")
            except ValueError:
                logger.warning(f"Invalid message type: {msg_type_str}")

    async def _handle_authentication(self, client_info: ClientInfo, data: Dict[str, Any]) -> None:
        """Handle client authentication."""
        token = data.get("token")
        
        # TODO: Implement proper JWT token validation
        # For now, accept any token as valid
        if token:
            client_info.authenticated = True
            client_info.user_role = data.get("role", "user")
            
            auth_response = WebSocketMessage(
                type=MessageType.SYSTEM_ALERT,
                data={
                    "message": "Authentication successful",
                    "role": client_info.user_role
                }
            )
            await client_info.websocket.send_text(auth_response.to_json())
            logger.info(f"Client {client_info.client_id} authenticated as {client_info.user_role}")
        else:
            auth_response = WebSocketMessage(
                type=MessageType.ERROR,
                data={
                    "message": "Authentication failed",
                    "error": "Invalid token"
                }
            )
            await client_info.websocket.send_text(auth_response.to_json())

    async def _send_pong(self, client_info: ClientInfo) -> None:
        """Send pong response to client ping."""
        pong_msg = WebSocketMessage(
            type=MessageType.SYSTEM_ALERT,
            data={"type": "pong", "timestamp": time.time()}
        )
        await client_info.websocket.send_text(pong_msg.to_json())

    async def _remove_client(self, client_id: str) -> None:
        """Remove a client from the server."""
        client_info = self.clients.get(client_id)
        if not client_info:
            return
        
        # Remove from subscriptions
        for msg_type in client_info.subscriptions:
            self.subscriptions[msg_type].discard(client_id)
        
        # Remove from clients dict
        self.clients.pop(client_id, None)
        
        logger.info(f"Client {client_id} removed. Total clients: {len(self.clients)}")

    async def broadcast_message(self, message: WebSocketMessage) -> None:
        """Broadcast a message to all subscribed clients."""
        await self.message_queue.put(message)

    async def broadcast_to_subscribers(self, message: WebSocketMessage) -> None:
        """Broadcast a message to clients subscribed to the message type."""
        subscribed_clients = self.subscriptions.get(message.type, set())
        
        if not subscribed_clients:
            return
        
        message_json = message.to_json()
        failed_clients = []
        
        for client_id in subscribed_clients:
            client_info = self.clients.get(client_id)
            if client_info and client_info.authenticated:
                try:
                    if client_info.websocket.client_state == WebSocketState.CONNECTED:
                        await client_info.websocket.send_text(message_json)
                    else:
                        failed_clients.append(client_id)
                except Exception as e:
                    logger.warning(f"Failed to send message to client {client_id}: {e}")
                    failed_clients.append(client_id)
        
        # Remove failed clients
        for client_id in failed_clients:
            await self._remove_client(client_id)

    async def _message_broadcaster(self) -> None:
        """Background task to broadcast messages from the queue."""
        while self.is_running:
            try:
                message = await asyncio.wait_for(self.message_queue.get(), timeout=1.0)
                await self.broadcast_to_subscribers(message)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error in message broadcaster: {e}")

    async def _heartbeat_task(self) -> None:
        """Background task to send heartbeat messages and check client health."""
        while self.is_running:
            try:
                current_time = time.time()
                heartbeat_msg = WebSocketMessage(
                    type=MessageType.SYSTEM_ALERT,
                    data={
                        "type": "heartbeat",
                        "timestamp": current_time,
                        "active_clients": len(self.clients)
                    }
                )
                
                # Send heartbeat to all authenticated clients
                failed_clients = []
                for client_info in list(self.clients.values()):
                    if client_info.authenticated:
                        try:
                            if client_info.websocket.client_state == WebSocketState.CONNECTED:
                                await client_info.websocket.send_text(heartbeat_msg.to_json())
                            else:
                                failed_clients.append(client_info.client_id)
                        except Exception as e:
                            logger.warning(f"Failed to send heartbeat to client {client_info.client_id}: {e}")
                            failed_clients.append(client_info.client_id)
                
                # Remove failed clients
                for client_id in failed_clients:
                    await self._remove_client(client_id)
                
                await asyncio.sleep(self.heartbeat_interval)
                
            except Exception as e:
                logger.error(f"Error in heartbeat task: {e}")
                await asyncio.sleep(self.heartbeat_interval)

    async def _cleanup_task(self) -> None:
        """Background task to clean up inactive clients."""
        while self.is_running:
            try:
                current_time = time.time()
                inactive_timeout = 300  # 5 minutes
                
                inactive_clients = []
                for client_info in self.clients.values():
                    if current_time - client_info.last_activity > inactive_timeout:
                        inactive_clients.append(client_info.client_id)
                
                for client_id in inactive_clients:
                    logger.info(f"Removing inactive client {client_id}")
                    await self._remove_client(client_id)
                
                await asyncio.sleep(self.cleanup_interval)
                
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")
                await asyncio.sleep(self.cleanup_interval)

    def get_stats(self) -> Dict[str, Any]:
        """Get server statistics."""
        return {
            "total_clients": len(self.clients),
            "authenticated_clients": len([c for c in self.clients.values() if c.authenticated]),
            "subscriptions": {
                msg_type.value: len(subscribers) 
                for msg_type, subscribers in self.subscriptions.items()
            },
            "is_running": self.is_running,
            "queue_size": self.message_queue.qsize()
        }

    async def send_to_client(self, client_id: str, message: WebSocketMessage) -> bool:
        """Send a message to a specific client."""
        client_info = self.clients.get(client_id)
        if not client_info or not client_info.authenticated:
            return False
        
        try:
            if client_info.websocket.client_state == WebSocketState.CONNECTED:
                await client_info.websocket.send_text(message.to_json())
                return True
            else:
                return False
        except Exception as e:
            logger.warning(f"Failed to send message to client {client_id}: {e}")
            return False

    async def start(self) -> None:
        """Start the WebSocket server background tasks."""
        self.is_running = True
        
        # Start background tasks
        asyncio.create_task(self._message_broadcaster())
        asyncio.create_task(self._heartbeat_task())
        asyncio.create_task(self._cleanup_task())
        
        logger.info("WebSocket server background tasks started")

    async def stop(self) -> None:
        """Stop the WebSocket server."""
        self.is_running = False
        
        # Close all client connections
        for client_info in list(self.clients.values()):
            try:
                await client_info.websocket.close()
            except Exception as e:
                logger.warning(f"Error closing client {client_info.client_id}: {e}")
        
        logger.info("WebSocket server stopped")


# Global WebSocket server instance
_websocket_server: Optional[WebSocketServer] = None


def get_websocket_server() -> Optional[WebSocketServer]:
    """Get the global WebSocket server instance."""
    return _websocket_server


def set_websocket_server(server: WebSocketServer) -> None:
    """Set the global WebSocket server instance."""
    global _websocket_server
    _websocket_server = server


async def broadcast_message(message: WebSocketMessage) -> None:
    """Broadcast a message using the global WebSocket server."""
    server = get_websocket_server()
    if server:
        await server.broadcast_message(message)
    else:
        logger.warning("WebSocket server not available for broadcasting")


async def start_websocket_server() -> WebSocketServer:
    """Start the WebSocket server and return the instance."""
    server = WebSocketServer()
    await server.start()
    set_websocket_server(server)
    return server


async def stop_websocket_server() -> None:
    """Stop the global WebSocket server."""
    server = get_websocket_server()
    if server:
        await server.stop()
        set_websocket_server(None) 