"""
Sessionizer for Gateway Service.

This module provides a state machine that correlates events within time windows
and creates transaction bundles. It handles:
- Event correlation by lane_id, register_id, cashier_id
- Time window management for session closure
- Transaction bundle creation with audit fields
- Idempotency key generation for safe re-delivery
"""

import asyncio
import json
import time
import uuid
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta

from core.logging_config import get_logger
from core.output_manager import (
    OutputMessage, 
    OutputType, 
    OutputPriority,
    send_output_message
)
from core.metrics import get_metrics_registry

logger = get_logger(__name__)


class SessionState(str, Enum):
    """States of a transaction session."""
    IDLE = "idle"
    ACTIVE = "active"
    COMPLETING = "completing"
    COMPLETED = "completed"
    TIMEOUT = "timeout"
    ERROR = "error"


class EventType(str, Enum):
    """Types of events that can be processed."""
    TRANSACTION_START = "transaction_start"
    TRANSACTION_END = "transaction_end"
    PAYMENT_RECEIVED = "payment_received"
    DRAWER_OPEN = "drawer_open"
    DRAWER_CLOSE = "drawer_close"
    SAFE_ACCESS = "safe_access"
    ITEM_SCANNED = "item_scanned"
    DISCOUNT_APPLIED = "discount_applied"
    TAX_CALCULATED = "tax_calculated"
    CASH_TENDERED = "cash_tendered"
    CARD_PAYMENT = "card_payment"
    RECEIPT_PRINTED = "receipt_printed"
    VOID_TRANSACTION = "void_transaction"
    REFUND_ISSUED = "refund_issued"


@dataclass
class SessionEvent:
    """An event within a transaction session."""
    event_type: EventType
    timestamp: float
    data: Dict[str, Any]
    device_id: str
    lane_id: str
    register_id: Optional[str] = None
    cashier_id: Optional[str] = None
    correlation_id: Optional[str] = None
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))


@dataclass
class TransactionSession:
    """A transaction session that correlates events."""
    session_id: str
    lane_id: str
    register_id: Optional[str]
    cashier_id: Optional[str]
    correlation_id: Optional[str]
    created_at: float
    last_activity: float
    state: SessionState
    events: List[SessionEvent] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    audit_trail: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    def add_event(self, event: SessionEvent):
        """Add an event to the session."""
        self.events.append(event)
        self.last_activity = event.timestamp
        
        # Update audit trail
        self.audit_trail.append({
            "timestamp": event.timestamp,
            "event_type": event.event_type.value,
            "device_id": event.device_id,
            "event_id": event.event_id
        })
        
        # Check for potential issues
        self._check_for_warnings(event)
    
    def _check_for_warnings(self, event: SessionEvent):
        """Check for potential issues and add warnings."""
        # Check for duplicate events
        event_count = sum(1 for e in self.events if e.event_type == event.event_type)
        if event_count > 1:
            self.warnings.append(f"Duplicate {event.event_type.value} event detected")
        
        # Check for missing required events
        if self.state == SessionState.ACTIVE:
            event_types = {e.event_type for e in self.events}
            if EventType.TRANSACTION_START in event_types and EventType.TRANSACTION_END not in event_types:
                # Check if session is taking too long
                if time.time() - self.created_at > 300:  # 5 minutes
                    self.warnings.append("Session taking longer than expected")
    
    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the session."""
        event_counts = {}
        for event in self.events:
            event_type = event.event_type.value
            event_counts[event_type] = event_counts.get(event_type, 0) + 1
        
        return {
            "session_id": self.session_id,
            "lane_id": self.lane_id,
            "register_id": self.register_id,
            "cashier_id": self.cashier_id,
            "correlation_id": self.correlation_id,
            "state": self.state.value,
            "created_at": self.created_at,
            "last_activity": self.last_activity,
            "duration": self.last_activity - self.created_at,
            "event_count": len(self.events),
            "event_counts": event_counts,
            "warning_count": len(self.warnings),
            "error_count": len(self.errors)
        }
    
    def create_transaction_bundle(self) -> Dict[str, Any]:
        """Create a transaction bundle from the session."""
        # Sort events by timestamp
        sorted_events = sorted(self.events, key=lambda e: e.timestamp)
        
        # Extract key transaction data
        transaction_data = self._extract_transaction_data(sorted_events)
        
        # Create bundle
        bundle = {
            "bundle_id": str(uuid.uuid4()),
            "session_id": self.session_id,
            "idempotency_key": f"{self.session_id}_{int(self.last_activity * 1000)}",
            "timestamp": self.last_activity,
            "lane_id": self.lane_id,
            "register_id": self.register_id,
            "cashier_id": self.cashier_id,
            "correlation_id": self.correlation_id,
            "state": self.state.value,
            "created_at": self.created_at,
            "completed_at": self.last_activity,
            "duration": self.last_activity - self.created_at,
            "transaction": transaction_data,
            "events": [self._format_event(e) for e in sorted_events],
            "audit_trail": self.audit_trail,
            "metadata": self.metadata,
            "warnings": self.warnings,
            "errors": self.errors,
            "summary": self.get_summary()
        }
        
        return bundle
    
    def _extract_transaction_data(self, events: List[SessionEvent]) -> Dict[str, Any]:
        """Extract key transaction data from events."""
        transaction_data = {
            "total_amount": 0.0,
            "payment_methods": [],
            "items": [],
            "discounts": [],
            "taxes": [],
            "drawer_operations": [],
            "safe_operations": []
        }
        
        for event in events:
            if event.event_type == EventType.PAYMENT_RECEIVED:
                amount = event.data.get("amount", 0.0)
                transaction_data["total_amount"] += amount
                payment_method = event.data.get("payment_method", "unknown")
                if payment_method not in transaction_data["payment_methods"]:
                    transaction_data["payment_methods"].append(payment_method)
            
            elif event.event_type == EventType.ITEM_SCANNED:
                item = {
                    "item_id": event.data.get("item_id"),
                    "description": event.data.get("description"),
                    "quantity": event.data.get("quantity", 1),
                    "unit_price": event.data.get("unit_price", 0.0),
                    "total_price": event.data.get("total_price", 0.0)
                }
                transaction_data["items"].append(item)
            
            elif event.event_type == EventType.DISCOUNT_APPLIED:
                discount = {
                    "type": event.data.get("discount_type"),
                    "amount": event.data.get("discount_amount", 0.0),
                    "reason": event.data.get("discount_reason")
                }
                transaction_data["discounts"].append(discount)
            
            elif event.event_type == EventType.TAX_CALCULATED:
                tax = {
                    "type": event.data.get("tax_type"),
                    "rate": event.data.get("tax_rate", 0.0),
                    "amount": event.data.get("tax_amount", 0.0)
                }
                transaction_data["taxes"].append(tax)
            
            elif event.event_type in [EventType.DRAWER_OPEN, EventType.DRAWER_CLOSE]:
                drawer_op = {
                    "operation": event.event_type.value,
                    "timestamp": event.timestamp,
                    "reason": event.data.get("reason")
                }
                transaction_data["drawer_operations"].append(drawer_op)
            
            elif event.event_type == EventType.SAFE_ACCESS:
                safe_op = {
                    "operation": event.data.get("operation"),
                    "timestamp": event.timestamp,
                    "amount": event.data.get("amount"),
                    "reason": event.data.get("reason")
                }
                transaction_data["safe_operations"].append(safe_op)
        
        return transaction_data
    
    def _format_event(self, event: SessionEvent) -> Dict[str, Any]:
        """Format an event for the bundle."""
        return {
            "event_id": event.event_id,
            "event_type": event.event_type.value,
            "timestamp": event.timestamp,
            "device_id": event.device_id,
            "data": event.data
        }


class Sessionizer:
    """
    Sessionizer that manages transaction sessions and event correlation.
    
    Features:
    - Automatic session creation and management
    - Time-based session closure
    - Event correlation by lane/register/cashier
    - Transaction bundle generation
    - Output to multiple destinations
    """
    
    def __init__(self, session_timeout: float = 300.0, cleanup_interval: float = 60.0):
        self.session_timeout = session_timeout  # 5 minutes default
        self.cleanup_interval = cleanup_interval  # 1 minute default
        self.sessions: Dict[str, TransactionSession] = {}
        self.metrics = get_metrics_registry()
        self.is_running = False
        self.cleanup_task: Optional[asyncio.Task] = None
    
    def get_session_key(self, lane_id: str, register_id: Optional[str] = None, 
                       cashier_id: Optional[str] = None, correlation_id: Optional[str] = None) -> str:
        """Generate a unique session key."""
        if correlation_id:
            return f"session_{correlation_id}"
        else:
            parts = [lane_id]
            if register_id:
                parts.append(register_id)
            if cashier_id:
                parts.append(cashier_id)
            return f"session_{'_'.join(parts)}"
    
    def process_event(self, event_data: Dict[str, Any]) -> Optional[str]:
        """Process an incoming event and return session ID."""
        try:
            # Extract event information
            event_type = EventType(event_data.get("event_type"))
            lane_id = event_data.get("lane_id")
            register_id = event_data.get("register_id")
            cashier_id = event_data.get("cashier_id")
            correlation_id = event_data.get("correlation_id")
            device_id = event_data.get("device_id", "unknown")
            timestamp = event_data.get("timestamp", time.time())
            
            if not lane_id:
                logger.warning("Event missing lane_id, cannot process")
                return None
            
            # Create session event
            event = SessionEvent(
                event_type=event_type,
                timestamp=timestamp,
                data=event_data.get("data", {}),
                device_id=device_id,
                lane_id=lane_id,
                register_id=register_id,
                cashier_id=cashier_id,
                correlation_id=correlation_id
            )
            
            # Get or create session
            session_key = self.get_session_key(lane_id, register_id, cashier_id, correlation_id)
            session = self._get_or_create_session(session_key, event)
            
            # Add event to session
            session.add_event(event)
            
            # Update session state based on event
            self._update_session_state(session, event)
            
            # Check if session should be closed
            if self._should_close_session(session, event):
                asyncio.create_task(self._close_session(session))
            
            # Update metrics
            self.metrics.counter("sessionizer_events_processed").increment()
            self.metrics.gauge("sessionizer_active_sessions").set(len(self.sessions))
            
            # Return the session ID
            return session.session_id
            
        except Exception as e:
            logger.error(f"Error processing event: {e}")
            self.metrics.counter("sessionizer_errors").increment()
            return None
    
    def _get_or_create_session(self, session_key: str, event: SessionEvent) -> TransactionSession:
        """Get existing session or create a new one."""
        if session_key in self.sessions:
            return self.sessions[session_key]
        
        # Create new session
        session = TransactionSession(
            session_id=str(uuid.uuid4()),
            lane_id=event.lane_id,
            register_id=event.register_id,
            cashier_id=event.cashier_id,
            correlation_id=event.correlation_id,
            created_at=event.timestamp,
            last_activity=event.timestamp,
            state=SessionState.IDLE
        )
        
        self.sessions[session_key] = session
        logger.info(f"Created new session: {session.session_id} for lane {event.lane_id}")
        
        return session
    
    def _update_session_state(self, session: TransactionSession, event: SessionEvent):
        """Update session state based on the event."""
        if event.event_type == EventType.TRANSACTION_START:
            session.state = SessionState.ACTIVE
            logger.debug(f"Session {session.session_id} activated")
        
        elif event.event_type == EventType.TRANSACTION_END:
            session.state = SessionState.COMPLETING
            logger.debug(f"Session {session.session_id} completing")
        
        elif event.event_type in [EventType.VOID_TRANSACTION, EventType.REFUND_ISSUED]:
            session.state = SessionState.ERROR
            session.errors.append(f"Transaction {event.event_type.value}")
    
    def _should_close_session(self, session: TransactionSession, event: SessionEvent) -> bool:
        """Determine if a session should be closed."""
        # Close on transaction end
        if event.event_type == EventType.TRANSACTION_END:
            return True
        
        # Close on error state
        if session.state == SessionState.ERROR:
            return True
        
        # Close on timeout (handled by cleanup task)
        if time.time() - session.last_activity > self.session_timeout:
            return True
        
        return False
    
    async def _close_session(self, session: TransactionSession):
        """Close a session and generate outputs."""
        try:
            # Update final state
            if session.state == SessionState.COMPLETING:
                session.state = SessionState.COMPLETED
            elif session.state == SessionState.ACTIVE:
                session.state = SessionState.TIMEOUT
                session.warnings.append("Session closed due to timeout")
            
            # Create transaction bundle
            bundle = session.create_transaction_bundle()
            
            # Send to outputs
            await self._send_session_outputs(session, bundle)
            
            # Remove session
            session_key = self.get_session_key(
                session.lane_id, 
                session.register_id, 
                session.cashier_id, 
                session.correlation_id
            )
            if session_key in self.sessions:
                del self.sessions[session_key]
            
            logger.info(f"Session {session.session_id} closed with state {session.state.value}")
            
            # Update metrics
            self.metrics.counter("sessionizer_sessions_closed").increment(labels={"state": session.state.value})
            
        except Exception as e:
            logger.error(f"Error closing session {session.session_id}: {e}")
            self.metrics.counter("sessionizer_close_errors").increment()
    
    async def _send_session_outputs(self, session: TransactionSession, bundle: Dict[str, Any]):
        """Send session outputs to all configured destinations."""
        try:
            # Create output message for transaction bundle
            bundle_message = OutputMessage(
                data=bundle,
                output_type=OutputType.ANALYTICS_API,
                priority=OutputPriority.HIGH,
                message_id=bundle["bundle_id"],
                correlation_id=session.correlation_id,
                lane_id=session.lane_id,
                register_id=session.register_id,
                cashier_id=session.cashier_id
            )
            
            # Send to analytics API
            await send_output_message(bundle_message, "analytics_api")
            
            # Send live events to WebSocket
            for event in session.events:
                live_message = OutputMessage(
                    data={
                        "session_id": session.session_id,
                        "event": session._format_event(event),
                        "session_summary": session.get_summary()
                    },
                    output_type=OutputType.WEBSOCKET,
                    priority=OutputPriority.NORMAL,
                    message_id=event.event_id,
                    correlation_id=session.correlation_id,
                    lane_id=session.lane_id,
                    register_id=session.register_id,
                    cashier_id=session.cashier_id
                )
                
                await send_output_message(live_message, "websocket")
            
            logger.debug(f"Session {session.session_id} outputs sent")
            
        except Exception as e:
            logger.error(f"Error sending session outputs for {session.session_id}: {e}")
    
    async def _cleanup_expired_sessions(self):
        """Clean up expired sessions."""
        current_time = time.time()
        expired_sessions = []
        
        for session_key, session in self.sessions.items():
            if current_time - session.last_activity > self.session_timeout:
                expired_sessions.append(session)
        
        for session in expired_sessions:
            logger.info(f"Cleaning up expired session {session.session_id}")
            await self._close_session(session)
    
    async def _cleanup_task(self):
        """Background task for cleaning up expired sessions."""
        while self.is_running:
            try:
                await asyncio.sleep(self.cleanup_interval)
                await self._cleanup_expired_sessions()
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")
    
    async def start(self):
        """Start the sessionizer."""
        self.is_running = True
        self.cleanup_task = asyncio.create_task(self._cleanup_task())
        logger.info("Sessionizer started")
    
    async def stop(self):
        """Stop the sessionizer."""
        self.is_running = False
        
        if self.cleanup_task:
            self.cleanup_task.cancel()
            try:
                await self.cleanup_task
            except asyncio.CancelledError:
                pass
        
        # Close all active sessions
        for session in list(self.sessions.values()):
            await self._close_session(session)
        
        logger.info("Sessionizer stopped")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get sessionizer statistics."""
        active_sessions = len(self.sessions)
        session_states = {}
        
        for session in self.sessions.values():
            state = session.state.value
            session_states[state] = session_states.get(state, 0) + 1
        
        return {
            "active_sessions": active_sessions,
            "session_states": session_states,
            "session_timeout": self.session_timeout,
            "cleanup_interval": self.cleanup_interval,
            "is_running": self.is_running
        }


# Global sessionizer instance
_sessionizer: Optional[Sessionizer] = None


def get_sessionizer() -> Optional[Sessionizer]:
    """Get the global sessionizer instance."""
    return _sessionizer


def set_sessionizer(sessionizer: Sessionizer) -> None:
    """Set the global sessionizer instance."""
    global _sessionizer
    _sessionizer = sessionizer


async def process_session_event(event_data: Dict[str, Any]) -> Optional[str]:
    """Process an event using the global sessionizer."""
    sessionizer = get_sessionizer()
    if sessionizer:
        return sessionizer.process_event(event_data)
    else:
        logger.warning("Sessionizer not available")
        return None 