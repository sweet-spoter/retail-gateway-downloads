"""
Abstract base class for all POS device interfaces.
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, Any, Optional
from .streaming_pipeline import StreamingPipeline
from ..pipeline.data_detector import DataDetector

class ProtocolType(Enum):
    TCP = "tcp"
    UDP = "udp"
    SERIAL = "serial"
    SDK = "sdk"

class ConnectionType(Enum):
    LISTEN = "listen"
    CONNECT = "connect"
    ETHERNET = "ethernet"
    SERIAL = "serial"

class POSInterface(ABC):
    """
    Abstract base class for all POS device interfaces.
    Handles device-specific data processing and streaming pipeline integration.
    """
    
    def __init__(self, config: dict):
        self.config = config
        self.device_type = config.get('device_type')
        self.protocol = ProtocolType(config.get('protocol', 'tcp'))
        self.connection_type = ConnectionType(config.get('connection_type', 'listen'))
        self.handshake_required = config.get('handshake_required', False)
        self.ip_connection = config.get('ip_connection')
        self.port_connection = config.get('port_connection')
        self.output_mapping = config.get('output_mapping', 'default_output')
        
        # Initialize streaming pipeline
        from ..pipeline.streaming_wrapper import StreamingWrapper
        self.streaming_pipeline = StreamingWrapper(config)
        self.data_detector = DataDetector()
    
    def process_streaming_data(self, raw_data: bytes) -> dict:
        """
        Main streaming processing: Data → Stream → Detect End → Repeat
        
        Args:
            raw_data: Raw data from the device
            
        Returns:
            dict: Processing result with formatted data and streaming status
        """
        try:
            # Format device-specific data
            formatted_data = self._format_device_data(raw_data)
            
            # Send through streaming pipeline
            device_info = {
                "device_type": self.device_type,
                "device_id": self.config.get('device_id'),
                "protocol": self.protocol.value
            }
            
            result = self.streaming_pipeline.process_streaming_data(
                raw_data, device_info
            )
            
            return {
                "device_type": self.device_type,
                "formatted_data": formatted_data,
                "streaming_result": result,
                "output": self.output_mapping,
                "timestamp": self._get_timestamp()
            }
            
        except Exception as e:
            return {
                "error": str(e),
                "device_type": self.device_type,
                "streaming_result": {"status": "error"},
                "timestamp": self._get_timestamp()
            }
    
    @abstractmethod
    def _format_device_data(self, data: bytes) -> dict:
        """
        Format device-specific data.
        
        Args:
            data: Raw device data
            
        Returns:
            dict: Formatted device data
        """
        pass
    
    @abstractmethod
    def validate_connection(self) -> bool:
        """
        Validate device connection.
        
        Returns:
            bool: True if connection is valid
        """
        pass
    
    def get_device_info(self) -> dict:
        """
        Get device information.
        
        Returns:
            dict: Device information
        """
        return {
            "device_type": self.device_type,
            "protocol": self.protocol.value,
            "connection_type": self.connection_type.value,
            "handshake_required": self.handshake_required,
            "ip_connection": self.ip_connection,
            "port_connection": self.port_connection,
            "output_mapping": self.output_mapping
        }
    
    def _get_timestamp(self) -> str:
        """
        Get current timestamp.
        
        Returns:
            str: ISO formatted timestamp
        """
        from datetime import datetime
        return datetime.now().isoformat() 