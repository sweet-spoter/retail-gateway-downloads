
import datetime
import asyncio

from server.observer import post_event
from config.config import input_configs
from config.config import logger

# result = {"id": device_id, "ip": client_ip, 'register': self.registers[device_id], 'device': self.device_configs[device_id]['name'], 'data': data}
terminals = {
    "terminal_id":{},
    "raw_data": {},
    "pem_timer": {},
    "pcm_timer": {},
    "parse_data":  {},
    "split_msg":  {},
    "sam_cmd": {},
    "hs_number": {},
    "scm_ack": {}
}
msg_indicator = None

# A placeholder to simulate inactivity check
INACTIVITY_TIMEOUT = 60  # Time in seconds

class InfoGenesisMsg:
    def __init__(self, strdata):
        self.msg_date = strdata[7:15]
        self.msg_time = strdata[15:21]
        self.msg_evt_terminal = strdata[21:30]
        self.msg_profit_center = strdata[30:39]
        self.msg_employee = strdata[39:48]
        self.msg_line = strdata[48:88]
        self.msg_line_number = strdata[88:91]
        self.msg_indicator = self.msg_line[:3]
    
    # Define a __repr__ method to give a more readable string when printing the object
    def __repr__(self):
        return (f"InfoGenesisMsg(date={self.msg_date}, time={self.msg_time}, "
                f"terminal={self.msg_evt_terminal}, profit_center={self.msg_profit_center}, "
                f"employee={self.msg_employee}, line={self.msg_line}, "
                f"line_number={self.msg_line_number}, indicator={self.msg_indicator})")

def reset(id):
    terminals['terminal_id'][id] = ""
    terminals['raw_data'][id] = ""
    terminals['parse_data'][id] = None
    terminals['split_msg'][id] = []
    terminals['pem_timer'][id] = datetime.datetime.now()
    terminals['pcm_timer'][id] = datetime.datetime.now()
    terminals['scm_ack'][id] = False

async def process_terminal(term, port, data):
    print("Processing term:", term)
    term_ip = term['term_ip']
    addr = (term_ip, port)
    reset(term_ip)  # Assuming reset is a defined function
    terminals['terminal_id'][term_ip] = term['term_id']
    terminal_num = int(term['term_id'])
    scm = f"\x02SCM1  {datetime.datetime.now():%Y%m%d%H%M%S}000000001001{terminal_num:09d}\x03"
    print("SCM message:", scm)
    result = {"id": data['id'], 'data': scm, 'addr': addr}
    await post_event("input_handshake_send_register_" + data['register'], result)
    await schedule_scm_check(term_ip, data['id'], data['register'], addr)

async def start_handshake(data):
    index =next((index for index, config in enumerate(input_configs) if config.get('register') == data['register']), None)
    if index is None:
        print(f"No configuration found for register {data['register']}")
        return

    print(f"Configuration index: {index}")

    pos_terminals = input_configs[index]['device'].get('terminals', [])
    port = input_configs[index]['port']
    print("pos_terminals:", pos_terminals)

    if not pos_terminals:
        print("No terminals to iterate over.")
        return

    # Run all terminal processing concurrently
    await asyncio.gather(*(process_terminal(term, port,  data) for term in pos_terminals))

    
async def manage_handshake_data(data):
   ip_address, port = data['ip']
   terminals['raw_data'][ip_address] =  process_message_stream(data['data']) 
   print(f"Handshake arrival data {terminals['raw_data'][ip_address]} ")
   
   if contains_special_characters(terminals['raw_data'][ip_address] ):
       
      current_indicator = add_key_if_empty(msg_indicator,ip_address, terminals['raw_data'][ip_address][1:4].upper()) 
      print(f"Infogenesis {current_indicator}")
    
      if current_indicator[ip_address] == "PEM":
        terminals['pem_timer'][ip_address]
        await save_data(ip_address, terminals['terminal_id'][ip_address],  terminals['raw_data'][ip_address],  data['ip'])
      elif current_indicator[ip_address] == "PAM":
        terminals['pem_timer'][ip_address] = datetime.datetime.now()
        terminals['scm_ack'][ip_address] = True
        print(f"PAM commd arrived")
      elif current_indicator[ip_address] == "PCM":
        terminals['hs_number'][ip_address] = terminals['raw_data'][ip_address][21:30]
        # Construct the SAM message
        now = datetime.datetime.now()
        terminals['sam_cmd'][ip_address] = f"\x02SAM1  {now:%Y%m%d%H%M%S}{ terminals['hs_number'][ip_address]:0>9}\x03"
        result = {"id": data['id'],  'data': terminals['sam_cmd'][ip_address], 'addr': data['ip']}
        print(f"PCM commd arrived  {result}")
        await post_event("input_handshake_send_register_" + data['register'], result)
        # await schedule_sam_check( ip_address, data['register'])

async def save_data(id, register, data, addr):
    # Check if data exists; if not, log and return
    if not data:
        logger.debug(f"No data received for register {register} with id {id} and addr {addr}")
        return
    
    # Ensure 'parse_data' exists in terminals
    if 'parse_data' not in terminals:
        terminals['parse_data'][id]= None

    # Check if data is a string and long enough for the expected structure
    if isinstance(data, str) and len(data) >= 88:
        try:
            # Create InfoGenesisMsg object and store it in terminals['parse_data'][id]
            terminals['parse_data'][id] = InfoGenesisMsg(data)

            # Log the message structure
            print(f"message structure {terminals['parse_data'][id]}")
            logger.debug(f"message structure {terminals['parse_data'][id]}")

            # Prepare result dictionary
            result = {
                "id": "output"+str(register),
                'data': terminals['parse_data'][id].msg_line,  # Accessing msg_line
                'addr': addr
            }
            
            # 1. Send Start Transaction and result messages
            logger.debug(f"Sending Start Transaction and result for register {register}")
            logger.debug(f"Sending result {result}")
            await post_event("output_register_" + str(register), {"id":"output"+str(register), "data": "Start Transaction",'addr': addr })
            await post_event("output_register_" + str(register), result)

            # Extract the message line to check for specific keywords
            msg_line = terminals['parse_data'][id].msg_line.lower()  # Make it lowercase for easier comparison

            # Check for the presence of keywords like "close register" or "no sale"
            if "close" in msg_line or "no sale" in msg_line:
                # Send End Transaction message if keywords are found
                logger.debug(f"Found 'close register' or 'no sale' for register {register}. Ending transaction.")
                await post_event("output_register_" + str(register), result)  # Send result before ending
                await post_event("output_register_" + str(register),  {"id":"output"+str(register), "data": "End Transaction",'addr': addr })

                # 3. Send Start Transaction again to restart the process
                logger.debug(f"Restarting transaction for register {register}")
                await post_event("output_register_" + str(register),  {"id":"output"+str(register), "data": "Start Transaction",'addr': addr })
            else:
                # Wait for inactivity timeout before sending End Transaction
                logger.debug(f"Waiting for inactivity timeout for register {register}")
                await asyncio.sleep(INACTIVITY_TIMEOUT)

                # After timeout, send End Transaction
                logger.debug(f"Inactivity timeout reached for register {register}. Ending transaction.")
                await post_event("output_register_" + str(register), result)  # Send result before ending
                await post_event("output_register_" + str(register), {"id":"output"+str(register), "data": "End Transaction",'addr': addr })

                # Restart the process by sending Start Transaction again
                logger.debug(f"Restarting transaction for register {register}")
                await post_event("output_register_" + str(register), {"id":"output"+str(register), "data": "Start Transaction",'addr': addr })

        except KeyError as e:
            logger.error(f"KeyError: 'id' {id} not found in terminals['parse_data']: {e}")
        except Exception as e:
            logger.error(f"An error occurred while processing data for id {id}: {e}")
    else:
        # Log if data is invalid (either not a string or too short)
        logger.error(f"Invalid data received for id {id} and register {register}: {data}")

        
async def schedule_scm_check(id, sock_id, register, addr):
    await asyncio.sleep(1 * 60)  # Wait for 2 minutes
    await check_and_send_scm_command(id, sock_id, register, addr)

async def check_and_send_scm_command(id, sock_id, register, addr):
    global terminals
    current_time = datetime.datetime.now()
    last_received_time = terminals['pem_timer'][id]

    if not last_received_time:
        print(f"No message received yet for terminal {id}.")
        return

    time_difference = current_time - last_received_time
    if time_difference > datetime.timedelta(minutes=3):
        terminals['pem_timer'][id] =  datetime.datetime.now()
        await handle_scm_command(id, sock_id, register, addr)
        await schedule_scm_check(id, sock_id, register, addr)
    else:
        print(f"Terminal {id}: Less than 5 minutes since the last message. Checking again in 5 minutes.")
        await schedule_scm_check(id, sock_id, register, addr)

async def handle_scm_command(id, sock_id, register, addr):
    current_time = datetime.datetime.now()
    date_time_str = current_time.strftime("%Y%m%d%H%M%S")
    scm_command = construct_scm_command(id, register, date_time_str)
    
    result = {"id": sock_id, 'data': scm_command, 'addr': addr}
    event_name = "input_handshake_send_register_" + register
    await post_event(event_name, result)

def construct_scm_command(id, register, date_time_str):
    base_command = f"\x02SCM1  {date_time_str}0000000010"
    # Ensure 'register' is a valid integer
    try:
        term = int(register)
    except ValueError:
        logger.error(f"Error: 'register' value {register} cannot be converted to an integer.")
        term = 0  # Provide a default value if conversion fails
    if terminals['scm_ack'][id]:
        command = f"{base_command}00{term:09d}\x03"
    else:
        terminals['scm_ack'][id] = False
        command = f"{base_command}01{term:09d}\x03"
    return command

async def schedule_sam_check(id , register):
    await asyncio.sleep(5 * 60)  # Wait for 5 minutes
    await check_and_send_command(id, register)
    
async def check_and_send_command(id, register):
    global terminals
    current_time = datetime.datetime.now()
    last_received_time = terminals['timer_started'].get(id)

    if last_received_time is None:
        print(f"No message received yet for terminal {id}.")
        return

    time_difference = current_time - last_received_time
    if time_difference > datetime.timedelta(minutes=5):
        now = datetime.datetime.now()
        terminals['sam_cmd'][id] = f"\x02SAM1  {now:%Y%m%d%H%M%S}{ terminals['hs_number'][id]:0>9}\x03"
        result = {"id": id,  'data': terminals['sam_cmd'][id]}
        await post_event("input_handshake_send_register_" + register, result)
    else:
        print(f"Terminal {id}: Less than 5 minutes since the last message. Checking again in 5 minutes.")
        await schedule_sam_check(id, register)
    
def add_key_if_empty(original_dict, key, value):
    # Check if the dictionary is None or empty
    if original_dict is None or not original_dict:
        # Initialize the dictionary if it is None
        new_dict = {}
        new_dict[key] = value
        return new_dict
    else:
        # Return the original dictionary if it's not empty
        return original_dict.copy()
 
def return_string_pattern(data, first_char, last_char, old_value=""):
        final_result = ""
        sb = ""
        start_saving = False
        try:
            if old_value:
                data = old_value + data
                old_value = ""

            chrs = list(data)

            for i in range(len(chrs)):
                if ord(chrs[i]) == first_char:
                    start_saving = True
                if start_saving:
                    sb += chrs[i]
                if ord(chrs[i]) == last_char:
                    start_saving = False
                    final_result += "{}".format(sb)
                    sb = ""

            if sb:
                old_value = sb

        except Exception:
            return "", old_value

        return final_result, old_value
    
def contains_special_characters(input_string):
    # Define the hex characters to check
    hex_02 = '\x02'
    hex_03 = '\x03'

    # Check if both hex characters are in the input string
    contains_hex_02 = hex_02 in input_string
    contains_hex_03 = hex_03 in input_string

    return contains_hex_02 and contains_hex_03


def process_message_stream(stream):
    start_marker = '╗'
    end_marker = '╚'
    buffer = ""
    messages = []

    def extract_complete_messages(buffer):
        complete_messages = []
        while start_marker in buffer and end_marker in buffer:
            start_index = buffer.find(start_marker)
            end_index = buffer.find(end_marker, start_index) + 1
            complete_message = buffer[start_index:end_index]
            complete_messages.append(complete_message)
            buffer = buffer[end_index:]
        return complete_messages, buffer

    def handle_complete_message(message):
        # Your processing logic here
        print(f"Processed message: {message}")

    buffer += stream
    complete_messages, buffer = extract_complete_messages(buffer)
    
    for message in complete_messages:
        handle_complete_message(message)
    
    return buffer
    
def create_terminals():
    return {
        "raw_data": {},
        "pem_timer": {},
        "pcm_timer": {},
        "parse_data":  {},
        "split_msg":  {},
        "sam_cmd": {},
        "hs_number": {},
        "scm_ack": {}
    }
     
