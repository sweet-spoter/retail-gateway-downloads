import asyncio
import importlib
import ctypes
import subprocess
import json
import logging
import os
import sys
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, Callable
from enum import Enum
from datetime import datetime
import multiprocessing as mp
from multiprocessing import Process, Queue, Pipe

from models.lane_config import SDKConfig, SDKType
from core.device_interfaces import DeviceConnection, DeviceStatus, DeviceEvent, EventType

logger = logging.getLogger(__name__)

class SDKConnectionStatus(str, Enum):
    """SDK connection status"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"
    TIMEOUT = "timeout"
    INITIALIZING = "initializing"

class SDKAdapter(ABC):
    """Abstract base class for SDK adapters"""
    
    def __init__(self, device_id: str, sdk_config: SDKConfig):
        self.device_id = device_id
        self.sdk_config = sdk_config
        self.status = SDKConnectionStatus.DISCONNECTED
        self.last_activity = None
        self.error_count = 0
        self.max_retries = 3
        self.retry_delay = 5  # seconds

    @abstractmethod
    async def initialize(self) -> bool:
        """Initialize the SDK connection"""
        pass

    @abstractmethod
    async def connect(self) -> bool:
        """Connect to the device via SDK"""
        pass

    @abstractmethod
    async def disconnect(self) -> bool:
        """Disconnect from the device"""
        pass

    @abstractmethod
    async def send_data(self, data: Dict[str, Any]) -> bool:
        """Send data to the device via SDK"""
        pass

    @abstractmethod
    async def receive_data(self) -> Optional[Dict[str, Any]]:
        """Receive data from the device via SDK"""
        pass

    @abstractmethod
    async def validate_connection(self) -> bool:
        """Validate the SDK connection"""
        pass

    def update_status(self, status: SDKConnectionStatus, error_message: Optional[str] = None):
        """Update SDK connection status"""
        self.status = status
        self.last_activity = datetime.now()
        if status == SDKConnectionStatus.ERROR:
            self.error_count += 1
        elif status == SDKConnectionStatus.CONNECTED:
            self.error_count = 0

    def is_connected(self) -> bool:
        """Check if SDK is connected"""
        return self.status == SDKConnectionStatus.CONNECTED

    def get_connection_info(self) -> Dict[str, Any]:
        """Get SDK connection information"""
        return {
            "device_id": self.device_id,
            "sdk_type": self.sdk_config.sdk_type.value,
            "status": self.status.value,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "error_count": self.error_count
        }

class PythonSDKAdapter(SDKAdapter):
    """Python SDK adapter for direct module import"""
    
    def __init__(self, device_id: str, sdk_config: SDKConfig):
        super().__init__(device_id, sdk_config)
        self.module = None
        self.sdk_instance = None
        self.connection_params = sdk_config.connection_params or {}

    async def initialize(self) -> bool:
        """Initialize Python SDK module"""
        try:
            logger.info(f"Initializing Python SDK for device {self.device_id}")
            
            # Import the SDK module
            module_name = self.sdk_config.module
            if not module_name:
                raise ValueError("Python SDK requires module name")
            
            self.module = importlib.import_module(module_name)
            
            # Check if module has required methods
            if not hasattr(self.module, 'connect') or not hasattr(self.module, 'disconnect'):
                raise ValueError(f"Python SDK module {module_name} missing required methods")
            
            self.update_status(SDKConnectionStatus.INITIALIZING)
            logger.info(f"Python SDK module {module_name} imported successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Python SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def connect(self) -> bool:
        """Connect to device via Python SDK"""
        try:
            if not self.module:
                logger.error(f"Python SDK module not initialized for device {self.device_id}")
                return False
            
            self.update_status(SDKConnectionStatus.CONNECTING)
            
            # Call the SDK's connect method
            if hasattr(self.module, 'connect'):
                # Handle both sync and async connect methods
                if asyncio.iscoroutinefunction(self.module.connect):
                    self.sdk_instance = await self.module.connect(**self.connection_params)
                else:
                    # Run sync method in thread pool
                    loop = asyncio.get_event_loop()
                    self.sdk_instance = await loop.run_in_executor(
                        None, self.module.connect, **self.connection_params
                    )
            
            if self.sdk_instance:
                self.update_status(SDKConnectionStatus.CONNECTED)
                logger.info(f"Python SDK connected successfully for device {self.device_id}")
                return True
            else:
                self.update_status(SDKConnectionStatus.ERROR)
                return False
                
        except Exception as e:
            logger.error(f"Failed to connect Python SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def disconnect(self) -> bool:
        """Disconnect from device via Python SDK"""
        try:
            if self.sdk_instance and hasattr(self.sdk_instance, 'disconnect'):
                # Handle both sync and async disconnect methods
                if asyncio.iscoroutinefunction(self.sdk_instance.disconnect):
                    await self.sdk_instance.disconnect()
                else:
                    # Run sync method in thread pool
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, self.sdk_instance.disconnect)
            
            self.sdk_instance = None
            self.update_status(SDKConnectionStatus.DISCONNECTED)
            logger.info(f"Python SDK disconnected successfully for device {self.device_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to disconnect Python SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def send_data(self, data: Dict[str, Any]) -> bool:
        """Send data via Python SDK"""
        try:
            if not self.sdk_instance:
                logger.error(f"Python SDK not connected for device {self.device_id}")
                return False
            
            # Call the SDK's send method
            if hasattr(self.sdk_instance, 'send'):
                if asyncio.iscoroutinefunction(self.sdk_instance.send):
                    await self.sdk_instance.send(data)
                else:
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, self.sdk_instance.send, data)
            
            self.last_activity = datetime.now()
            return True
            
        except Exception as e:
            logger.error(f"Failed to send data via Python SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def receive_data(self) -> Optional[Dict[str, Any]]:
        """Receive data via Python SDK"""
        try:
            if not self.sdk_instance:
                logger.error(f"Python SDK not connected for device {self.device_id}")
                return None
            
            # Call the SDK's receive method
            if hasattr(self.sdk_instance, 'receive'):
                if asyncio.iscoroutinefunction(self.sdk_instance.receive):
                    data = await self.sdk_instance.receive()
                else:
                    loop = asyncio.get_event_loop()
                    data = await loop.run_in_executor(None, self.sdk_instance.receive)
                
                self.last_activity = datetime.now()
                return data
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to receive data via Python SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return None

    async def validate_connection(self) -> bool:
        """Validate Python SDK connection"""
        try:
            if not self.sdk_instance:
                return False
            
            # Call the SDK's health check method if available
            if hasattr(self.sdk_instance, 'health_check'):
                if asyncio.iscoroutinefunction(self.sdk_instance.health_check):
                    return await self.sdk_instance.health_check()
                else:
                    loop = asyncio.get_event_loop()
                    return await loop.run_in_executor(None, self.sdk_instance.health_check)
            
            # Default validation - check if instance exists
            return self.sdk_instance is not None
            
        except Exception as e:
            logger.error(f"Failed to validate Python SDK connection for device {self.device_id}: {e}")
            return False

class CppSDKAdapter(SDKAdapter):
    """C++ SDK adapter using ctypes for DLL loading"""
    
    def __init__(self, device_id: str, sdk_config: SDKConfig):
        super().__init__(device_id, sdk_config)
        self.dll = None
        self.connection_handle = None
        self.dll_path = sdk_config.dll_path
        self.connection_params = sdk_config.connection_params or {}

    async def initialize(self) -> bool:
        """Initialize C++ SDK DLL"""
        try:
            logger.info(f"Initializing C++ SDK for device {self.device_id}")
            
            if not self.dll_path:
                raise ValueError("C++ SDK requires DLL path")
            
            # Load the DLL
            if not os.path.exists(self.dll_path):
                raise FileNotFoundError(f"C++ SDK DLL not found: {self.dll_path}")
            
            self.dll = ctypes.CDLL(self.dll_path)
            
            # Set function signatures (common SDK interface)
            self._setup_function_signatures()
            
            self.update_status(SDKConnectionStatus.INITIALIZING)
            logger.info(f"C++ SDK DLL {self.dll_path} loaded successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize C++ SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    def _setup_function_signatures(self):
        """Setup C++ SDK function signatures"""
        try:
            # Common SDK function signatures
            if hasattr(self.dll, 'sdk_connect'):
                self.dll.sdk_connect.argtypes = [ctypes.c_char_p, ctypes.c_int]
                self.dll.sdk_connect.restype = ctypes.c_void_p
            
            if hasattr(self.dll, 'sdk_disconnect'):
                self.dll.sdk_disconnect.argtypes = [ctypes.c_void_p]
                self.dll.sdk_disconnect.restype = ctypes.c_int
            
            if hasattr(self.dll, 'sdk_send'):
                self.dll.sdk_send.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
                self.dll.sdk_send.restype = ctypes.c_int
            
            if hasattr(self.dll, 'sdk_receive'):
                self.dll.sdk_receive.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
                self.dll.sdk_receive.restype = ctypes.c_int
            
            if hasattr(self.dll, 'sdk_health_check'):
                self.dll.sdk_health_check.argtypes = [ctypes.c_void_p]
                self.dll.sdk_health_check.restype = ctypes.c_int
                
        except Exception as e:
            logger.warning(f"Failed to setup C++ SDK function signatures: {e}")

    async def connect(self) -> bool:
        """Connect to device via C++ SDK"""
        try:
            if not self.dll:
                logger.error(f"C++ SDK DLL not loaded for device {self.device_id}")
                return False
            
            self.update_status(SDKConnectionStatus.CONNECTING)
            
            # Call the SDK's connect function
            if hasattr(self.dll, 'sdk_connect'):
                # Prepare connection parameters
                params_str = json.dumps(self.connection_params).encode('utf-8')
                timeout = self.connection_params.get('timeout', 30)
                
                # Run in thread pool to avoid blocking
                loop = asyncio.get_event_loop()
                self.connection_handle = await loop.run_in_executor(
                    None, self.dll.sdk_connect, params_str, timeout
                )
                
                if self.connection_handle:
                    self.update_status(SDKConnectionStatus.CONNECTED)
                    logger.info(f"C++ SDK connected successfully for device {self.device_id}")
                    return True
                else:
                    self.update_status(SDKConnectionStatus.ERROR)
                    return False
            else:
                logger.error(f"C++ SDK missing connect function for device {self.device_id}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to connect C++ SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def disconnect(self) -> bool:
        """Disconnect from device via C++ SDK"""
        try:
            if self.connection_handle and hasattr(self.dll, 'sdk_disconnect'):
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, self.dll.sdk_disconnect, self.connection_handle
                )
                
                self.connection_handle = None
                self.update_status(SDKConnectionStatus.DISCONNECTED)
                logger.info(f"C++ SDK disconnected successfully for device {self.device_id}")
                return result == 0
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to disconnect C++ SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def send_data(self, data: Dict[str, Any]) -> bool:
        """Send data via C++ SDK"""
        try:
            if not self.connection_handle:
                logger.error(f"C++ SDK not connected for device {self.device_id}")
                return False
            
            if hasattr(self.dll, 'sdk_send'):
                data_str = json.dumps(data).encode('utf-8')
                data_len = len(data_str)
                
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, self.dll.sdk_send, self.connection_handle, data_str, data_len
                )
                
                self.last_activity = datetime.now()
                return result == 0
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to send data via C++ SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def receive_data(self) -> Optional[Dict[str, Any]]:
        """Receive data via C++ SDK"""
        try:
            if not self.connection_handle:
                logger.error(f"C++ SDK not connected for device {self.device_id}")
                return None
            
            if hasattr(self.dll, 'sdk_receive'):
                # Create buffer for receiving data
                buffer_size = 4096
                buffer = ctypes.create_string_buffer(buffer_size)
                
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, self.dll.sdk_receive, self.connection_handle, buffer, buffer_size
                )
                
                if result > 0:
                    data_str = buffer.value.decode('utf-8')
                    data = json.loads(data_str)
                    self.last_activity = datetime.now()
                    return data
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to receive data via C++ SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return None

    async def validate_connection(self) -> bool:
        """Validate C++ SDK connection"""
        try:
            if not self.connection_handle:
                return False
            
            if hasattr(self.dll, 'sdk_health_check'):
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None, self.dll.sdk_health_check, self.connection_handle
                )
                return result == 0
            
            return self.connection_handle is not None
            
        except Exception as e:
            logger.error(f"Failed to validate C++ SDK connection for device {self.device_id}: {e}")
            return False

class CSharpSDKAdapter(SDKAdapter):
    """C# SDK adapter using multi-process architecture with IPC"""
    
    def __init__(self, device_id: str, sdk_config: SDKConfig):
        super().__init__(device_id, sdk_config)
        self.process = None
        self.command_queue = None
        self.response_queue = None
        self.assembly_name = sdk_config.assembly
        self.runtime = sdk_config.runtime or "net6.0"
        self.connection_params = sdk_config.connection_params or {}

    async def initialize(self) -> bool:
        """Initialize C# SDK process"""
        try:
            logger.info(f"Initializing C# SDK for device {self.device_id}")
            
            if not self.assembly_name:
                raise ValueError("C# SDK requires assembly name")
            
            # Create IPC queues
            self.command_queue = Queue()
            self.response_queue = Queue()
            
            # Start C# SDK process
            self.process = Process(
                target=self._run_csharp_sdk_process,
                args=(self.assembly_name, self.runtime, self.connection_params, 
                      self.command_queue, self.response_queue)
            )
            self.process.start()
            
            self.update_status(SDKConnectionStatus.INITIALIZING)
            logger.info(f"C# SDK process started for device {self.device_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize C# SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    def _run_csharp_sdk_process(self, assembly_name: str, runtime: str, 
                               connection_params: Dict[str, Any], 
                               command_queue: Queue, response_queue: Queue):
        """Run C# SDK process"""
        try:
            # This would typically launch a .NET process
            # For now, we'll simulate the C# SDK process
            logger.info(f"C# SDK process started for assembly {assembly_name}")
            
            while True:
                try:
                    # Wait for commands from main process
                    command = command_queue.get(timeout=1)
                    
                    if command.get('action') == 'connect':
                        # Simulate connection
                        response = {'status': 'success', 'action': 'connect'}
                        response_queue.put(response)
                    
                    elif command.get('action') == 'disconnect':
                        # Simulate disconnection
                        response = {'status': 'success', 'action': 'disconnect'}
                        response_queue.put(response)
                        break
                    
                    elif command.get('action') == 'send':
                        # Simulate sending data
                        response = {'status': 'success', 'action': 'send'}
                        response_queue.put(response)
                    
                    elif command.get('action') == 'receive':
                        # Simulate receiving data
                        response = {
                            'status': 'success', 
                            'action': 'receive',
                            'data': {'event_type': 'data_received', 'timestamp': datetime.now().isoformat()}
                        }
                        response_queue.put(response)
                    
                    elif command.get('action') == 'health_check':
                        # Simulate health check
                        response = {'status': 'success', 'action': 'health_check'}
                        response_queue.put(response)
                        
                except Exception as e:
                    logger.error(f"C# SDK process error: {e}")
                    response = {'status': 'error', 'error': str(e)}
                    response_queue.put(response)
                    
        except Exception as e:
            logger.error(f"Failed to start C# SDK process: {e}")

    async def connect(self) -> bool:
        """Connect to device via C# SDK"""
        try:
            if not self.process or not self.command_queue:
                logger.error(f"C# SDK process not started for device {self.device_id}")
                return False
            
            self.update_status(SDKConnectionStatus.CONNECTING)
            
            # Send connect command to C# process
            command = {
                'action': 'connect',
                'params': self.connection_params
            }
            self.command_queue.put(command)
            
            # Wait for response
            response = self.response_queue.get(timeout=10)
            
            if response.get('status') == 'success':
                self.update_status(SDKConnectionStatus.CONNECTED)
                logger.info(f"C# SDK connected successfully for device {self.device_id}")
                return True
            else:
                self.update_status(SDKConnectionStatus.ERROR)
                return False
                
        except Exception as e:
            logger.error(f"Failed to connect C# SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def disconnect(self) -> bool:
        """Disconnect from device via C# SDK"""
        try:
            if self.process and self.command_queue:
                # Send disconnect command to C# process
                command = {'action': 'disconnect'}
                self.command_queue.put(command)
                
                # Wait for response
                response = self.response_queue.get(timeout=10)
                
                # Terminate process
                if self.process.is_alive():
                    self.process.terminate()
                    self.process.join(timeout=5)
                
                self.process = None
                self.command_queue = None
                self.response_queue = None
                
                self.update_status(SDKConnectionStatus.DISCONNECTED)
                logger.info(f"C# SDK disconnected successfully for device {self.device_id}")
                return response.get('status') == 'success'
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to disconnect C# SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def send_data(self, data: Dict[str, Any]) -> bool:
        """Send data via C# SDK"""
        try:
            if not self.process or not self.command_queue:
                logger.error(f"C# SDK not connected for device {self.device_id}")
                return False
            
            # Send data command to C# process
            command = {
                'action': 'send',
                'data': data
            }
            self.command_queue.put(command)
            
            # Wait for response
            response = self.response_queue.get(timeout=10)
            
            self.last_activity = datetime.now()
            return response.get('status') == 'success'
            
        except Exception as e:
            logger.error(f"Failed to send data via C# SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return False

    async def receive_data(self) -> Optional[Dict[str, Any]]:
        """Receive data via C# SDK"""
        try:
            if not self.process or not self.command_queue:
                logger.error(f"C# SDK not connected for device {self.device_id}")
                return None
            
            # Send receive command to C# process
            command = {'action': 'receive'}
            self.command_queue.put(command)
            
            # Wait for response
            response = self.response_queue.get(timeout=10)
            
            if response.get('status') == 'success':
                data = response.get('data')
                self.last_activity = datetime.now()
                return data
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to receive data via C# SDK for device {self.device_id}: {e}")
            self.update_status(SDKConnectionStatus.ERROR)
            return None

    async def validate_connection(self) -> bool:
        """Validate C# SDK connection"""
        try:
            if not self.process or not self.command_queue:
                return False
            
            # Send health check command to C# process
            command = {'action': 'health_check'}
            self.command_queue.put(command)
            
            # Wait for response
            response = self.response_queue.get(timeout=5)
            
            return response.get('status') == 'success'
            
        except Exception as e:
            logger.error(f"Failed to validate C# SDK connection for device {self.device_id}: {e}")
            return False

class SDKFactory:
    """Factory for creating SDK adapters"""
    
    @staticmethod
    def create_sdk_adapter(device_id: str, sdk_config: SDKConfig) -> Optional[SDKAdapter]:
        """Create SDK adapter based on SDK type"""
        try:
            sdk_type = sdk_config.sdk_type
            
            if sdk_type == SDKType.PYTHON:
                return PythonSDKAdapter(device_id, sdk_config)
            elif sdk_type == SDKType.CPP:
                return CppSDKAdapter(device_id, sdk_config)
            elif sdk_type == SDKType.CSHARP:
                return CSharpSDKAdapter(device_id, sdk_config)
            else:
                logger.error(f"Unsupported SDK type: {sdk_type}")
                return None
                
        except Exception as e:
            logger.error(f"Failed to create SDK adapter for device {device_id}: {e}")
            return None 