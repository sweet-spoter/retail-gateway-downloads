#!/usr/bin/env python3
"""
SmarttillAPI Python Wrapper

A simple, easy-to-use wrapper for the SmarttillAPI.dll cash drawer.
This wrapper provides a clean Python interface to the .NET Core SmarttillAPI.
"""

import os
import sys
import time
import threading
from typing import Optional, List, Callable, Any


class SmarttillWrapper:
    """
    A simple wrapper for SmarttillAPI.dll cash drawer functionality.
    
    This wrapper provides an easy-to-use Python interface for:
    - Connecting to cash drawers (Ethernet/Serial)
    - Checking drawer status
    - Performing transactions (Sale, Topup, Pickup, Reset)
    - Getting till information
    - Event handling
    """
    
    def __init__(self):
        """Initialize the SmarttillAPI wrapper"""
        self.smarttill = None
        self.connected = False
        self.connection_type = None
        self.data_handlers = []
        self.log_handlers = []
        self._setup_dotnet()
    
    def _setup_dotnet(self):
        """Setup .NET Core runtime and load SmarttillAPI.dll (simplified like windows_dotnet_test.py)"""
        try:
            # Set environment for .NET Core (same as working test)
            os.environ['PYTHONNET_RUNTIME'] = 'coreclr'
            os.environ['COMPLUS_LoadFromRemoteSources'] = '1'
            os.environ['DOTNET_LoadFromRemoteSources'] = '1'
            
            import pythonnet
            pythonnet.load()
            print("✓ pythonnet loaded with .NET Core")
            
            import clr
            from System import String, Int32, Boolean, EventHandler
            print("✓ clr and System modules imported")
            
            # Load SmarttillAPI.dll from libs/net8.0/ directory
            dll_path = os.path.join(os.path.dirname(__file__), "libs", "net8.0", "SmarttillAPI.dll")
            if not os.path.exists(dll_path):
                raise FileNotFoundError(f"SmarttillAPI.dll not found at {dll_path}")
            
            print(f"✓ Found SmarttillAPI.dll at {dll_path}")
            
            # Add reference to the DLL (same as working test)
            clr.AddReference(dll_path)
            print("✓ DLL reference added")
            
            # Import SmarttillAPI namespace (same as working test)
            import SmarttillAPI
            print("✓ SmarttillAPI namespace imported")
            
            # Create SmartCashDrawer instance (same as working test)
            self.smarttill = SmarttillAPI.SmartCashDrawer()
            print("✓ SmartCashDrawer instance created")
            
        except Exception as e:
            # Check if we're on a non-Windows platform
            import platform
            if platform.system() != 'Windows':
                print(f"⚠️  SmarttillAPI.dll is Windows-only. Running in mock mode on {platform.system()}")
                self._setup_mock_mode()
            else:
                raise RuntimeError(f"Failed to load SmarttillAPI: {e}")
    
    def _setup_mock_mode(self):
        """Setup mock mode for non-Windows platforms"""
        print("🔧 Setting up Smarttill mock mode for testing")
        self.smarttill = MockSmarttillAPI()
        self.mock_mode = True
    
    def find_cash_drawers(self) -> list:
        """
        Find available cash drawers on the network
        
        Returns:
            list: List of found cash drawer information (IP addresses, MAC addresses, etc.)
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            # Set up event handler to capture found devices
            found_devices = []
            
            def device_found_handler(sender, data):
                """Handle device discovery events and PRM messages"""
                if data and ":" in data:
                    parts = data.split(":")
                    if len(parts) >= 2:
                        device_info = {
                            'type': parts[0],
                            'data': parts[1:],
                            'raw': data
                        }
                        found_devices.append(device_info)
                        
                        # Handle different message types
                        if parts[0] == "PRM":
                            # PRM = User prompt message for calibration
                            prm_messages = parts[1:4] if len(parts) >= 4 else parts[1:]
                            print(f"📋 PRM Message: {' | '.join(prm_messages)}")
                        elif parts[0] == "DIS":
                            # DIS = Discrepancy report
                            print(f"📊 Discrepancy Report: {data}")
                        elif parts[0] == "MVT":
                            # MVT = Movement count
                            print(f"🔄 Movement Count: {data}")
                        elif parts[0] == "TIL":
                            # TIL = Till count update
                            print(f"💰 Till Count Update: {data}")
                        else:
                            print(f"✓ Found device: {data}")
            
            # Check if SmarttillDataReady event exists and is not None
            if hasattr(self.smarttill, 'SmarttillDataReady') and self.smarttill.SmarttillDataReady is not None:
                try:
                    # Subscribe to data events temporarily
                    self.smarttill.SmarttillDataReady += device_found_handler
                    print("✓ Event handler subscribed")
                except Exception as e:
                    print(f"⚠️  Could not subscribe to SmarttillDataReady event: {e}")
            else:
                print("⚠️  SmarttillDataReady event not available or is None")
            
            # Call the Ethernet_FindCashDrawers method
            result = self.smarttill.Ethernet_FindCashDrawers()
            
            if result == 0:
                print("✓ Cash drawer search completed successfully")
                # Wait a moment for devices to be discovered
                import time
                time.sleep(3)  # Increased wait time
                
                # Unsubscribe from events if we subscribed
                if hasattr(self.smarttill, 'SmarttillDataReady') and self.smarttill.SmarttillDataReady is not None:
                    try:
                        self.smarttill.SmarttillDataReady -= device_found_handler
                        print("✓ Event handler unsubscribed")
                    except Exception as e:
                        print(f"⚠️  Could not unsubscribe from SmarttillDataReady event: {e}")
                
                # If no devices found via events, return a simple success message
                if not found_devices:
                    print("ℹ️  No devices found via events, but search completed successfully")
                    print("💡 Try connecting directly with known IP addresses or MAC addresses")
                    # Return a placeholder to indicate search was successful
                    return [{'type': 'SEARCH_COMPLETE', 'data': ['Search completed, no devices found via events'], 'raw': 'SEARCH_COMPLETE:Search completed, no devices found via events'}]
                
                return found_devices
            else:
                print(f"✗ Cash drawer search failed (result: {result})")
                return []
                
        except Exception as e:
            print(f"✗ Cash drawer search failed: {e}")
            return []
    
    def open_drawer(self) -> bool:
        """
        Open the cash drawer directly
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            # Try to find an OpenDrawer method
            if hasattr(self.smarttill, 'OpenDrawer'):
                result = self.smarttill.OpenDrawer()
                if result == 0:
                    print("✓ Drawer opened successfully")
                    return True
                else:
                    print(f"✗ Failed to open drawer (result: {result})")
                    return False
            else:
                # Fallback: Use a sale transaction with £0.00 to open drawer
                print("⚠️  OpenDrawer method not found, using £0.00 sale to open drawer")
                result = self.smarttill.DoSale(99999, 1, "0", "0")  # £0.00 sale
                if result == 0:
                    print("✓ Drawer opened using £0.00 sale")
                    return True
                else:
                    print(f"✗ Failed to open drawer with £0.00 sale (result: {result})")
                    return False
                
        except Exception as e:
            print(f"✗ Open drawer failed: {e}")
            return False

    def connect_ethernet(self, device_id: str, port: int = 8086) -> bool:
        """
        Connect to cash drawer via Ethernet
        
        Args:
            device_id: IP address or MAC address of the cash drawer
            port: Port number (default: 8086)
            
        Returns:
            bool: True if connection successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            # Set server IP and port (for IP addresses)
            if self._is_ip_address(device_id):
                self.smarttill.server_ip = device_id
                self.smarttill.server_port = port
                print(f"Connecting to IP address: {device_id}:{port}")
            else:
                print(f"Connecting to MAC address: {device_id}")
            
            # Attempt connection using the device_id (IP or MAC)
            result = self.smarttill.Ethernet_Connect(device_id)
            
            if result == 0:  # Success
                self.connected = True
                self.connection_type = "ethernet"
                print(f"✓ Connected to cash drawer at {device_id}")
                return True
            else:
                print(f"✗ Failed to connect to {device_id} (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Ethernet connection failed: {e}")
            return False
    
    def _is_ip_address(self, address: str) -> bool:
        """Check if the address is an IP address or MAC address"""
        import re
        # Simple IP address pattern
        ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
        return bool(re.match(ip_pattern, address))
    
    def connect_serial(self, device_id: str, baudrate: int = 19200) -> bool:
        """
        Connect to cash drawer via Serial port
        
        Args:
            device_id: Serial port device ID (e.g., "COM1", "/dev/ttyUSB0")
            baudrate: Baud rate (default: 19200)
            
        Returns:
            bool: True if connection successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            # Attempt serial connection
            result = self.smarttill.Serial_Connect(device_id)
            
            if result == 0:  # Success
                self.connected = True
                self.connection_type = "serial"
                print(f"✓ Connected to cash drawer via {device_id} at {baudrate} baud")
                return True
            else:
                print(f"✗ Failed to connect via {device_id} (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Serial connection failed: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from the cash drawer"""
        try:
            if self.connected:
                # Note: SmarttillAPI doesn't have an explicit disconnect method
                # The connection will be closed when the object is destroyed
                self.connected = False
                self.connection_type = None
                print("✓ Disconnected from cash drawer")
        except Exception as e:
            print(f"✗ Disconnect failed: {e}")
    
    def is_connected(self) -> bool:
        """Check if cash drawer is connected"""
        try:
            if not self.smarttill:
                return False
            return self.smarttill.IsCashDrawerConnected() == 1
        except Exception as e:
            print(f"✗ Connection check failed: {e}")
            return False
    
    def is_drawer_open(self) -> bool:
        """Check if cash drawer is open"""
        try:
            if not self.smarttill:
                return False
            return self.smarttill.IsCashDrawerOpen() == 1
        except Exception as e:
            print(f"✗ Drawer status check failed: {e}")
            return False
    
    def is_weighing(self) -> bool:
        """Check if cash drawer is weighing"""
        try:
            if not self.smarttill:
                return False
            return self.smarttill.IsCashDrawerWeighing() == 1
        except Exception as e:
            print(f"✗ Weighing status check failed: {e}")
            return False
    
    def get_till_count(self) -> List[int]:
        """Get current till count for each denomination"""
        try:
            if not self.smarttill:
                return []
            till_count = self.smarttill.CurrentTillCount()
            return list(till_count) if till_count else []
        except Exception as e:
            print(f"✗ Till count retrieval failed: {e}")
            return []
    
    def get_till_value(self) -> int:
        """Get current till value in pence"""
        try:
            if not self.smarttill:
                return 0
            return self.smarttill.CurrentTillValueInPence()
        except Exception as e:
            print(f"✗ Till value retrieval failed: {e}")
            return 0
    
    def get_firmware_version(self) -> str:
        """Get cash drawer firmware version"""
        try:
            if not self.smarttill:
                return "Unknown"
            version = self.smarttill.CurrentFirmwareVersion()
            return str(version) if version else "Unknown"
        except Exception as e:
            print(f"✗ Firmware version retrieval failed: {e}")
            return "Unknown"
    
    def do_sale(self, receipt_number: int, cashier_id: int, sale_amount_pence: int, change_pence: int = 0) -> bool:
        """
        Perform a sale transaction
        
        Args:
            receipt_number: Receipt number
            cashier_id: Cashier ID
            sale_amount_pence: Sale amount in pence
            change_pence: Change amount in pence (default: 0)
            
        Returns:
            bool: True if transaction successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            result = self.smarttill.DoSale(receipt_number, cashier_id, str(sale_amount_pence), str(change_pence))
            
            if result == 0:
                print(f"✓ Sale transaction successful: Receipt {receipt_number}, Amount: {sale_amount_pence/100:.2f}")
                return True
            else:
                print(f"✗ Sale transaction failed (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Sale transaction failed: {e}")
            return False
    
    def do_topup(self, receipt_number: int, cashier_id: int) -> bool:
        """
        Perform a topup transaction
        
        Args:
            receipt_number: Receipt number
            cashier_id: Cashier ID
            
        Returns:
            bool: True if transaction successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            result = self.smarttill.DoTopup(receipt_number, cashier_id)
            
            if result == 0:
                print(f"✓ Topup transaction successful: Receipt {receipt_number}")
                return True
            else:
                print(f"✗ Topup transaction failed (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Topup transaction failed: {e}")
            return False
    
    def do_pickup(self, receipt_number: int, cashier_id: int) -> bool:
        """
        Perform a pickup transaction
        
        Args:
            receipt_number: Receipt number
            cashier_id: Cashier ID
            
        Returns:
            bool: True if transaction successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            result = self.smarttill.DoPickup(receipt_number, cashier_id)
            
            if result == 0:
                print(f"✓ Pickup transaction successful: Receipt {receipt_number}")
                return True
            else:
                print(f"✗ Pickup transaction failed (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Pickup transaction failed: {e}")
            return False
    
    def do_reset(self, receipt_number: int, cashier_id: int) -> bool:
        """
        Perform a reset transaction
        
        Args:
            receipt_number: Receipt number
            cashier_id: Cashier ID
            
        Returns:
            bool: True if transaction successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            result = self.smarttill.DoReset(receipt_number, cashier_id)
            
            if result == 0:
                print(f"✓ Reset transaction successful: Receipt {receipt_number}")
                return True
            else:
                print(f"✗ Reset transaction failed (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Reset transaction failed: {e}")
            return False
    
    def set_till_number(self, till_number: int, till_name: str) -> bool:
        """
        Set till number and name
        
        Args:
            till_number: Till number
            till_name: Till name
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            result = self.smarttill.Set_TillNumber(till_number, till_name)
            
            if result == 1:
                print(f"✓ Till number set: {till_number} - {till_name}")
                return True
            else:
                print(f"✗ Failed to set till number (result: {result})")
                return False
                
        except Exception as e:
            print(f"✗ Set till number failed: {e}")
            return False
    
    def get_pos_message(self) -> str:
        """Get POS message from cash drawer"""
        try:
            if not self.smarttill:
                return ""
            message = self.smarttill.GetPosMessage()
            return str(message) if message else ""
        except Exception as e:
            print(f"✗ Get POS message failed: {e}")
            return ""
    
    def do_calibrate(self, cashier_id: int, receipt_number: int) -> bool:
        """Start calibration process"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return False
            
            result = self.smarttill.DoCalibrate(cashier_id, receipt_number)
            success = result == 1
            if success:
                print(f"✓ Calibration started successfully (receipt: {receipt_number}, cashier: {cashier_id})")
            else:
                print(f"✗ Calibration failed with result: {result}")
            return success
        except Exception as e:
            print(f"✗ Calibration failed: {e}")
            return False
    
    def do_hard_reset(self, receipt_number: int, cashier_id: int) -> bool:
        """Start hard reset/GRZ transaction"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return False
            
            result = self.smarttill.DoHardReset(receipt_number, cashier_id)
            success = result == 1
            if success:
                print(f"✓ Hard reset started successfully (receipt: {receipt_number}, cashier: {cashier_id})")
            else:
                print(f"✗ Hard reset failed with result: {result}")
            return success
        except Exception as e:
            print(f"✗ Hard reset failed: {e}")
            return False
    
    def confirm_key0(self) -> bool:
        """Cancel calibration (Key 0)"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return False
            
            self.smarttill.ConfirmKey0()
            print("✓ Key 0 (Cancel) sent")
            return True
        except Exception as e:
            print(f"✗ Key 0 confirmation failed: {e}")
            return False
    
    def confirm_key1(self) -> bool:
        """Confirm calibration step (Key 1)"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return False
            
            self.smarttill.ConfirmKey1()
            print("✓ Key 1 (Confirm) sent")
            return True
        except Exception as e:
            print(f"✗ Key 1 confirmation failed: {e}")
            return False
    
    def get_cup_weights(self) -> List[float]:
        """Get current cup weights from last calibration"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return []
            
            weights = self.smarttill.CupWeights()
            if weights is not None:
                # Convert to Python list of floats
                weight_list = [float(w) for w in weights]
                print(f"✓ Cup weights retrieved: {len(weight_list)} values")
                return weight_list
            else:
                print("⚠️  No cup weights available")
                return []
        except Exception as e:
            print(f"✗ Get cup weights failed: {e}")
            return []
    
    def get_calibration_weights(self) -> List[float]:
        """Get calibration weights from last calibration"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return []
            
            weights = self.smarttill.CalibrationWeights()
            if weights is not None:
                # Convert to Python list of floats
                weight_list = [float(w) for w in weights]
                print(f"✓ Calibration weights retrieved: {len(weight_list)} values")
                return weight_list
            else:
                print("⚠️  No calibration weights available")
                return []
        except Exception as e:
            print(f"✗ Get calibration weights failed: {e}")
            return []
    
    def get_last_discrepancy_value(self) -> int:
        """Get last discrepancy value in pence"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return 0
            
            discrepancy = self.smarttill.LastDiscrepancyValueInPence()
            if discrepancy is not None:
                print(f"✓ Last discrepancy value: {discrepancy} pence (£{discrepancy/100:.2f})")
                return int(discrepancy)
            else:
                print("⚠️  No discrepancy value available")
                return 0
        except Exception as e:
            print(f"✗ Get last discrepancy value failed: {e}")
            return 0
    
    def do_bulk_deposit(self) -> bool:
        """Initiate bulk deposit"""
        try:
            if not self.connected:
                print("✗ Not connected to cash drawer")
                return False
            
            self.smarttill.DoBulkDeposit()
            print("✓ Bulk deposit initiated")
            return True
        except Exception as e:
            print(f"✗ Bulk deposit failed: {e}")
            return False
    
    def on_data_received(self, callback: Callable[[Any, Any], None]):
        """
        Register a callback for data received events
        
        Args:
            callback: Function to call when data is received
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            if hasattr(self.smarttill, 'SmarttillDataReady'):
                # Store the callback
                self.data_handlers.append(callback)
                
                # Try to subscribe to the event
                if hasattr(self.smarttill.SmarttillDataReady, 'add'):
                    self.smarttill.SmarttillDataReady.add(callback)
                    print("✓ Data event handler registered")
                else:
                    print("⚠️  Data event exists but cannot subscribe")
            else:
                print("⚠️  SmarttillDataReady event not available")
                
        except Exception as e:
            print(f"✗ Failed to register data event handler: {e}")
    
    def on_log_message(self, callback: Callable[[Any, Any], None]):
        """
        Register a callback for log messages
        
        Args:
            callback: Function to call when log messages are received
        """
        try:
            if not self.smarttill:
                raise RuntimeError("SmarttillAPI not loaded")
            
            if hasattr(self.smarttill, 'NewLogEvent'):
                # Store the callback
                self.log_handlers.append(callback)
                
                # Try to subscribe to the event
                if hasattr(self.smarttill.NewLogEvent, 'add'):
                    self.smarttill.NewLogEvent.add(callback)
                    print("✓ Log event handler registered")
                else:
                    print("⚠️  Log event exists but cannot subscribe")
            else:
                print("⚠️  NewLogEvent not available")
                
        except Exception as e:
            print(f"✗ Failed to register log event handler: {e}")
    
    def get_status(self) -> dict:
        """
        Get comprehensive status of the cash drawer
        
        Returns:
            dict: Status information
        """
        try:
            status = {
                'connected': self.is_connected(),
                'connection_type': self.connection_type,
                'drawer_open': self.is_drawer_open(),
                'weighing': self.is_weighing(),
                'till_count': self.get_till_count(),
                'till_value_pence': self.get_till_value(),
                'till_value_pounds': self.get_till_value() / 100.0,
                'firmware_version': self.get_firmware_version(),
                'pos_message': self.get_pos_message()
            }
            return status
        except Exception as e:
            print(f"✗ Status retrieval failed: {e}")
            return {}
    
    def __del__(self):
        """Cleanup when object is destroyed"""
        try:
            if self.connected:
                print("🔄 Auto-disconnecting from cash drawer...")
                self.disconnect()
                print("✓ Auto-disconnect completed")
        except Exception as e:
            print(f"⚠️  Error during auto-disconnect: {e}")
    
    def cleanup(self):
        """Explicit cleanup method for graceful shutdown"""
        try:
            if self.connected:
                print("🔄 Cleaning up cash drawer connection...")
                self.disconnect()
                print("✓ Cleanup completed")
        except Exception as e:
            print(f"⚠️  Error during cleanup: {e}")


class MockSmarttillAPI:
    """
    Mock SmarttillAPI for testing on non-Windows platforms.
    Provides the same interface as the real SmarttillAPI.dll
    """
    
    def __init__(self):
        self.connected = False
        self.drawer_open = False
        self.weighing = False
        self.till_value = 5000  # £50.00 in pence
        self.firmware_version = "Mock-1.0.0"
        self.server_ip = None
        self.server_port = None
    
    def Ethernet_Connect(self, device_id):
        """Mock Ethernet connection"""
        print(f"🔧 Mock: Connecting to {device_id}")
        self.connected = True
        return 0  # Success
    
    def Ethernet_FindCashDrawers(self):
        """Mock cash drawer search"""
        print("🔧 Mock: Searching for cash drawers")
        return 0  # Success
    
    def IsCashDrawerConnected(self):
        """Mock connection check"""
        return 1 if self.connected else 0
    
    def IsCashDrawerOpen(self):
        """Mock drawer status check"""
        return 1 if self.drawer_open else 0
    
    def IsCashDrawerWeighing(self):
        """Mock weighing status check"""
        return 1 if self.weighing else 0
    
    def CurrentTillValueInPence(self):
        """Mock till value"""
        return self.till_value
    
    def CurrentFirmwareVersion(self):
        """Mock firmware version"""
        return self.firmware_version
    
    def DoSale(self, receipt_number, cashier_id, amount, change):
        """Mock sale transaction"""
        print(f"🔧 Mock: Sale transaction - Receipt: {receipt_number}, Amount: {amount}")
        return 0  # Success
    
    def DoTopup(self, receipt_number, cashier_id):
        """Mock topup transaction"""
        print(f"🔧 Mock: Topup transaction - Receipt: {receipt_number}")
        return 0  # Success
    
    def DoPickup(self, receipt_number, cashier_id):
        """Mock pickup transaction"""
        print(f"🔧 Mock: Pickup transaction - Receipt: {receipt_number}")
        return 0  # Success
    
    def DoReset(self, receipt_number, cashier_id):
        """Mock reset transaction"""
        print(f"🔧 Mock: Reset transaction - Receipt: {receipt_number}")
        return 0  # Success
    
    def OpenDrawer(self):
        """Mock drawer opening"""
        print("🔧 Mock: Opening drawer")
        self.drawer_open = True
        return 0  # Success


# Example usage
if __name__ == "__main__":
    print("SmarttillAPI Python Wrapper")
    print("=" * 40)
    
    try:
        # Create wrapper instance
        drawer = SmarttillWrapper()
        
        # Test basic functionality
        print("\nTesting basic functionality...")
        status = drawer.get_status()
        print(f"Status: {status}")
        
        # Test connection (this will fail without a real device)
        print("\nTesting connection...")
        connected = drawer.connect_ethernet("30-68-93-AB-97-A1")
        print(f"Connected: {connected}")
        
        # Test transactions (these will fail without a real device)
        print("\nTesting transactions...")
        drawer.do_sale(12345, 1, 1000, 0)  # £10.00 sale
        drawer.do_topup(12346, 1)
        drawer.do_pickup(12347, 1)
        drawer.do_reset(12348, 1)
        
        print("\n✓ Wrapper test completed successfully!")
        
    except Exception as e:
        print(f"✗ Wrapper test failed: {e}")
        import traceback
        traceback.print_exc()