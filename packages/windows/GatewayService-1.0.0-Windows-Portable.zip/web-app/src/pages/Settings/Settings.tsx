import React from 'react';
import { Helmet } from 'react-helmet-async';

const Settings: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Settings - Gateway Service</title>
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="mt-1 text-sm text-gray-500">
            Configure application settings and preferences
          </p>
        </div>

        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="text-center">
              <h3 className="text-lg font-medium text-gray-900">Application Settings</h3>
              <p className="mt-2 text-sm text-gray-500">
                This page will contain user preferences, system settings, and configuration options.
              </p>
              <div className="mt-4">
                <div className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100">
                  Coming Soon
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Settings; 