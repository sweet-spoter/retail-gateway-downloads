"""
Verifone TCP POS device implementation.
"""

import socket
from typing import Dict, Any
from ...base.pos_interface import POSInterface, ProtocolType, ConnectionType

class VerifoneInterface(POSInterface):
    """
    Verifone TCP POS device interface.
    Handles Verifone-specific data formatting and connection validation.
    """
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.device_type = "verifone"
        self.handshake_required = False  # Verifone doesn't require handshake
        
        # Verifone-specific configuration
        self.terminal_id = config.get('terminal_id', '')
        self.merchant_id = config.get('merchant_id', '')
        self.transaction_timeout = config.get('transaction_timeout', 30)
        
        # Connection socket
        self.connection_socket: socket.socket = None
    
    def _format_device_data(self, data: bytes) -> dict:
        """
        Format Verifone-specific device data.
        
        Args:
            data: Raw Verifone data
            
        Returns:
            dict: Formatted Verifone data
        """
        try:
            # Convert bytes to string for parsing
            data_str = data.decode('utf-8', errors='ignore').strip()
            
            # Parse Verifone data format
            formatted_data = {
                "device_type": "verifone",
                "terminal_id": self.terminal_id,
                "merchant_id": self.merchant_id,
                "raw_data": data_str,
                "data_length": len(data),
                "data_hex": data.hex(),
                "parsed_fields": self._parse_verifone_data(data_str)
            }
            
            return formatted_data
            
        except Exception as e:
            return {
                "device_type": "verifone",
                "error": f"Failed to format Verifone data: {str(e)}",
                "raw_data": data.hex(),
                "data_length": len(data)
            }
    
    def _parse_verifone_data(self, data_str: str) -> dict:
        """
        Parse Verifone-specific data fields.
        
        Args:
            data_str: Verifone data string
            
        Returns:
            dict: Parsed Verifone fields
        """
        parsed_fields = {}
        
        try:
            # Common Verifone field separators
            if '|' in data_str:
                # Pipe-separated format
                fields = data_str.split('|')
                parsed_fields = {
                    "format": "pipe_separated",
                    "field_count": len(fields),
                    "fields": fields
                }
            elif ',' in data_str:
                # Comma-separated format
                fields = data_str.split(',')
                parsed_fields = {
                    "format": "comma_separated",
                    "field_count": len(fields),
                    "fields": fields
                }
            elif '\x1C' in data_str:
                # Field separator format
                fields = data_str.split('\x1C')
                parsed_fields = {
                    "format": "field_separator",
                    "field_count": len(fields),
                    "fields": fields
                }
            else:
                # Raw format
                parsed_fields = {
                    "format": "raw",
                    "data": data_str
                }
            
            # Try to extract common Verifone fields
            if "fields" in parsed_fields:
                fields = parsed_fields["fields"]
                if len(fields) >= 3:
                    parsed_fields["transaction_type"] = fields[0] if fields[0] else "unknown"
                    parsed_fields["amount"] = fields[1] if fields[1] else "0.00"
                    parsed_fields["reference"] = fields[2] if fields[2] else ""
            
        except Exception as e:
            parsed_fields["parse_error"] = str(e)
        
        return parsed_fields
    
    def validate_connection(self) -> bool:
        """
        Validate Verifone device connection.
        
        Returns:
            bool: True if connection is valid
        """
        try:
            if not self.ip_connection or not self.port_connection:
                return False
            
            # Test TCP connection
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            test_socket.settimeout(5)
            test_socket.connect((self.ip_connection, self.port_connection))
            test_socket.close()
            
            return True
            
        except Exception as e:
            print(f"Verifone connection validation failed: {e}")
            return False
    
    def get_device_info(self) -> dict:
        """
        Get Verifone device information.
        
        Returns:
            dict: Verifone device information
        """
        base_info = super().get_device_info()
        base_info.update({
            "terminal_id": self.terminal_id,
            "merchant_id": self.merchant_id,
            "transaction_timeout": self.transaction_timeout
        })
        return base_info
    
    def process_verifone_transaction(self, transaction_data: bytes) -> dict:
        """
        Process a complete Verifone transaction.
        
        Args:
            transaction_data: Complete transaction data
            
        Returns:
            dict: Transaction processing result
        """
        try:
            # Process through streaming pipeline
            result = self.process_streaming_data(transaction_data)
            
            # Add Verifone-specific processing
            result["verifone_specific"] = {
                "terminal_id": self.terminal_id,
                "merchant_id": self.merchant_id,
                "transaction_processed": True
            }
            
            return result
            
        except Exception as e:
            return {
                "error": f"Failed to process Verifone transaction: {str(e)}",
                "device_type": "verifone",
                "terminal_id": self.terminal_id
            } 