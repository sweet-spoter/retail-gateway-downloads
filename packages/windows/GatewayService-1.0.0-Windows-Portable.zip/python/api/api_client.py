import aiohttp
import asyncio
from typing import Dict, Any, Optional
from core.logging_config import get_logger
from core.exceptions import ConnectionError
from core.interfaces import ConnectionProtocol

class APIClient(ConnectionProtocol):
    """Example API client implementation"""
    
    def __init__(self, base_url: str, auth_config: Optional[Dict[str, Any]] = None, 
                 timeout: int = 30, retry_attempts: int = 3):
        self.base_url = base_url.rstrip('/')
        self.auth_config = auth_config or {}
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        self.session: Optional[aiohttp.ClientSession] = None
        self.logger = get_logger(__name__)
        self.connected = False
    
    async def connect(self) -> bool:
        """Establish connection to API"""
        try:
            # Create session with timeout and auth
            timeout_config = aiohttp.ClientTimeout(total=self.timeout)
            
            # Setup authentication headers
            headers = {}
            if self.auth_config.get('type') == 'bearer':
                headers['Authorization'] = f"Bearer {self.auth_config.get('token')}"
            elif self.auth_config.get('type') == 'api_key':
                headers['X-API-Key'] = self.auth_config.get('key')
            
            self.session = aiohttp.ClientSession(
                timeout=timeout_config,
                headers=headers
            )
            
            # Test connection with health check
            health_endpoint = self.auth_config.get('endpoints', {}).get('health', '/health')
            async with self.session.get(f"{self.base_url}{health_endpoint}") as response:
                if response.status == 200:
                    self.connected = True
                    self.logger.info(f"Connected to API at {self.base_url}")
                    return True
                else:
                    self.logger.error(f"API health check failed: {response.status}")
                    return False
                    
        except Exception as e:
            self.logger.error(f"Failed to connect to API: {e}")
            self.connected = False
            return False
    
    async def disconnect(self) -> None:
        """Close API connection"""
        if self.session:
            await self.session.close()
            self.session = None
        self.connected = False
        self.logger.info("Disconnected from API")
    
    async def send(self, data: bytes) -> bool:
        """Send data to API"""
        if not self.connected or not self.session:
            raise ConnectionError("Not connected to API")
        
        try:
            # Convert bytes to JSON (assuming JSON format)
            import json
            payload = json.loads(data.decode('utf-8'))
            
            # Get data endpoint
            data_endpoint = self.auth_config.get('endpoints', {}).get('data', '/api/data')
            
            # Send POST request
            async with self.session.post(
                f"{self.base_url}{data_endpoint}",
                json=payload
            ) as response:
                if response.status in [200, 201]:
                    self.logger.debug(f"Data sent successfully: {response.status}")
                    return True
                else:
                    self.logger.error(f"Failed to send data: {response.status}")
                    return False
                    
        except Exception as e:
            self.logger.error(f"Error sending data to API: {e}")
            return False
    
    async def receive(self) -> Optional[bytes]:
        """Receive data from API (if supported)"""
        # This is a one-way API client, so receive is not implemented
        return None
    
    def is_connected(self) -> bool:
        """Check if connected to API"""
        return self.connected
    
    async def health_check(self) -> bool:
        """Perform health check"""
        if not self.connected or not self.session:
            return False
        
        try:
            health_endpoint = self.auth_config.get('endpoints', {}).get('health', '/health')
            async with self.session.get(f"{self.base_url}{health_endpoint}") as response:
                return response.status == 200
        except Exception as e:
            self.logger.error(f"Health check failed: {e}")
            return False

class APIClientFactory:
    """Factory for creating API clients"""
    
    @staticmethod
    def create_client(config: Dict[str, Any]) -> APIClient:
        """Create API client from configuration"""
        base_url = f"{config.get('protocol', 'https')}://{config['host']}"
        if config.get('port') and config['port'] not in [80, 443]:
            base_url += f":{config['port']}"
        
        auth_config = config.get('device', {}).get('auth', {})
        
        return APIClient(
            base_url=base_url,
            auth_config=auth_config,
            timeout=config.get('timeout', 30),
            retry_attempts=config.get('retry_attempts', 3)
        ) 