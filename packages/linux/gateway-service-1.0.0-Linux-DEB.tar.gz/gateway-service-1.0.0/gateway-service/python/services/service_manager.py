import asyncio
import platform
import signal
import sys
from typing import Optional
from core.logging_config import get_logger
from core.constants import SERVICE_NAME, SERVICE_DISPLAY_NAME
from core.exceptions import ServiceError
from services.application_service import ApplicationService

# Check if we're on Windows and import Windows-specific modules
IS_WINDOWS = platform.system().lower() == "windows"

if IS_WINDOWS:
    try:
        import win32serviceutil
        import win32service
        import win32event
        import servicemanager
        WINDOWS_MODULES_AVAILABLE = True
    except ImportError:
        WINDOWS_MODULES_AVAILABLE = False
        print("Warning: Windows service modules not available")
else:
    WINDOWS_MODULES_AVAILABLE = False

class ServiceManager:
    """Cross-platform service manager for the gateway service"""
    
    _svc_name_ = SERVICE_NAME
    _svc_display_name_ = SERVICE_DISPLAY_NAME
    _svc_description_ = "Gulfcoast Gateway Service for device communication"
    
    def __init__(self, args=None):
        self.app_service: Optional[ApplicationService] = None
        self.logger = get_logger(__name__)
        self.running = False
        self.stop_event = None
        
        # Windows-specific initialization
        if IS_WINDOWS and WINDOWS_MODULES_AVAILABLE:
            self._init_windows_service(args)
        else:
            self._init_development_service()
    
    def _init_windows_service(self, args):
        """Initialize Windows service components"""
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
    
    def _init_development_service(self):
        """Initialize development service components (Mac/Linux)"""
        self.logger.info("Running in development mode (non-Windows environment)")
        self.stop_event = None
    
    def SvcStop(self):
        """Handle service stop request (Windows)"""
        if IS_WINDOWS and WINDOWS_MODULES_AVAILABLE:
            self.logger.info("Service stop requested")
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            win32event.SetEvent(self.stop_event)
            self.running = False
            
            if self.app_service:
                try:
                    # Create a new event loop for shutdown if needed
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(self.app_service.shutdown())
                    loop.close()
                except Exception as e:
                    self.logger.error(f"Error during service shutdown: {e}")
        else:
            self.logger.info("Stop requested (development mode)")
            self.running = False
    
    def SvcDoRun(self):
        """Handle service start request (Windows)"""
        if IS_WINDOWS and WINDOWS_MODULES_AVAILABLE:
            try:
                self.logger.info("Service starting")
                servicemanager.LogMsg(
                    servicemanager.EVENTLOG_INFORMATION_TYPE,
                    servicemanager.PYS_SERVICE_STARTED,
                    (self._svc_name_, '')
                )
                
                # Run the service
                asyncio.run(self._run_service())
                
            except Exception as e:
                self.logger.error(f"Service failed to start: {e}")
                raise ServiceError(f"Service startup failed: {e}")
        else:
            # Development mode - run directly
            asyncio.run(self._run_service())
    
    async def _run_service(self):
        """Main service run loop"""
        try:
            # Initialize application service
            self.app_service = ApplicationService()
            await self.app_service.start()
            
            self.running = True
            self.logger.info("Service started successfully")
            
            # Main service loop
            while self.running:
                if IS_WINDOWS and WINDOWS_MODULES_AVAILABLE and self.stop_event:
                    # Check for stop event every 5 seconds (Windows)
                    if win32event.WaitForSingleObject(self.stop_event, 5000) == win32event.WAIT_OBJECT_0:
                        self.logger.info("Stop event received")
                        break
                else:
                    # Development mode - check for keyboard interrupt
                    await asyncio.sleep(5)
                
                # Check if application service is still healthy
                if self.app_service and not self.app_service.is_healthy():
                    self.logger.warning("Application service unhealthy, attempting restart")
                    await self.app_service.restart()
            
        except Exception as e:
            self.logger.error(f"Service error: {e}")
            raise
        finally:
            # Cleanup
            if self.app_service:
                await self.app_service.shutdown()
            self.logger.info("Service stopped")
    
    def run_development(self):
        """Run the service in development mode (Mac/Linux)"""
        self.logger.info("Starting Gateway Service in development mode")
        
        # Set up signal handlers for graceful shutdown
        def signal_handler(signum, frame):
            self.logger.info(f"Received signal {signum}, shutting down gracefully...")
            self.running = False
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        try:
            asyncio.run(self._run_service())
        except KeyboardInterrupt:
            self.logger.info("Keyboard interrupt received, shutting down...")
            self.running = False
        except Exception as e:
            self.logger.error(f"Service error: {e}")
            raise

# Windows-specific functions (only available on Windows)
if IS_WINDOWS and WINDOWS_MODULES_AVAILABLE:
    class WindowsServiceManager(ServiceManager, win32serviceutil.ServiceFramework):
        """Windows-specific service manager"""
        pass
    
    def install_service():
        """Install the Windows service"""
        try:
            win32serviceutil.InstallService(
                WindowsServiceManager._svc_name_,
                WindowsServiceManager._svc_display_name_,
                WindowsServiceManager._svc_description_
            )
            print(f"Service '{WindowsServiceManager._svc_display_name_}' installed successfully")
        except Exception as e:
            print(f"Failed to install service: {e}")

    def uninstall_service():
        """Uninstall the Windows service"""
        try:
            win32serviceutil.RemoveService(WindowsServiceManager._svc_name_)
            print(f"Service '{WindowsServiceManager._svc_display_name_}' uninstalled successfully")
        except Exception as e:
            print(f"Failed to uninstall service: {e}")

    def start_service():
        """Start the Windows service"""
        try:
            win32serviceutil.StartService(WindowsServiceManager._svc_name_)
            print(f"Service '{WindowsServiceManager._svc_display_name_}' started successfully")
        except Exception as e:
            print(f"Failed to start service: {e}")

    def stop_service():
        """Stop the Windows service"""
        try:
            win32serviceutil.StopService(WindowsServiceManager._svc_name_)
            print(f"Service '{WindowsServiceManager._svc_display_name_}' stopped successfully")
        except Exception as e:
            print(f"Failed to stop service: {e}")

    def restart_service():
        """Restart the Windows service"""
        try:
            win32serviceutil.RestartService(WindowsServiceManager._svc_name_)
            print(f"Service '{WindowsServiceManager._svc_display_name_}' restarted successfully")
        except Exception as e:
            print(f"Failed to restart service: {e}")

else:
    # Development mode functions (Mac/Linux)
    def install_service():
        """Development mode - no service installation"""
        print("Service installation not available in development mode (Mac/Linux)")
        print("Use 'python main.py' to run the service directly")

    def uninstall_service():
        """Development mode - no service uninstallation"""
        print("Service uninstallation not available in development mode (Mac/Linux)")

    def start_service():
        """Development mode - start service directly"""
        print("Starting Gateway Service in development mode...")
        service_manager = ServiceManager()
        service_manager.run_development()

    def stop_service():
        """Development mode - stop service"""
        print("Use Ctrl+C to stop the service in development mode")

    def restart_service():
        """Development mode - restart service"""
        print("Restart the service manually in development mode") 