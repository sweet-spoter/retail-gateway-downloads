import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from enum import Enum
from datetime import datetime

logger = logging.getLogger(__name__)

class DeviceStatus(str, Enum):
    """Device connection status"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"
    TIMEOUT = "timeout"

class EventType(str, Enum):
    """Event types"""
    CONNECT = "connect"
    DISCONNECT = "disconnect"
    DATA_RECEIVED = "data_received"
    DATA_SENT = "data_sent"
    ERROR = "error"
    STATUS_CHANGE = "status_change"

class DeviceEvent:
    """Standardized device event"""
    def __init__(
        self,
        event_id: str,
        device_type: str,
        event_type: EventType,
        timestamp: datetime,
        payload: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.event_id = event_id
        self.device_type = device_type
        self.event_type = event_type
        self.timestamp = timestamp
        self.payload = payload
        self.metadata = metadata or {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary"""
        return {
            "event_id": self.event_id,
            "device_type": self.device_type,
            "event_type": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "payload": self.payload,
            "metadata": self.metadata
        }

class DeviceConnection(ABC):
    """Abstract base class for device connections"""
    
    def __init__(self, device_config: Dict[str, Any]):
        self.device_config = device_config
        self.device_type = device_config.get("device_type", "unknown")
        self.status = DeviceStatus.DISCONNECTED
        self.last_activity = None
        self.error_count = 0
        self.max_retries = 3
        self.retry_delay = 5  # seconds

    @abstractmethod
    async def connect(self) -> bool:
        """Connect to the device"""
        pass

    @abstractmethod
    async def disconnect(self) -> bool:
        """Disconnect from the device"""
        pass

    @abstractmethod
    async def send_data(self, data: bytes) -> bool:
        """Send data to the device"""
        pass

    @abstractmethod
    async def receive_data(self) -> Optional[bytes]:
        """Receive data from the device"""
        pass

    @abstractmethod
    def get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        pass

    def update_status(self, status: DeviceStatus, error_message: Optional[str] = None):
        """Update device status"""
        self.status = status
        self.last_activity = datetime.now()
        if status == DeviceStatus.ERROR:
            self.error_count += 1
        elif status == DeviceStatus.CONNECTED:
            self.error_count = 0

    def is_connected(self) -> bool:
        """Check if device is connected"""
        return self.status == DeviceStatus.CONNECTED

    def get_health_info(self) -> Dict[str, Any]:
        """Get device health information"""
        return {
            "device_type": self.device_type,
            "status": self.status.value,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "error_count": self.error_count,
            "connection_type": self.get_connection_type()
        }

    @abstractmethod
    def get_connection_type(self) -> str:
        """Get connection type (sdk or socket)"""
        pass

class SDKDeviceConnection(DeviceConnection):
    """Base class for SDK-based device connections"""
    
    def __init__(self, device_config: Dict[str, Any]):
        super().__init__(device_config)
        self.sdk_config = device_config.get("sdk_config", {})
        self.sdk_type = self.sdk_config.get("sdk_type", "unknown")

    def get_connection_type(self) -> str:
        return "sdk"

    @abstractmethod
    async def initialize_sdk(self) -> bool:
        """Initialize the SDK"""
        pass

    @abstractmethod
    async def validate_sdk(self) -> bool:
        """Validate SDK installation and configuration"""
        pass

class SocketDeviceConnection(DeviceConnection):
    """Base class for socket-based device connections"""
    
    def __init__(self, device_config: Dict[str, Any]):
        super().__init__(device_config)
        self.socket_config = device_config.get("socket_config", {})
        self.socket_type = self.socket_config.get("type", "unknown")
        self.host = self.socket_config.get("host", "")
        self.port = self.socket_config.get("port", 0)
        self.mode = self.socket_config.get("mode", "connect")
        self.timeout = self.socket_config.get("timeout", 30)

    def get_connection_type(self) -> str:
        return "socket"

    @abstractmethod
    async def create_socket(self) -> bool:
        """Create and configure the socket"""
        pass

    @abstractmethod
    async def bind_socket(self) -> bool:
        """Bind socket for listening mode"""
        pass

    @abstractmethod
    async def connect_socket(self) -> bool:
        """Connect socket for connect mode"""
        pass

class DeviceManager:
    """Manages all device connections"""
    
    def __init__(self):
        self.devices: Dict[str, DeviceConnection] = {}
        self.device_factories: Dict[str, type] = {}
        self.connection_pool = {}
        self.health_monitor = None

    def register_device_factory(self, device_type: str, factory_class: type):
        """Register a device factory for a specific device type"""
        self.device_factories[device_type] = factory_class

    def create_device(self, device_id: str, device_config: Dict[str, Any]) -> Optional[DeviceConnection]:
        """Create a device connection"""
        try:
            device_type = device_config.get("device_type")
            connection_type = device_config.get("connection_type", "socket")
            
            # Add device_id to config for real devices
            device_config["device_id"] = device_id
            
            # Try to create real device first
            try:
                from core.real_devices import RealDeviceFactory
                device = RealDeviceFactory.create_device(device_id, device_config)
                if device:
                    self.devices[device_id] = device
                    logger.info(f"Created real device {device_id} of type {device_type}")
                    return device
            except ImportError:
                logger.warning("Real device factory not available, falling back to mock devices")
            
            # Fallback to mock devices for testing
            if connection_type == "sdk":
                device = MockSDKDeviceConnection(device_id, device_config)
            elif connection_type == "socket":
                device = MockSocketDeviceConnection(device_id, device_config)
            else:
                logger.warning(f"Unknown connection type: {connection_type}")
                return None
            
            self.devices[device_id] = device
            logger.info(f"Created mock device {device_id} of type {device_type}")
            return device
                
        except Exception as e:
            logger.error(f"Failed to create device {device_id}: {e}")
            return None

    async def connect_device(self, device_id: str) -> bool:
        """Connect a specific device"""
        device = self.devices.get(device_id)
        if device:
            return await device.connect()
        return False

    async def disconnect_device(self, device_id: str) -> bool:
        """Disconnect a specific device"""
        device = self.devices.get(device_id)
        if device:
            return await device.disconnect()
        return False

    async def connect_all_devices(self) -> Dict[str, bool]:
        """Connect all devices"""
        results = {}
        for device_id in self.devices:
            results[device_id] = await self.connect_device(device_id)
        return results

    async def disconnect_all_devices(self) -> Dict[str, bool]:
        """Disconnect all devices"""
        results = {}
        for device_id in self.devices:
            results[device_id] = await self.disconnect_device(device_id)
        return results

    def get_device(self, device_id: str) -> Optional[DeviceConnection]:
        """Get a specific device"""
        return self.devices.get(device_id)

    def get_all_devices(self) -> Dict[str, DeviceConnection]:
        """Get all devices"""
        return self.devices.copy()

    def get_connected_devices(self) -> Dict[str, DeviceConnection]:
        """Get all connected devices"""
        return {device_id: device for device_id, device in self.devices.items() 
                if device.is_connected()}

    def get_device_health(self) -> Dict[str, Dict[str, Any]]:
        """Get health information for all devices"""
        return {device_id: device.get_health_info() 
                for device_id, device in self.devices.items()}

    def remove_device(self, device_id: str) -> bool:
        """Remove a device from the manager"""
        if device_id in self.devices:
            del self.devices[device_id]
            return True
        return False

class MockSDKDeviceConnection(SDKDeviceConnection):
    """Mock SDK device connection for testing"""
    
    def __init__(self, device_id: str, device_config: Dict[str, Any]):
        super().__init__(device_config)
        self.device_id = device_id
        self.status = DeviceStatus.CONNECTED  # Mock devices start connected
    
    async def connect(self) -> bool:
        """Mock connect - always succeeds"""
        self.status = DeviceStatus.CONNECTED
        self.last_activity = datetime.now()
        return True
    
    async def disconnect(self) -> bool:
        """Mock disconnect - always succeeds"""
        self.status = DeviceStatus.DISCONNECTED
        return True
    
    async def send_data(self, data: bytes) -> bool:
        """Mock send data - always succeeds"""
        self.last_activity = datetime.now()
        return True
    
    async def receive_data(self) -> Optional[bytes]:
        """Mock receive data - returns sample data"""
        self.last_activity = datetime.now()
        return b"mock_data"
    
    async def initialize_sdk(self) -> bool:
        """Mock SDK initialization - always succeeds"""
        return True
    
    async def validate_sdk(self) -> bool:
        """Mock SDK validation - always succeeds"""
        return True
    
    def get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        return {
            "device_id": self.device_id,
            "device_type": self.device_type,
            "connection_type": "sdk",
            "sdk_type": self.sdk_type,
            "status": self.status.value,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None
        }

class MockSocketDeviceConnection(SocketDeviceConnection):
    """Mock socket device connection for testing"""
    
    def __init__(self, device_id: str, device_config: Dict[str, Any]):
        super().__init__(device_config)
        self.device_id = device_id
        self.status = DeviceStatus.CONNECTED  # Mock devices start connected
    
    async def connect(self) -> bool:
        """Mock connect - always succeeds"""
        self.status = DeviceStatus.CONNECTED
        self.last_activity = datetime.now()
        return True
    
    async def disconnect(self) -> bool:
        """Mock disconnect - always succeeds"""
        self.status = DeviceStatus.DISCONNECTED
        return True
    
    async def send_data(self, data: bytes) -> bool:
        """Mock send data - always succeeds"""
        self.last_activity = datetime.now()
        return True
    
    async def receive_data(self) -> Optional[bytes]:
        """Mock receive data - returns sample data"""
        self.last_activity = datetime.now()
        return b"mock_data"
    
    async def create_socket(self) -> bool:
        """Mock socket creation - always succeeds"""
        return True
    
    async def bind_socket(self) -> bool:
        """Mock socket binding - always succeeds"""
        return True
    
    async def connect_socket(self) -> bool:
        """Mock socket connection - always succeeds"""
        return True
    
    def get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        return {
            "device_id": self.device_id,
            "device_type": self.device_type,
            "connection_type": "socket",
            "socket_type": self.socket_type,
            "host": self.host,
            "port": self.port,
            "status": self.status.value,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None
        }

class DeviceEventManager:
    """Manages device events and event processing"""
    
    def __init__(self):
        self.event_handlers: Dict[EventType, List[callable]] = {}
        self.event_queue = asyncio.Queue()
        self.event_history: List[DeviceEvent] = []
        self.max_history_size = 1000

    def register_event_handler(self, event_type: EventType, handler: callable):
        """Register an event handler"""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)

    async def emit_event(self, event: DeviceEvent):
        """Emit a device event"""
        # Add to history
        self.event_history.append(event)
        if len(self.event_history) > self.max_history_size:
            self.event_history.pop(0)
        
        # Add to queue for processing
        await self.event_queue.put(event)
        
        # Call registered handlers
        handlers = self.event_handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                print(f"Error in event handler: {e}")

    async def process_events(self):
        """Process events from the queue"""
        while True:
            try:
                event = await self.event_queue.get()
                # Process event (can be extended with more logic)
                print(f"Processing event: {event.event_type} from {event.device_type}")
            except Exception as e:
                print(f"Error processing event: {e}")

    def get_event_history(self, device_type: Optional[str] = None, 
                         event_type: Optional[EventType] = None) -> List[DeviceEvent]:
        """Get event history with optional filtering"""
        events = self.event_history
        
        if device_type:
            events = [e for e in events if e.device_type == device_type]
        
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        return events

    def clear_event_history(self):
        """Clear event history"""
        self.event_history.clear() 