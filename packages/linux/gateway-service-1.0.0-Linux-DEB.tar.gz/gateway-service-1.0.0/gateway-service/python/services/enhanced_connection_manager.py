"""
Enhanced connection manager that supports lane-based architecture and streaming pipeline.
"""

import asyncio
from typing import Dict, List, Optional, Any
from core.logging_config import get_logger
from core.exceptions import ConnectionError
from core.interfaces import ConnectionManagerProtocol, EventBusProtocol, DeviceManagerProtocol
from sockets.socket_factory import create_socket

class EnhancedConnectionManager(ConnectionManagerProtocol):
    """Enhanced connection manager for lane-based architecture with streaming pipeline"""
    
    def __init__(self, config: Dict[str, Any], event_bus: EventBusProtocol, device_manager: DeviceManagerProtocol):
        self.config = config
        self.event_bus = event_bus
        self.device_manager = device_manager
        self.logger = get_logger(__name__)
        
        # Connection tracking
        self.connections: Dict[str, Any] = {}
        self.connection_tasks: Dict[str, asyncio.Task] = {}
        self.connection_status: Dict[str, bool] = {}
        self.connection_metrics: Dict[str, Dict[str, Any]] = {}
        
        # Lane-based connection tracking
        self.lane_connections: Dict[str, List[str]] = {}
        self.device_connections: Dict[str, str] = {}  # device_id -> connection_id
        
        # Health monitoring
        self.health_check_interval = 30  # seconds
        self.health_check_task: Optional[asyncio.Task] = None
    
    async def start_all_connections(self):
        """Start all connections from enhanced configuration"""
        try:
            self.logger.info("Starting all enhanced connections")
            
            # Get lanes from configuration
            lanes = self.config.get('lanes', {})
            
            # Start connections for each lane
            for lane_id, lane_config in lanes.items():
                await self._start_lane_connections(lane_id, lane_config)
            
            # Start health monitoring
            self.health_check_task = asyncio.create_task(self._health_monitor())
            
            self.logger.info(f"Started {len(self.connections)} enhanced connections across {len(lanes)} lanes")
            
        except Exception as e:
            self.logger.error(f"Failed to start enhanced connections: {e}")
            raise ConnectionError(f"Failed to start enhanced connections: {e}")
    
    async def stop_all_connections(self):
        """Stop all connections gracefully"""
        try:
            self.logger.info("Stopping all enhanced connections")
            
            # Stop health monitoring
            if self.health_check_task:
                self.health_check_task.cancel()
                try:
                    await self.health_check_task
                except asyncio.CancelledError:
                    pass
            
            # Cancel all connection tasks
            for task in self.connection_tasks.values():
                task.cancel()
            
            # Wait for all tasks to complete
            if self.connection_tasks:
                await asyncio.gather(*self.connection_tasks.values(), return_exceptions=True)
            
            # Clear tracking
            self.connections.clear()
            self.connection_tasks.clear()
            self.connection_status.clear()
            self.connection_metrics.clear()
            self.lane_connections.clear()
            self.device_connections.clear()
            
            self.logger.info("All enhanced connections stopped")
            
        except Exception as e:
            self.logger.error(f"Error during enhanced connection shutdown: {e}")
            raise
    
    async def shutdown_all_connections(self):
        """Shutdown all connections gracefully (alias for stop_all_connections)"""
        await self.stop_all_connections()
    
    async def restart_connection(self, connection_id: str) -> bool:
        """Restart a specific connection"""
        try:
            self.logger.info(f"Restarting connection: {connection_id}")
            
            # Stop existing connection
            if connection_id in self.connection_tasks:
                self.connection_tasks[connection_id].cancel()
                try:
                    await self.connection_tasks[connection_id]
                except asyncio.CancelledError:
                    pass
            
            # Find the connection configuration
            connection_config = self._find_connection_config(connection_id)
            if not connection_config:
                self.logger.error(f"Connection configuration not found for {connection_id}")
                return False
            
            # Start new connection
            await self._start_single_connection(connection_id, connection_config)
            
            self.logger.info(f"Connection {connection_id} restarted successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to restart connection: {e}")
            return False
    
    def get_connection_status(self) -> Dict[str, bool]:
        """Get status of all connections"""
        return self.connection_status.copy()
    
    def get_connection_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Get metrics for all connections"""
        return self.connection_metrics.copy()
    
    async def _start_lane_connections(self, lane_id: str, lane_config: Dict[str, Any]):
        """Start connections for a specific lane"""
        try:
            self.logger.info(f"Starting connections for lane: {lane_id}")
            
            devices = lane_config.get('devices', {})
            outputs = lane_config.get('outputs', {})
            
            # Track connections for this lane
            self.lane_connections[lane_id] = []
            
            # Start device connections
            for device_name, device_config in devices.items():
                await self._start_device_connections(lane_id, device_name, device_config)
            
            # Start output connections
            for output_name, output_config in outputs.items():
                await self._start_output_connections(lane_id, output_name, output_config)
            
            self.logger.info(f"Started connections for lane {lane_id}")
            
        except Exception as e:
            self.logger.error(f"Failed to start connections for lane {lane_id}: {e}")
            raise
    
    async def _start_device_connections(self, lane_id: str, device_name: str, device_config: Dict[str, Any]):
        """Start connections for a specific device"""
        try:
            # Get socket configuration from device
            socket_config = device_config.get('socket_config')
            if not socket_config:
                self.logger.warning(f"No socket configuration for {lane_id}.{device_name}")
                return
            
            # Create connection ID
            connection_id = f"{lane_id}_{device_name}_{socket_config.get('type', 'unknown')}"
            
            # Create connection configuration
            connection_config = {
                'socket_type': socket_config.get('type'),
                'connection_type': socket_config.get('mode'),
                'host': socket_config.get('host'),
                'port': socket_config.get('port'),
                'register': f"{lane_id}_{device_name}",
                'device': {
                    'name': device_config.get('device_type'),
                    'type': device_config.get('connection_type', 'socket'),
                    'terminals': device_config.get('terminals', [])
                }
            }
            
            # Start connection
            await self._start_single_connection(connection_id, connection_config)
            
            # Track connection
            self.lane_connections[lane_id].append(connection_id)
            self.device_connections[f"{lane_id}_{device_name}"] = connection_id
            
            self.logger.info(f"Started device connection: {connection_id}")
            
        except Exception as e:
            self.logger.error(f"Failed to start device connection for {lane_id}.{device_name}: {e}")
    
    async def _start_output_connections(self, lane_id: str, output_name: str, output_config: Dict[str, Any]):
        """Start connections for a specific output"""
        try:
            # Handle different output types
            if output_name == 'streaming_pipeline':
                # Streaming pipeline is handled separately
                return
            
            elif output_name == 'simple_outputs':
                # Handle simple outputs
                simple_outputs = output_config if isinstance(output_config, list) else []
                for i, simple_output in enumerate(simple_outputs):
                    await self._start_simple_output_connection(lane_id, output_name, simple_output, i)
            
            elif output_name in ['live_events', 'transaction_bundles']:
                # These are internal outputs, no external connections needed
                return
            
            else:
                self.logger.warning(f"Unknown output type: {output_name}")
            
        except Exception as e:
            self.logger.error(f"Failed to start output connection for {lane_id}.{output_name}: {e}")
    
    async def _start_simple_output_connection(self, lane_id: str, output_name: str, output_config: Dict[str, Any], index: int):
        """Start a simple output connection"""
        try:
            output_type = output_config.get('type')
            if output_type == 'tcp':
                # Create TCP connection configuration
                connection_config = {
                    'socket_type': 'tcp',
                    'connection_type': 'connect',
                    'host': output_config.get('host'),
                    'port': output_config.get('port'),
                    'register': f"{lane_id}_{output_name}_{index}",
                    'device': {
                        'name': output_config.get('name', 'simple_output'),
                        'type': 'none',
                        'terminals': []
                    }
                }
                
                connection_id = f"{lane_id}_{output_name}_{index}_tcp"
                await self._start_single_connection(connection_id, connection_config)
                
                # Track connection
                self.lane_connections[lane_id].append(connection_id)
                
                self.logger.info(f"Started simple output connection: {connection_id}")
            
            elif output_type == 'api':
                # API outputs don't need persistent connections
                self.logger.info(f"API output configured: {lane_id}.{output_name}")
            
            else:
                self.logger.warning(f"Unsupported simple output type: {output_type}")
            
        except Exception as e:
            self.logger.error(f"Failed to start simple output connection: {e}")
    
    async def _start_single_connection(self, connection_id: str, connection_config: Dict[str, Any]):
        """Start a single connection"""
        try:
            self.logger.info(f"Starting connection: {connection_id}")
            
            # Create socket task
            task = asyncio.create_task(
                self._run_connection(connection_config, connection_id)
            )
            
            # Track connection
            self.connection_tasks[connection_id] = task
            self.connection_status[connection_id] = False
            self.connection_metrics[connection_id] = {
                "start_time": asyncio.get_event_loop().time(),
                "bytes_sent": 0,
                "bytes_received": 0,
                "messages_sent": 0,
                "messages_received": 0,
                "errors": 0,
                "last_activity": None
            }
            
            # Wait a bit for connection to establish
            await asyncio.sleep(0.1)
            
            self.logger.info(f"Connection {connection_id} started")
            
        except Exception as e:
            self.logger.error(f"Failed to start connection {connection_id}: {e}")
            self.connection_status[connection_id] = False
            raise
    
    async def _run_connection(self, connection_config: Dict[str, Any], connection_id: str):
        """Run a connection with error handling and reconnection"""
        max_retries = 5
        retry_count = 0
        base_delay = 1
        
        while retry_count < max_retries:
            try:
                self.logger.info(f"Establishing connection {connection_id} (attempt {retry_count + 1})")
                
                # Create socket using factory
                socket_task = create_socket(connection_config, 'input' if 'input' in connection_id else 'output')
                
                # Store connection
                self.connections[connection_id] = socket_task
                self.connection_status[connection_id] = True
                
                # Update metrics
                self.connection_metrics[connection_id]["last_activity"] = asyncio.get_event_loop().time()
                
                # Wait for socket to complete or fail
                await socket_task
                
                # If we get here, socket completed normally
                self.logger.info(f"Connection {connection_id} completed normally")
                break
                
            except asyncio.CancelledError:
                self.logger.info(f"Connection {connection_id} cancelled")
                break
                
            except Exception as e:
                retry_count += 1
                self.connection_status[connection_id] = False
                self.connection_metrics[connection_id]["errors"] += 1
                
                self.logger.error(f"Connection {connection_id} failed (attempt {retry_count}): {e}")
                
                if retry_count >= max_retries:
                    self.logger.error(f"Connection {connection_id} failed after {max_retries} attempts")
                    break
                
                # Exponential backoff
                delay = base_delay * (2 ** (retry_count - 1))
                self.logger.info(f"Retrying connection {connection_id} in {delay} seconds")
                await asyncio.sleep(delay)
        
        # Cleanup
        if connection_id in self.connections:
            del self.connections[connection_id]
        self.connection_status[connection_id] = False
    
    def _find_connection_config(self, connection_id: str) -> Optional[Dict[str, Any]]:
        """Find connection configuration by connection ID"""
        # This would search through the configuration to find the matching connection
        # Implementation depends on how connection IDs are structured
        return None
    
    async def _health_monitor(self):
        """Monitor connection health"""
        while True:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                # Check connection status
                active_connections = sum(1 for status in self.connection_status.values() if status)
                total_connections = len(self.connection_status)
                
                self.logger.info(f"Health check: {active_connections}/{total_connections} connections active")
                
                # Log inactive connections
                inactive_connections = [
                    conn_id for conn_id, status in self.connection_status.items() 
                    if not status
                ]
                
                if inactive_connections:
                    self.logger.warning(f"Inactive connections: {inactive_connections}")
                
                # Update metrics
                current_time = asyncio.get_event_loop().time()
                for conn_id, metrics in self.connection_metrics.items():
                    if self.connection_status.get(conn_id, False):
                        metrics["last_activity"] = current_time
                
            except asyncio.CancelledError:
                self.logger.info("Health monitor cancelled")
                break
            except Exception as e:
                self.logger.error(f"Health monitor error: {e}")
    
    def get_connection_info(self, connection_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a specific connection"""
        if connection_id not in self.connection_status:
            return None
        
        metrics = self.connection_metrics.get(connection_id, {})
        
        return {
            "id": connection_id,
            "active": self.connection_status[connection_id],
            "task_running": connection_id in self.connection_tasks and not self.connection_tasks[connection_id].done(),
            "task_exception": self.connection_tasks[connection_id].exception() if connection_id in self.connection_tasks else None,
            "metrics": metrics
        }
    
    def get_lane_connections(self, lane_id: str) -> List[str]:
        """Get all connections for a specific lane"""
        return self.lane_connections.get(lane_id, [])
    
    def get_device_connection(self, device_id: str) -> Optional[str]:
        """Get connection ID for a specific device"""
        return self.device_connections.get(device_id)
    
    def update_connection_metrics(self, connection_id: str, bytes_sent: int = 0, bytes_received: int = 0, 
                                messages_sent: int = 0, messages_received: int = 0):
        """Update metrics for a specific connection"""
        if connection_id in self.connection_metrics:
            metrics = self.connection_metrics[connection_id]
            metrics["bytes_sent"] += bytes_sent
            metrics["bytes_received"] += bytes_received
            metrics["messages_sent"] += messages_sent
            metrics["messages_received"] += messages_received
            metrics["last_activity"] = asyncio.get_event_loop().time() 