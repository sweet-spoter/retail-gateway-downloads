import logging
import logging.handlers
import os
import sys
from typing import Optional
from core.correlation import get_correlation_id
from core.constants import LOG_FORMAT, LOG_FILE_MAX_BYTES, LOG_FILE_BACKUP_COUNT

class CorrelationFormatter(logging.Formatter):
    """Custom formatter that includes correlation IDs"""
    
    def format(self, record):
        # Add correlation ID to the record
        record.correlation_id = get_correlation_id()
        return super().format(record)

def setup_logging(
    log_level: str = "INFO",
    log_file: Optional[str] = None,
    enable_console: bool = True
) -> logging.Logger:
    """Setup logging configuration"""
    
    # Create logs directory if it doesn't exist
    if log_file:
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level.upper()))
    
    # Clear existing handlers
    root_logger.handlers.clear()
    
    # Create formatter with correlation ID
    formatter = CorrelationFormatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(correlation_id)s] - %(message)s'
    )
    
    # Console handler
    if enable_console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)
    
    # File handler
    if log_file:
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=LOG_FILE_MAX_BYTES,
            backupCount=LOG_FILE_BACKUP_COUNT
        )
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    return root_logger

def get_logger(name: str) -> logging.Logger:
    """Get a logger instance with the given name"""
    return logging.getLogger(name)

def setup_application_logging(config: dict) -> logging.Logger:
    """Setup logging based on application configuration"""
    
    # Get log directory from config or use default
    if getattr(sys, 'frozen', False):
        # Running as frozen executable
        base_path = os.path.dirname(sys.executable)
    else:
        # Running as script
        base_path = os.path.dirname(os.path.abspath(__file__))
    
    log_dir = os.path.join(base_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    log_file = os.path.join(log_dir, 'gateway_service.log')
    
    # Determine log level
    log_level = "DEBUG" if config.get('debug', False) else "INFO"
    
    return setup_logging(
        log_level=log_level,
        log_file=log_file,
        enable_console=not getattr(sys, 'frozen', False)  # Console only when not frozen
    ) 