import asyncio
import socket
import struct

from sockets.device_manager import device_manager
from sockets.tcp_server import TCPServerProtocol
from sockets.tcp_client import TCPClientProtocol
from sockets.udp_server import UDPServerProtocol
from sockets.udp_client import UDPClientProtocol
from sockets.multicast_socket import MulticastProtocol

# Factory Function
async def create_socket(config, direction):
    loop = asyncio.get_running_loop()
    
    # Adding a new device
    device_manager.add_device(
        device_id= direction +config['register'] ,
        device_config= config['device'],
        socket_type=config['socket_type'],
        connection_type=config['connection_type']
    )

    if config['socket_type'] == 'tcp':
        if config['connection_type'] == 'listen':
            return await create_tcp_server( config['host'], config['port'],
                config['register'],  direction, device_manager)
               
        elif config['connection_type'] == 'connect':
            # protocol = TCPClientProtocol(config['host'], config['port'], config['register'], direction, config['device'])
            # trop = config['device']
            
            return await TCPClientProtocol.create_tcp_client(config['host'], config['port'], config['register'], direction, device_manager)
            # return await create_tcp_client(config['host'], config['port'],
            #     config['register'],  direction, config['device'])
    elif config['socket_type'] == 'multicast':
        return await create_multicast( config['host'], config['port'],
                config['register'],  direction, device_manager)
    elif config['socket_type'] == 'udp':
        if  config['connection_type'] == 'listen':
            return await create_udp_server( config['host'], config['port'],
                config['register'],  direction, device_manager)
        elif config['connection_type'] == 'connect':
             return await UDPClientProtocol.create_udp_client(config['host'], config['port'], config['register'], direction, device_manager)
     # Add elif for 'udp' socket_type handling here if needed

async def create_tcp_client(host, port, register, direction, device):
    loop = asyncio.get_running_loop()
    return await loop.create_connection(
        lambda: TCPClientProtocol(register, direction, device),
        host, port)

async def create_tcp_server(host, port, register, direction, device ):
    loop = asyncio.get_running_loop()
    server = await loop.create_server(
        lambda: TCPServerProtocol(register, direction, device),
        host, port)
    async with server:
        await server.serve_forever()

async def create_udp_server(host, port, register, direction, device ):
    loop = asyncio.get_running_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        lambda: UDPServerProtocol(register, direction, device_manager),
        local_addr=(host, port))

    # Run forever
    await asyncio.Event().wait()
        
async def create_multicast(host, port, register, direction, device ):
    # Create a socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    port = int(port)
    if not (0 <= port <= 65535):
        raise ValueError("Port number must be between 0 and 65535")
    sock.bind(('', port))  # Bind on all interfaces

    # Get list of all IP addresses of the host
    # ips = socket.gethostbyname_ex(socket.gethostname())[2]
    # for ip in ips:
    #     # Join the multicast group on each interface
    #     mreq = struct.pack("4s4s", socket.inet_aton(host), socket.inet_aton(ip))
    #     sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        
    mreq = struct.pack("4s4s", socket.inet_aton(host), socket.inet_aton('0.0.0.0'))
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)


    # Join the multicast group
    # mreq = struct.pack("4sl", socket.inet_aton(host), socket.INADDR_ANY)
    # sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
    loop = asyncio.get_running_loop()
    _, protocol = await loop.create_datagram_endpoint(
        lambda: MulticastProtocol(host, port, register, direction, device),
        sock=sock
    )