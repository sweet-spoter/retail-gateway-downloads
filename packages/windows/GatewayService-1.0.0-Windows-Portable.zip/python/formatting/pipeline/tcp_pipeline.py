"""
TCP pipeline implementation for connecting to video systems.
"""

import socket
import json
import threading
import time
from typing import Optional, Callable
from datetime import datetime

class TCPPipeline:
    """
    TCP pipeline for connecting to video systems or other external software.
    Handles connection management and data transmission.
    """
    
    def __init__(self, host: str = 'localhost', port: int = 9000, timeout: int = 5):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.socket: Optional[socket.socket] = None
        self.connected = False
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 5
        self.reconnect_delay = 1  # seconds
        
        # Callback for connection status changes
        self.connection_callback: Optional[Callable] = None
        
        # Thread for connection monitoring
        self.monitor_thread: Optional[threading.Thread] = None
        self.monitoring = False
    
    def connect(self) -> bool:
        """
        Connect to the TCP pipeline.
        
        Returns:
            bool: True if connection successful
        """
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(self.timeout)
            self.socket.connect((self.host, self.port))
            self.connected = True
            self.reconnect_attempts = 0
            
            print(f"Connected to TCP pipeline at {self.host}:{self.port}")
            
            # Start monitoring thread
            self._start_monitoring()
            
            # Call connection callback
            if self.connection_callback:
                self.connection_callback(True)
            
            return True
            
        except Exception as e:
            print(f"Failed to connect to TCP pipeline: {e}")
            self.connected = False
            return False
    
    def disconnect(self):
        """
        Disconnect from the TCP pipeline.
        """
        self.monitoring = False
        
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
            self.socket = None
        
        self.connected = False
        
        # Call connection callback
        if self.connection_callback:
            self.connection_callback(False)
        
        print(f"Disconnected from TCP pipeline at {self.host}:{self.port}")
    
    def send_data(self, data: dict) -> bool:
        """
        Send data to the TCP pipeline.
        
        Args:
            data: Data dictionary to send
            
        Returns:
            bool: True if send successful
        """
        if not self.connected:
            if not self._attempt_reconnect():
                return False
        
        try:
            # Add timestamp if not present
            if 'timestamp' not in data:
                data['timestamp'] = self._get_timestamp()
            
            message_str = json.dumps(data) + "\n"
            self.socket.send(message_str.encode('utf-8'))
            return True
            
        except Exception as e:
            print(f"Failed to send data to pipeline: {e}")
            self.connected = False
            return False
    
    def send_transaction_start(self, transaction_id: str, device_type: str, device_id: str, initial_data: bytes) -> bool:
        """
        Send transaction start message.
        
        Args:
            transaction_id: Unique transaction ID
            device_type: Type of device
            device_id: Device identifier
            initial_data: Initial device data
            
        Returns:
            bool: True if send successful
        """
        message = {
            "type": "start_transaction",
            "transaction_id": transaction_id,
            "device_type": device_type,
            "device_id": device_id,
            "initial_data": initial_data.hex(),
            "timestamp": self._get_timestamp()
        }
        
        return self.send_data(message)
    
    def send_transaction_data(self, transaction_id: str, device_type: str, device_id: str, data: bytes) -> bool:
        """
        Send transaction data message.
        
        Args:
            transaction_id: Unique transaction ID
            device_type: Type of device
            device_id: Device identifier
            data: Device data
            
        Returns:
            bool: True if send successful
        """
        message = {
            "type": "stream_data",
            "transaction_id": transaction_id,
            "device_type": device_type,
            "device_id": device_id,
            "data": data.hex(),
            "timestamp": self._get_timestamp()
        }
        
        return self.send_data(message)
    
    def send_transaction_end(self, transaction_id: str, device_type: str, device_id: str, final_data: bytes, total_chunks: int) -> bool:
        """
        Send transaction end message.
        
        Args:
            transaction_id: Unique transaction ID
            device_type: Type of device
            device_id: Device identifier
            final_data: Final device data
            total_chunks: Total number of data chunks
            
        Returns:
            bool: True if send successful
        """
        # Send end data
        end_data_message = {
            "type": "end_data",
            "transaction_id": transaction_id,
            "device_type": device_type,
            "device_id": device_id,
            "final_data": final_data.hex(),
            "timestamp": self._get_timestamp()
        }
        
        if not self.send_data(end_data_message):
            return False
        
        # Send end transaction
        end_transaction_message = {
            "type": "end_transaction",
            "transaction_id": transaction_id,
            "device_type": device_type,
            "device_id": device_id,
            "total_data_chunks": total_chunks,
            "timestamp": self._get_timestamp()
        }
        
        return self.send_data(end_transaction_message)
    
    def set_connection_callback(self, callback: Callable[[bool], None]):
        """
        Set callback for connection status changes.
        
        Args:
            callback: Function to call when connection status changes
        """
        self.connection_callback = callback
    
    def _attempt_reconnect(self) -> bool:
        """
        Attempt to reconnect to the pipeline.
        
        Returns:
            bool: True if reconnection successful
        """
        if self.reconnect_attempts >= self.max_reconnect_attempts:
            print(f"Max reconnection attempts reached for {self.host}:{self.port}")
            return False
        
        self.reconnect_attempts += 1
        print(f"Attempting to reconnect to {self.host}:{self.port} (attempt {self.reconnect_attempts})")
        
        time.sleep(self.reconnect_delay)
        return self.connect()
    
    def _start_monitoring(self):
        """
        Start connection monitoring thread.
        """
        if self.monitor_thread and self.monitor_thread.is_alive():
            return
        
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_connection, daemon=True)
        self.monitor_thread.start()
    
    def _monitor_connection(self):
        """
        Monitor connection status.
        """
        while self.monitoring and self.connected:
            try:
                # Send ping to check connection
                ping_message = {
                    "type": "ping",
                    "timestamp": self._get_timestamp()
                }
                
                message_str = json.dumps(ping_message) + "\n"
                self.socket.send(message_str.encode('utf-8'))
                
                time.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                print(f"Connection lost to {self.host}:{self.port}: {e}")
                self.connected = False
                self.monitoring = False
                
                # Call connection callback
                if self.connection_callback:
                    self.connection_callback(False)
                
                break
    
    def _get_timestamp(self) -> str:
        """
        Get current timestamp.
        
        Returns:
            str: ISO formatted timestamp
        """
        return datetime.now().isoformat()
    
    def is_connected(self) -> bool:
        """
        Check if connected to pipeline.
        
        Returns:
            bool: True if connected
        """
        return self.connected
    
    def get_connection_info(self) -> dict:
        """
        Get connection information.
        
        Returns:
            dict: Connection information
        """
        return {
            "host": self.host,
            "port": self.port,
            "connected": self.connected,
            "reconnect_attempts": self.reconnect_attempts,
            "max_reconnect_attempts": self.max_reconnect_attempts
        } 