import asyncio
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
import logging

from models.lane_config import LaneConfig, DeviceConfig, LicenseStatus
from core.device_interfaces import DeviceManager, DeviceConnection, DeviceEvent, EventType
from core.event_normalizer import EventNormalizer, NormalizedEventType
from core.session_manager import SessionManager
from core.output_manager import OutputManager
from core.exceptions import ValidationError

logger = logging.getLogger(__name__)

class LaneStatus(str, Enum):
    """Lane status enumeration"""
    INITIALIZING = "initializing"
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    LICENSED_EXPIRED = "licensed_expired"
    GRACE_PERIOD = "grace_period"

class LaneManager:
    """Manages lane lifecycle and device connections"""
    
    def __init__(self, event_callback: Optional[Callable] = None):
        self.lanes: Dict[str, 'LaneInstance'] = {}
        self.device_manager = DeviceManager()
        self.event_normalizer = EventNormalizer()
        self.event_callback = event_callback
        self.health_check_interval = 30  # seconds
        self.health_check_task: Optional[asyncio.Task] = None

    async def create_lane(self, lane_config: LaneConfig) -> str:
        """Create and initialize a lane"""
        try:
            lane_id = lane_config.lane_id
            
            # Check if lane already exists
            if lane_id in self.lanes:
                logger.warning(f"Lane {lane_id} already exists, updating configuration")
                await self.remove_lane(lane_id)
            
            # Create lane instance
            lane_instance = LaneInstance(
                lane_config=lane_config,
                device_manager=self.device_manager,
                event_normalizer=self.event_normalizer,
                event_callback=self.event_callback
            )
            
            # Initialize the lane
            await lane_instance.initialize()
            
            # Store the lane
            self.lanes[lane_id] = lane_instance
            
            logger.info(f"Lane {lane_id} created and initialized successfully")
            return lane_id
            
        except Exception as e:
            logger.error(f"Failed to create lane {lane_config.lane_id}: {e}")
            raise

    async def remove_lane(self, lane_id: str) -> bool:
        """Remove a lane and clean up resources"""
        try:
            if lane_id not in self.lanes:
                logger.warning(f"Lane {lane_id} not found")
                return False
            
            lane_instance = self.lanes[lane_id]
            await lane_instance.shutdown()
            del self.lanes[lane_id]
            
            logger.info(f"Lane {lane_id} removed successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to remove lane {lane_id}: {e}")
            return False

    async def start_lane(self, lane_id: str) -> bool:
        """Start a lane (activate all devices)"""
        try:
            if lane_id not in self.lanes:
                logger.error(f"Lane {lane_id} not found")
                return False
            
            lane_instance = self.lanes[lane_id]
            success = await lane_instance.start()
            
            if success:
                logger.info(f"Lane {lane_id} started successfully")
            else:
                logger.error(f"Failed to start lane {lane_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error starting lane {lane_id}: {e}")
            return False

    async def stop_lane(self, lane_id: str) -> bool:
        """Stop a lane (deactivate all devices)"""
        try:
            if lane_id not in self.lanes:
                logger.error(f"Lane {lane_id} not found")
                return False
            
            lane_instance = self.lanes[lane_id]
            success = await lane_instance.stop()
            
            if success:
                logger.info(f"Lane {lane_id} stopped successfully")
            else:
                logger.error(f"Failed to stop lane {lane_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error stopping lane {lane_id}: {e}")
            return False

    async def start_all_lanes(self) -> Dict[str, bool]:
        """Start all lanes"""
        results = {}
        for lane_id in self.lanes:
            results[lane_id] = await self.start_lane(lane_id)
        return results

    async def stop_all_lanes(self) -> Dict[str, bool]:
        """Stop all lanes"""
        results = {}
        for lane_id in self.lanes:
            results[lane_id] = await self.stop_lane(lane_id)
        return results

    def get_lane(self, lane_id: str) -> Optional['LaneInstance']:
        """Get a specific lane instance"""
        return self.lanes.get(lane_id)

    def get_all_lanes(self) -> Dict[str, 'LaneInstance']:
        """Get all lane instances"""
        return self.lanes.copy()

    def get_lane_status(self, lane_id: str) -> Optional[LaneStatus]:
        """Get the status of a specific lane"""
        lane_instance = self.lanes.get(lane_id)
        return lane_instance.status if lane_instance else None

    def get_all_lane_statuses(self) -> Dict[str, LaneStatus]:
        """Get status of all lanes"""
        return {lane_id: lane_instance.status for lane_id, lane_instance in self.lanes.items()}

    async def process_event(self, lane_id: str, device_event: DeviceEvent) -> bool:
        """Process an event for a specific lane"""
        try:
            if lane_id not in self.lanes:
                logger.error(f"Lane {lane_id} not found for event processing")
                return False
            
            lane_instance = self.lanes[lane_id]
            return await lane_instance.process_event(device_event)
            
        except Exception as e:
            logger.error(f"Error processing event for lane {lane_id}: {e}")
            return False

    async def start_health_monitoring(self):
        """Start health monitoring for all lanes"""
        if self.health_check_task and not self.health_check_task.done():
            logger.warning("Health monitoring already running")
            return
        
        self.health_check_task = asyncio.create_task(self._health_monitor_loop())
        logger.info("Health monitoring started")

    async def stop_health_monitoring(self):
        """Stop health monitoring"""
        if self.health_check_task:
            self.health_check_task.cancel()
            try:
                await self.health_check_task
            except asyncio.CancelledError:
                pass
            self.health_check_task = None
            logger.info("Health monitoring stopped")

    async def _health_monitor_loop(self):
        """Health monitoring loop"""
        while True:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                for lane_id, lane_instance in self.lanes.items():
                    await lane_instance.check_health()
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in health monitoring loop: {e}")

    async def shutdown(self):
        """Shutdown the lane manager"""
        logger.info("Shutting down lane manager...")
        
        # Stop health monitoring
        await self.stop_health_monitoring()
        
        # Stop all lanes
        await self.stop_all_lanes()
        
        # Remove all lanes
        for lane_id in list(self.lanes.keys()):
            await self.remove_lane(lane_id)
        
        logger.info("Lane manager shutdown complete")

class LaneInstance:
    """Represents a single lane instance with its devices and session management"""
    
    def __init__(
        self,
        lane_config: LaneConfig,
        device_manager: DeviceManager,
        event_normalizer: EventNormalizer,
        event_callback: Optional[Callable] = None
    ):
        self.lane_config = lane_config
        self.device_manager = device_manager
        self.event_normalizer = event_normalizer
        self.event_callback = event_callback
        
        self.lane_id = lane_config.lane_id
        self.register_id = lane_config.register_id
        self.cashier_id = lane_config.cashier_id
        
        self.status = LaneStatus.INITIALIZING
        self.devices: Dict[str, DeviceConnection] = {}
        self.session_manager: Optional['SessionManager'] = None
        self.output_manager: Optional['OutputManager'] = None
        
        self.last_health_check = datetime.now()
        self.error_count = 0
        self.max_errors = 5

    async def initialize(self):
        """Initialize the lane instance"""
        try:
            logger.info(f"Initializing lane {self.lane_id}")
            
            # Check license status
            if not self._check_license():
                self.status = LaneStatus.LICENSED_EXPIRED
                logger.warning(f"Lane {self.lane_id} license expired")
                return
            
            # Create devices
            await self._create_devices()
            
            # Initialize session manager if enabled
            if self.lane_config.sessionizer.enabled:
                self.session_manager = SessionManager(
                    lane_config=self.lane_config,
                    event_callback=self.event_callback
                )
                await self.session_manager.initialize()
            
            # Initialize output manager
            self.output_manager = OutputManager(
                lane_config=self.lane_config,
                event_callback=self.event_callback
            )
            await self.output_manager.initialize()
            
            self.status = LaneStatus.INACTIVE
            logger.info(f"Lane {self.lane_id} initialized successfully")
            
        except Exception as e:
            self.status = LaneStatus.ERROR
            logger.error(f"Failed to initialize lane {self.lane_id}: {e}")
            raise

    async def start(self) -> bool:
        """Start the lane (connect all devices)"""
        try:
            if self.status == LaneStatus.LICENSED_EXPIRED:
                logger.warning(f"Cannot start lane {self.lane_id} - license expired")
                return False
            
            logger.info(f"Starting lane {self.lane_id}")
            
            # Connect all devices
            device_results = await self.device_manager.connect_all_devices()
            
            # Check if all devices connected successfully
            failed_devices = [device_id for device_id, success in device_results.items() if not success]
            
            if failed_devices:
                logger.warning(f"Some devices failed to connect in lane {self.lane_id}: {failed_devices}")
                self.status = LaneStatus.ERROR
                return False
            
            # Start session manager if enabled
            if self.session_manager:
                await self.session_manager.start()
            
            # Start output manager
            if self.output_manager:
                await self.output_manager.start()
            
            self.status = LaneStatus.ACTIVE
            logger.info(f"Lane {self.lane_id} started successfully")
            return True
            
        except Exception as e:
            self.status = LaneStatus.ERROR
            logger.error(f"Failed to start lane {self.lane_id}: {e}")
            return False

    async def stop(self) -> bool:
        """Stop the lane (disconnect all devices)"""
        try:
            logger.info(f"Stopping lane {self.lane_id}")
            
            # Stop session manager
            if self.session_manager:
                await self.session_manager.stop()
            
            # Stop output manager
            if self.output_manager:
                await self.output_manager.stop()
            
            # Disconnect all devices
            await self.device_manager.disconnect_all_devices()
            
            self.status = LaneStatus.INACTIVE
            logger.info(f"Lane {self.lane_id} stopped successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to stop lane {self.lane_id}: {e}")
            return False

    async def shutdown(self):
        """Shutdown the lane instance"""
        try:
            logger.info(f"Shutting down lane {self.lane_id}")
            
            # Stop the lane
            await self.stop()
            
            # Shutdown session manager
            if self.session_manager:
                await self.session_manager.shutdown()
            
            # Shutdown output manager
            if self.output_manager:
                await self.output_manager.shutdown()
            
            # Clear devices
            self.devices.clear()
            
            logger.info(f"Lane {self.lane_id} shutdown complete")
            
        except Exception as e:
            logger.error(f"Error shutting down lane {self.lane_id}: {e}")

    async def process_event(self, device_event: DeviceEvent) -> bool:
        """Process an event for this lane"""
        try:
            # Normalize the event
            normalized_event = self.event_normalizer.normalize_event(
                device_event,
                lane_id=self.lane_id,
                register_id=self.register_id,
                cashier_id=self.cashier_id
            )
            
            # Process with session manager if enabled
            if self.session_manager:
                await self.session_manager.process_event(normalized_event)
            else:
                # Direct output for lanes without session management
                if self.output_manager:
                    await self.output_manager.send_event(normalized_event)
            
            return True
            
        except Exception as e:
            logger.error(f"Error processing event in lane {self.lane_id}: {e}")
            self.error_count += 1
            return False

    async def check_health(self):
        """Check the health of the lane"""
        try:
            current_time = datetime.now()
            
            # Check device health
            device_health = self.device_manager.get_device_health()
            failed_devices = [
                device_id for device_id, health in device_health.items()
                if health.get("status") == "error"
            ]
            
            if failed_devices:
                logger.warning(f"Lane {self.lane_id} has failed devices: {failed_devices}")
                self.error_count += 1
            
            # Check license status
            if not self._check_license():
                self.status = LaneStatus.LICENSED_EXPIRED
                logger.warning(f"Lane {self.lane_id} license expired during health check")
            
            # Update status based on error count
            if self.error_count >= self.max_errors:
                self.status = LaneStatus.ERROR
                logger.error(f"Lane {self.lane_id} has too many errors")
            
            self.last_health_check = current_time
            
        except Exception as e:
            logger.error(f"Error checking health for lane {self.lane_id}: {e}")

    async def _create_devices(self):
        """Create all devices for this lane"""
        for device_name, device_config in self.lane_config.devices.items():
            try:
                device_id = f"{self.lane_id}_{device_name}"
                device = self.device_manager.create_device(device_id, device_config.model_dump())
                
                if device:
                    self.devices[device_name] = device
                    logger.info(f"Created device {device_name} for lane {self.lane_id}")
                else:
                    logger.error(f"Failed to create device {device_name} for lane {self.lane_id}")
                    
            except Exception as e:
                logger.error(f"Error creating device {device_name} for lane {self.lane_id}: {e}")

    def _check_license(self) -> bool:
        """Check if the lane license is valid"""
        license_config = self.lane_config.license
        
        if not license_config.license_required:
            return True
        
        if license_config.license_status == LicenseStatus.ACTIVE:
            return True
        
        if license_config.license_status == LicenseStatus.GRACE_PERIOD:
            if license_config.grace_period_until and datetime.now() < license_config.grace_period_until:
                return True
        
        return False 