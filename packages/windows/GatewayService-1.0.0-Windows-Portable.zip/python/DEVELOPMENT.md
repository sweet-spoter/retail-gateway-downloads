# Development Guide

This guide explains how to set up and use the development environment for the Gateway Service project.

## 🚀 Quick Start

### 1. Setup Development Environment

```bash
# Run the setup script (creates venv, installs dependencies, runs tests)
./setup_dev.sh
```

### 2. Activate Virtual Environment

```bash
# Activate the virtual environment
source venv/bin/activate

# Your prompt should now show (venv) indicating the virtual environment is active
(venv) oskarsanchez-chagollan@Dev/Python/Gulfcoast/gateway_service_latest %
```

### 3. Run Tests

```bash
# Run all tests
./run_tests.sh

# Run Phase 1 tests only
./run_tests.sh phase1

# Run validation script
./run_tests.sh validation

# Run debug configuration test
./run_tests.sh debug

# Run specific test file
./run_tests.sh tests/test_phase1_foundation.py
```

## 🧪 Testing

### Manual Testing

```bash
# Activate virtual environment
source venv/bin/activate

# Run pytest directly
python -m pytest tests/ -v

# Run specific test file
python -m pytest tests/test_phase1_foundation.py -v

# Run with coverage (if pytest-cov is installed)
python -m pytest tests/ --cov=. --cov-report=html
```

### Validation Scripts

```bash
# Run Phase 1 validation
python validate_phase1.py

# Run debug configuration test
python debug_config.py
```

## 📦 Dependencies

The project uses the following key dependencies:

- **pydantic>=2.0.0** - Data validation and settings management
- **structlog>=23.0.0** - Structured logging
- **dependency-injector>=4.41.0** - Dependency injection
- **aiohttp>=3.8.0** - Async HTTP client/server
- **pytest>=7.0.0** - Testing framework
- **pytest-asyncio>=0.21.0** - Async testing support
- **psutil>=5.9.0** - System and process utilities

### Installing Additional Dependencies

```bash
# Activate virtual environment
source venv/bin/activate

# Install new dependency
pip install package_name

# Update requirements.txt
pip freeze > requirements.txt
```

## 🔧 Development Workflow

### 1. Start Development Session

```bash
# Activate virtual environment
source venv/bin/activate

# Verify environment
python -c "import pydantic, structlog, pytest; print('Environment ready!')"
```

### 2. Make Changes

- Edit source files in `core/`, `models/`, `services/`, etc.
- Add new tests in `tests/` directory
- Update configuration in `config/` directory

### 3. Test Changes

```bash
# Run tests after making changes
./run_tests.sh phase1

# Or run specific tests
python -m pytest tests/test_specific_feature.py -v
```

### 4. Validate Configuration

```bash
# Test configuration changes
python debug_config.py

# Run full validation
python validate_phase1.py
```

## 📁 Project Structure

```
gateway_service_latest/
├── venv/                    # Virtual environment (created by setup)
├── core/                    # Core framework components
│   ├── device_interfaces.py # Device connection framework
│   ├── event_normalizer.py  # Event normalization system
│   └── ...
├── models/                  # Data models and configuration
│   ├── lane_config.py       # Enhanced configuration models
│   └── ...
├── tests/                   # Test files
│   ├── test_phase1_foundation.py
│   └── ...
├── config/                  # Configuration files
│   ├── enhanced_config.json # Sample enhanced configuration
│   └── ...
├── setup_dev.sh            # Development setup script
├── run_tests.sh            # Test runner script
├── validate_phase1.py      # Phase 1 validation script
├── debug_config.py         # Configuration debugging script
└── requirements.txt        # Python dependencies
```

## 🐛 Troubleshooting

### Virtual Environment Issues

```bash
# If virtual environment is corrupted, recreate it
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Import Errors

```bash
# Make sure you're in the project root directory
pwd  # Should show /path/to/gateway_service_latest

# Make sure virtual environment is activated
echo $VIRTUAL_ENV  # Should show path to venv

# Check Python path
python -c "import sys; print('\n'.join(sys.path))"
```

### Test Failures

```bash
# Run tests with verbose output
python -m pytest tests/ -v -s

# Run specific failing test
python -m pytest tests/test_phase1_foundation.py::TestSpecificClass::test_specific_method -v -s
```

### Configuration Issues

```bash
# Test configuration loading
python debug_config.py

# Check JSON syntax
python -c "import json; json.load(open('config/enhanced_config.json'))"
```

## 🔄 Continuous Integration

For CI/CD environments, you can use the setup script:

```bash
# In CI environment
chmod +x setup_dev.sh
./setup_dev.sh
```

## 📝 Adding New Tests

1. Create test file in `tests/` directory
2. Follow naming convention: `test_*.py`
3. Use pytest fixtures and async testing when needed
4. Add to test runner script if needed

Example test structure:

```python
import pytest
from datetime import datetime

class TestNewFeature:
    def test_basic_functionality(self):
        # Test basic functionality
        assert True
    
    @pytest.mark.asyncio
    async def test_async_functionality(self):
        # Test async functionality
        assert True
```

## 🚀 Next Steps

After setting up the development environment:

1. **Phase 1 Complete** ✅ - Foundation components are working
2. **Phase 2** - Implement core functionality (Lane Manager, Session Management)
3. **Phase 3** - Add SDK integration (Python, C++, C#)
4. **Phase 4** - Implement licensing and monetization
5. **Phase 5** - Performance optimization and scaling

## 📞 Support

If you encounter issues:

1. Check this development guide
2. Run the debug scripts: `./run_tests.sh debug`
3. Check the test output for specific error messages
4. Verify your Python version: `python --version` (should be 3.8+) 