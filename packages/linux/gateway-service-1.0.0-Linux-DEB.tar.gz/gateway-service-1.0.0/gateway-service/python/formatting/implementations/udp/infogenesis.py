"""
Infogenesis UDP POS device implementation with handshake support.
"""

import socket
import time
import datetime
import asyncio
from typing import Dict, Any, Optional
from ...base.pos_interface import POSInterface, ProtocolType, ConnectionType
from ..handshake.infogenesis_handshake import InfogenesisHandshake, InfoGenesisMsg

class InfogenesisInterface(POSInterface):
    """
    Infogenesis UDP POS device interface.
    Handles Infogenesis-specific handshake, data formatting, and connection validation.
    """
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.device_type = "infogenesis"
        self.handshake_required = True  # Infogenesis requires handshake
        
        # Infogenesis-specific configuration
        self.terminal_id = config.get('terminal_id', '')
        self.terminal_ip = config.get('terminal_ip', '')
        self.handshake_timeout = config.get('handshake_timeout', 10)
        self.handshake_retries = config.get('handshake_retries', 3)
        
        # Handshake state (matching the working implementation)
        self.handshake_completed = False
        self.handshake_session_id = None
        
        # Connection socket
        self.connection_socket: socket.socket = None
        
        # Terminal ID to output mapping
        self.terminal_output_mapping = config.get('terminal_output_mapping', {})
        
        # Initialize handshake handler
        self.handshake_handler = InfogenesisHandshake(self.terminal_id, self.terminal_ip)
    
    def _format_device_data(self, data: bytes) -> dict:
        """
        Format Infogenesis-specific device data.
        
        Args:
            data: Raw Infogenesis data
            
        Returns:
            dict: Formatted Infogenesis data
        """
        try:
            # Convert bytes to string for parsing
            data_str = data.decode('utf-8', errors='ignore').strip()
            
            # Process data through handshake handler
            handshake_result = self.handshake_handler.manage_handshake_data(data_str, "1")  # Default register
            
            # Parse Infogenesis data format
            formatted_data = {
                "device_type": "infogenesis",
                "terminal_id": self.terminal_id,
                "terminal_ip": self.terminal_ip,
                "handshake_completed": self.handshake_handler.is_handshake_complete(),
                "handshake_session_id": self.handshake_session_id,
                "raw_data": handshake_result.get("raw_data", data_str),
                "data_length": len(data),
                "data_hex": data.hex(),
                "parsed_fields": self._parse_infogenesis_data(data_str, handshake_result),
                "output_mapping": self._get_output_mapping()
            }
            
            return formatted_data
            
        except Exception as e:
            return {
                "device_type": "infogenesis",
                "error": f"Failed to format Infogenesis data: {str(e)}",
                "raw_data": data.hex(),
                "data_length": len(data)
            }
    
    def _parse_infogenesis_data(self, data_str: str, handshake_result: dict = None) -> dict:
        """
        Parse Infogenesis-specific data fields using the working implementation logic.
        
        Args:
            data_str: Infogenesis data string
            handshake_result: Result from handshake handler
            
        Returns:
            dict: Parsed Infogenesis fields
        """
        parsed_fields = {}
        
        try:
            # Use handshake result if available
            if handshake_result and handshake_result.get("processed"):
                parsed_fields.update(handshake_result)
            else:
                # Fallback parsing
                if self.handshake_handler.contains_special_characters(data_str):
                    if len(data_str) >= 4:
                        indicator = data_str[1:4].upper()
                        parsed_fields["indicator"] = indicator
                        parsed_fields["message_type"] = "unknown"
            
            # Add raw data for debugging
            parsed_fields["raw_data"] = data_str
            parsed_fields["data_length"] = len(data_str)
            
        except Exception as e:
            parsed_fields["parse_error"] = str(e)
        
        return parsed_fields
    
    def _get_output_mapping(self) -> str:
        """
        Get output mapping based on terminal ID.
        
        Returns:
            str: Output mapping identifier
        """
        if self.terminal_id in self.terminal_output_mapping:
            return self.terminal_output_mapping[self.terminal_id]
        return self.output_mapping
    
    def validate_connection(self) -> bool:
        """
        Validate Infogenesis device connection and perform handshake.
        
        Returns:
            bool: True if connection and handshake are valid
        """
        try:
            if not self.ip_connection or not self.port_connection:
                return False
            
            # Test UDP connection
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            test_socket.settimeout(5)
            
            # Try to connect to the device
            test_socket.connect((self.ip_connection, self.port_connection))
            test_socket.close()
            
            # Perform handshake if required
            if self.handshake_required and not self.handshake_completed:
                return self._perform_handshake()
            
            return True
            
        except Exception as e:
            print(f"Infogenesis connection validation failed: {e}")
            return False
    
    def _perform_handshake(self) -> bool:
        """
        Perform Infogenesis-specific handshake using the working protocol.
        
        Returns:
            bool: True if handshake successful
        """
        try:
            for attempt in range(self.handshake_retries):
                print(f"Infogenesis handshake attempt {attempt + 1}/{self.handshake_retries}")
                
                # Send SCM command (matching the working implementation)
                if self._send_scm_command():
                    # Wait for response and process
                    if self._wait_for_handshake_response():
                        self.handshake_completed = True
                        print(f"Infogenesis handshake completed successfully")
                        return True
                
                time.sleep(1)  # Wait before retry
            
            print(f"Infogenesis handshake failed after {self.handshake_retries} attempts")
            return False
            
        except Exception as e:
            print(f"Infogenesis handshake error: {e}")
            return False
    
    def _send_scm_command(self) -> bool:
        """
        Send SCM command to Infogenesis device (matching working implementation).
        
        Returns:
            bool: True if command sent successfully
        """
        try:
            # Create handshake socket
            handshake_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            handshake_socket.settimeout(self.handshake_timeout)
            
            # Use handshake handler to construct SCM command
            scm_command = self.handshake_handler.construct_scm_command("1")  # Default register
            
            print(f"Sending SCM command: {scm_command}")
            
            # Send SCM command
            handshake_socket.sendto(scm_command.encode('utf-8'), (self.ip_connection, self.port_connection))
            handshake_socket.close()
            
            return True
            
        except Exception as e:
            print(f"Failed to send SCM command: {e}")
            return False
    
    def _wait_for_handshake_response(self) -> bool:
        """
        Wait for handshake response from Infogenesis device.
        
        Returns:
            bool: True if valid response received
        """
        try:
            # Create response socket
            response_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            response_socket.settimeout(self.handshake_timeout)
            response_socket.bind(('', 0))  # Bind to any available port
            
            # Wait for response
            response_data, addr = response_socket.recvfrom(1024)
            response_socket.close()
            
            # Parse response
            response_str = response_data.decode('utf-8', errors='ignore')
            print(f"Received handshake response: {response_str}")
            
            # Check for special characters and process response
            if self.handshake_handler.contains_special_characters(response_str):
                # Process the response using handshake handler
                handshake_result = self.handshake_handler.manage_handshake_data(response_str, "1")
                
                if handshake_result.get("processed"):
                    message_type = handshake_result.get("message_type")
                    
                    if message_type == "PEM":
                        print(f"PEM message processed: {handshake_result.get('parsed_message')}")
                    
                    elif message_type == "PAM":
                        print("PAM command arrived")
                        return True
                    
                    elif message_type == "PCM":
                        print(f"PCM command arrived with hs_number: {handshake_result.get('hs_number')}")
                        return True
            
            return False
            
        except Exception as e:
            print(f"Failed to receive handshake response: {e}")
            return False
    

    
    def get_device_info(self) -> dict:
        """
        Get Infogenesis device information.
        
        Returns:
            dict: Infogenesis device information
        """
        base_info = super().get_device_info()
        # Get terminal state from handshake handler
        terminal_state = self.handshake_handler.get_terminal_state()
        
        base_info.update({
            "terminal_id": self.terminal_id,
            "terminal_ip": self.terminal_ip,
            "handshake_completed": self.handshake_handler.is_handshake_complete(),
            "handshake_session_id": self.handshake_session_id,
            "scm_ack": terminal_state.get("scm_ack", False),
            "hs_number": terminal_state.get("hs_number"),
            "terminal_output_mapping": self.terminal_output_mapping
        })
        return base_info
    
    def process_infogenesis_transaction(self, transaction_data: bytes) -> dict:
        """
        Process a complete Infogenesis transaction.
        
        Args:
            transaction_data: Complete transaction data
            
        Returns:
            dict: Transaction processing result
        """
        try:
            # Ensure handshake is completed
            if self.handshake_required and not self.handshake_completed:
                if not self._perform_handshake():
                    return {
                        "error": "Handshake required but failed",
                        "device_type": "infogenesis",
                        "terminal_id": self.terminal_id
                    }
            
            # Process through streaming pipeline
            result = self.process_streaming_data(transaction_data)
            
            # Get terminal state from handshake handler
            terminal_state = self.handshake_handler.get_terminal_state()
            
            # Add Infogenesis-specific processing
            result["infogenesis_specific"] = {
                "terminal_id": self.terminal_id,
                "terminal_ip": self.terminal_ip,
                "handshake_completed": self.handshake_handler.is_handshake_complete(),
                "handshake_session_id": self.handshake_session_id,
                "scm_ack": terminal_state.get("scm_ack", False),
                "hs_number": terminal_state.get("hs_number"),
                "output_mapping": self._get_output_mapping(),
                "transaction_processed": True
            }
            
            return result
            
        except Exception as e:
            return {
                "error": f"Failed to process Infogenesis transaction: {str(e)}",
                "device_type": "infogenesis",
                "terminal_id": self.terminal_id
            } 