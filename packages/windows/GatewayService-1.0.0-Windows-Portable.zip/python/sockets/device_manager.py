from sockets.device_handler import DeviceHandler

# Create a global instance of DeviceHandler
device_manager = DeviceHandler()
