"""
Analytics API Client for sending data to external analytics systems.

This module provides:
- HTTP client for RESTful API communication
- Batch processing for efficient data transmission
- Authentication handling (API keys, OAuth tokens)
- Rate limiting and retry logic
- Offline queuing when API is unavailable
- Error handling and logging
"""

import asyncio
import json
import time
import logging
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, field
from enum import Enum
import aiohttp
import aiofiles
from pathlib import Path

logger = logging.getLogger(__name__)


class AnalyticsEndpoint(str, Enum):
    """Analytics API endpoints."""
    TRANSACTIONS = "transactions"
    METRICS = "metrics"
    EVENTS = "events"
    HEALTH = "health"
    CONFIGURATION = "configuration"


@dataclass
class AnalyticsConfig:
    """Configuration for analytics API client."""
    base_url: str
    api_key: Optional[str] = None
    auth_token: Optional[str] = None
    timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 1.0
    batch_size: int = 100
    batch_timeout: float = 5.0
    rate_limit: int = 1000  # requests per minute
    queue_file: str = "analytics_queue.json"
    enable_offline_queue: bool = True


@dataclass
class AnalyticsMessage:
    """Structure for analytics messages."""
    endpoint: AnalyticsEndpoint
    data: Any
    timestamp: float = field(default_factory=time.time)
    message_id: Optional[str] = None
    retry_count: int = 0
    priority: int = 1  # 1=normal, 2=high, 3=urgent


class AnalyticsAPIClient:
    """
    Analytics API client for sending data to external systems.
    
    Features:
    - HTTP client with session management
    - Batch processing for efficiency
    - Authentication and rate limiting
    - Retry logic with exponential backoff
    - Offline queuing for reliability
    - Error handling and logging
    """

    def __init__(self, config: AnalyticsConfig):
        self.config = config
        self.session: Optional[aiohttp.ClientSession] = None
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.batch_queue: List[AnalyticsMessage] = []
        self.last_request_time = 0.0
        self.request_count = 0
        self.rate_limit_reset_time = time.time() + 60
        self.is_running = False
        self.offline_queue_file = Path(config.queue_file)
        
        # Load offline queue if exists
        self._load_offline_queue()

    def _load_offline_queue(self) -> None:
        """Load messages from offline queue file."""
        if not self.config.enable_offline_queue or not self.offline_queue_file.exists():
            return
        
        try:
            with open(self.offline_queue_file, 'r') as f:
                data = json.load(f)
                messages = data.get('messages', [])
                
                for msg_data in messages:
                    try:
                        message = AnalyticsMessage(
                            endpoint=AnalyticsEndpoint(msg_data['endpoint']),
                            data=msg_data['data'],
                            timestamp=msg_data['timestamp'],
                            message_id=msg_data.get('message_id'),
                            retry_count=msg_data.get('retry_count', 0),
                            priority=msg_data.get('priority', 1)
                        )
                        asyncio.create_task(self.message_queue.put(message))
                    except Exception as e:
                        logger.warning(f"Failed to load queued message: {e}")
                
                logger.info(f"Loaded {len(messages)} messages from offline queue")
                
        except Exception as e:
            logger.error(f"Failed to load offline queue: {e}")

    def _save_offline_queue(self) -> None:
        """Save messages to offline queue file."""
        if not self.config.enable_offline_queue:
            return
        
        try:
            # Get all messages from queue
            messages = []
            while not self.message_queue.empty():
                try:
                    message = self.message_queue.get_nowait()
                    messages.append({
                        'endpoint': message.endpoint.value,
                        'data': message.data,
                        'timestamp': message.timestamp,
                        'message_id': message.message_id,
                        'retry_count': message.retry_count,
                        'priority': message.priority
                    })
                except asyncio.QueueEmpty:
                    break
            
            # Add batch queue messages
            for message in self.batch_queue:
                messages.append({
                    'endpoint': message.endpoint.value,
                    'data': message.data,
                    'timestamp': message.timestamp,
                    'message_id': message.message_id,
                    'retry_count': message.retry_count,
                    'priority': message.priority
                })
            
            if messages:
                data = {
                    'timestamp': time.time(),
                    'message_count': len(messages),
                    'messages': messages
                }
                
                with open(self.offline_queue_file, 'w') as f:
                    json.dump(data, f, indent=2)
                
                logger.info(f"Saved {len(messages)} messages to offline queue")
                
        except Exception as e:
            logger.error(f"Failed to save offline queue: {e}")

    async def start(self) -> None:
        """Start the analytics API client."""
        if self.is_running:
            return
        
        self.is_running = True
        
        # Create HTTP session
        timeout = aiohttp.ClientTimeout(total=self.config.timeout)
        self.session = aiohttp.ClientSession(
            timeout=timeout,
            headers=self._get_default_headers()
        )
        
        # Start background tasks
        asyncio.create_task(self._batch_processor())
        asyncio.create_task(self._queue_processor())
        
        logger.info("Analytics API client started")

    async def stop(self) -> None:
        """Stop the analytics API client."""
        self.is_running = False
        
        # Save offline queue
        self._save_offline_queue()
        
        # Close HTTP session
        if self.session:
            await self.session.close()
            self.session = None
        
        logger.info("Analytics API client stopped")

    def _get_default_headers(self) -> Dict[str, str]:
        """Get default HTTP headers."""
        headers = {
            'Content-Type': 'application/json',
            'User-Agent': 'GatewayService/1.0'
        }
        
        if self.config.api_key:
            headers['X-API-Key'] = self.config.api_key
        
        if self.config.auth_token:
            headers['Authorization'] = f'Bearer {self.config.auth_token}'
        
        return headers

    async def send_message(self, endpoint: AnalyticsEndpoint, data: Any, 
                          priority: int = 1, message_id: Optional[str] = None) -> bool:
        """
        Send a message to the analytics API.
        
        Args:
            endpoint: The API endpoint to send to
            data: The data to send
            priority: Message priority (1=normal, 2=high, 3=urgent)
            message_id: Optional message ID for tracking
            
        Returns:
            True if message was queued successfully, False otherwise
        """
        try:
            message = AnalyticsMessage(
                endpoint=endpoint,
                data=data,
                message_id=message_id,
                priority=priority
            )
            
            await self.message_queue.put(message)
            logger.debug(f"Queued message for {endpoint}: {message_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to queue message: {e}")
            return False

    async def send_transaction(self, transaction_data: Dict[str, Any], 
                              message_id: Optional[str] = None) -> bool:
        """Send transaction data to analytics API."""
        return await self.send_message(
            AnalyticsEndpoint.TRANSACTIONS,
            transaction_data,
            priority=2,  # High priority for transactions
            message_id=message_id
        )

    async def send_metrics(self, metrics_data: Dict[str, Any], 
                          message_id: Optional[str] = None) -> bool:
        """Send metrics data to analytics API."""
        return await self.send_message(
            AnalyticsEndpoint.METRICS,
            metrics_data,
            priority=1,
            message_id=message_id
        )

    async def send_event(self, event_data: Dict[str, Any], 
                        message_id: Optional[str] = None) -> bool:
        """Send event data to analytics API."""
        return await self.send_message(
            AnalyticsEndpoint.EVENTS,
            event_data,
            priority=1,
            message_id=message_id
        )

    async def send_health_update(self, health_data: Dict[str, Any], 
                                message_id: Optional[str] = None) -> bool:
        """Send health update to analytics API."""
        return await self.send_message(
            AnalyticsEndpoint.HEALTH,
            health_data,
            priority=3,  # Urgent priority for health updates
            message_id=message_id
        )

    async def _queue_processor(self) -> None:
        """Background task to process message queue."""
        while self.is_running:
            try:
                # Get message from queue
                message = await asyncio.wait_for(
                    self.message_queue.get(), 
                    timeout=1.0
                )
                
                # Add to batch queue
                self.batch_queue.append(message)
                
                # Process batch if full or timeout reached
                if (len(self.batch_queue) >= self.config.batch_size or 
                    time.time() - self.batch_queue[0].timestamp >= self.config.batch_timeout):
                    await self._process_batch()
                    
            except asyncio.TimeoutError:
                # Process any remaining messages in batch
                if self.batch_queue:
                    await self._process_batch()
            except Exception as e:
                logger.error(f"Error in queue processor: {e}")
                await asyncio.sleep(1)

    async def _batch_processor(self) -> None:
        """Background task to process batches periodically."""
        while self.is_running:
            try:
                await asyncio.sleep(self.config.batch_timeout)
                
                # Process any messages in batch
                if self.batch_queue:
                    await self._process_batch()
                    
            except Exception as e:
                logger.error(f"Error in batch processor: {e}")

    async def _process_batch(self) -> None:
        """Process a batch of messages."""
        if not self.batch_queue:
            return
        
        # Sort by priority (urgent first)
        self.batch_queue.sort(key=lambda x: x.priority, reverse=True)
        
        # Group by endpoint
        endpoint_groups: Dict[AnalyticsEndpoint, List[AnalyticsMessage]] = {}
        for message in self.batch_queue:
            if message.endpoint not in endpoint_groups:
                endpoint_groups[message.endpoint] = []
            endpoint_groups[message.endpoint].append(message)
        
        # Clear batch queue
        self.batch_queue.clear()
        
        # Send each group
        for endpoint, messages in endpoint_groups.items():
            await self._send_batch(endpoint, messages)

    async def _send_batch(self, endpoint: AnalyticsEndpoint, 
                         messages: List[AnalyticsMessage]) -> None:
        """Send a batch of messages to a specific endpoint."""
        if not messages:
            return
        
        # Prepare batch data
        batch_data = {
            'timestamp': time.time(),
            'batch_id': f"batch_{int(time.time() * 1000)}",
            'message_count': len(messages),
            'messages': [
                {
                    'id': msg.message_id,
                    'timestamp': msg.timestamp,
                    'data': msg.data,
                    'retry_count': msg.retry_count
                }
                for msg in messages
            ]
        }
        
        # Send batch
        success = await self._send_request(endpoint, batch_data)
        
        if success:
            logger.info(f"Successfully sent batch of {len(messages)} messages to {endpoint}")
        else:
            # Re-queue failed messages
            for message in messages:
                if message.retry_count < self.config.max_retries:
                    message.retry_count += 1
                    await self.message_queue.put(message)
                else:
                    logger.error(f"Message {message.message_id} exceeded max retries")

    async def _send_request(self, endpoint: AnalyticsEndpoint, 
                           data: Dict[str, Any]) -> bool:
        """Send a single request to the analytics API."""
        if not self.session:
            return False
        
        # Check rate limit
        if not await self._check_rate_limit():
            logger.warning("Rate limit exceeded, queuing message")
            return False
        
        url = f"{self.config.base_url.rstrip('/')}/{endpoint.value}"
        
        try:
            async with self.session.post(url, json=data) as response:
                self._update_rate_limit()
                
                if response.status == 200:
                    return True
                elif response.status == 429:  # Rate limited
                    logger.warning("Rate limited by server")
                    return False
                elif response.status >= 500:  # Server error
                    logger.error(f"Server error: {response.status}")
                    return False
                else:
                    logger.error(f"API error: {response.status} - {await response.text()}")
                    return False
                    
        except asyncio.TimeoutError:
            logger.error("Request timeout")
            return False
        except aiohttp.ClientError as e:
            logger.error(f"Client error: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return False

    async def _check_rate_limit(self) -> bool:
        """Check if we're within rate limits."""
        current_time = time.time()
        
        # Reset counter if minute has passed
        if current_time >= self.rate_limit_reset_time:
            self.request_count = 0
            self.rate_limit_reset_time = current_time + 60
        
        return self.request_count < self.config.rate_limit

    def _update_rate_limit(self) -> None:
        """Update rate limit counter."""
        self.request_count += 1
        self.last_request_time = time.time()

    async def _retry_with_backoff(self, func, *args, **kwargs) -> Any:
        """Retry a function with exponential backoff."""
        for attempt in range(self.config.max_retries):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                if attempt == self.config.max_retries - 1:
                    raise e
                
                delay = self.config.retry_delay * (2 ** attempt)
                logger.warning(f"Attempt {attempt + 1} failed, retrying in {delay}s: {e}")
                await asyncio.sleep(delay)

    def get_stats(self) -> Dict[str, Any]:
        """Get client statistics."""
        return {
            'is_running': self.is_running,
            'queue_size': self.message_queue.qsize(),
            'batch_size': len(self.batch_queue),
            'request_count': self.request_count,
            'rate_limit': self.config.rate_limit,
            'last_request_time': self.last_request_time,
            'offline_queue_enabled': self.config.enable_offline_queue,
            'offline_queue_file': str(self.offline_queue_file)
        }


# Global analytics client instance
_analytics_client: Optional[AnalyticsAPIClient] = None


def get_analytics_client() -> Optional[AnalyticsAPIClient]:
    """Get the global analytics client instance."""
    return _analytics_client


def set_analytics_client(client: AnalyticsAPIClient) -> None:
    """Set the global analytics client instance."""
    global _analytics_client
    _analytics_client = client


async def send_analytics_message(endpoint: AnalyticsEndpoint, data: Any, 
                                priority: int = 1, message_id: Optional[str] = None) -> bool:
    """Send a message using the global analytics client."""
    client = get_analytics_client()
    if client:
        return await client.send_message(endpoint, data, priority, message_id)
    else:
        logger.warning("Analytics client not available")
        return False


async def send_transaction_data(transaction_data: Dict[str, Any], 
                               message_id: Optional[str] = None) -> bool:
    """Send transaction data using the global analytics client."""
    client = get_analytics_client()
    if client:
        return await client.send_transaction(transaction_data, message_id)
    else:
        logger.warning("Analytics client not available")
        return False


async def send_metrics_data(metrics_data: Dict[str, Any], 
                           message_id: Optional[str] = None) -> bool:
    """Send metrics data using the global analytics client."""
    client = get_analytics_client()
    if client:
        return await client.send_metrics(metrics_data, message_id)
    else:
        logger.warning("Analytics client not available")
        return False


async def send_event_data(event_data: Dict[str, Any], 
                         message_id: Optional[str] = None) -> bool:
    """Send event data using the global analytics client."""
    client = get_analytics_client()
    if client:
        return await client.send_event(event_data, message_id)
    else:
        logger.warning("Analytics client not available")
        return False


async def send_health_data(health_data: Dict[str, Any], 
                          message_id: Optional[str] = None) -> bool:
    """Send health data using the global analytics client."""
    client = get_analytics_client()
    if client:
        return await client.send_health_update(health_data, message_id)
    else:
        logger.warning("Analytics client not available")
        return False 