import asyncio
import logging
from typing import Dict, Any, Optional
from datetime import datetime

from core.device_interfaces import DeviceConnection, DeviceStatus, DeviceEvent, EventType
from core.sdk_integration import SDKFactory, SDKAdapter, SDKConnectionStatus

logger = logging.getLogger(__name__)

class RealSDKDeviceConnection(DeviceConnection):
    """Real SDK-based device connection using SDK adapters"""
    
    def __init__(self, device_config: Dict[str, Any]):
        super().__init__(device_config)
        self.sdk_adapter: Optional[SDKAdapter] = None
        self.device_id = device_config.get("device_id", "unknown")
        self.sdk_config = device_config.get("sdk_config")
        
        # Create SDK adapter if SDK config is provided
        if self.sdk_config:
            self.sdk_adapter = SDKFactory.create_sdk_adapter(self.device_id, self.sdk_config)

    async def connect(self) -> bool:
        """Connect to the device via SDK"""
        try:
            if not self.sdk_adapter:
                logger.error(f"No SDK adapter available for device {self.device_id}")
                self.update_status(DeviceStatus.ERROR)
                return False
            
            # Initialize SDK adapter
            if not await self.sdk_adapter.initialize():
                logger.error(f"Failed to initialize SDK adapter for device {self.device_id}")
                self.update_status(DeviceStatus.ERROR)
                return False
            
            # Connect via SDK
            if await self.sdk_adapter.connect():
                self.update_status(DeviceStatus.CONNECTED)
                logger.info(f"Successfully connected to device {self.device_id} via SDK")
                return True
            else:
                logger.error(f"Failed to connect to device {self.device_id} via SDK")
                self.update_status(DeviceStatus.ERROR)
                return False
                
        except Exception as e:
            logger.error(f"Error connecting to device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def disconnect(self) -> bool:
        """Disconnect from the device"""
        try:
            if self.sdk_adapter:
                success = await self.sdk_adapter.disconnect()
                if success:
                    self.update_status(DeviceStatus.DISCONNECTED)
                    logger.info(f"Successfully disconnected from device {self.device_id}")
                    return True
                else:
                    logger.error(f"Failed to disconnect from device {self.device_id}")
                    return False
            
            self.update_status(DeviceStatus.DISCONNECTED)
            return True
            
        except Exception as e:
            logger.error(f"Error disconnecting from device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def send_data(self, data: bytes) -> bool:
        """Send data to the device via SDK"""
        try:
            if not self.sdk_adapter or not self.sdk_adapter.is_connected():
                logger.error(f"SDK adapter not connected for device {self.device_id}")
                return False
            
            # Convert bytes to dict for SDK
            try:
                data_dict = data.decode('utf-8')
                import json
                data_dict = json.loads(data_dict)
            except:
                data_dict = {"raw_data": str(data)}
            
            success = await self.sdk_adapter.send_data(data_dict)
            if success:
                self.last_activity = datetime.now()
                return True
            else:
                logger.error(f"Failed to send data to device {self.device_id}")
                return False
                
        except Exception as e:
            logger.error(f"Error sending data to device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def receive_data(self) -> Optional[bytes]:
        """Receive data from the device via SDK"""
        try:
            if not self.sdk_adapter or not self.sdk_adapter.is_connected():
                logger.error(f"SDK adapter not connected for device {self.device_id}")
                return None
            
            data = await self.sdk_adapter.receive_data()
            if data:
                self.last_activity = datetime.now()
                # Convert dict to bytes for compatibility
                import json
                return json.dumps(data).encode('utf-8')
            
            return None
            
        except Exception as e:
            logger.error(f"Error receiving data from device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return None

    def get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        info = {
            "device_id": self.device_id,
            "device_type": self.device_type,
            "status": self.status.value,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "error_count": self.error_count,
            "connection_type": "sdk"
        }
        
        if self.sdk_adapter:
            info.update(self.sdk_adapter.get_connection_info())
        
        return info

    def get_connection_type(self) -> str:
        """Get connection type"""
        return "sdk"

class RealSocketDeviceConnection(DeviceConnection):
    """Real socket-based device connection"""
    
    def __init__(self, device_config: Dict[str, Any]):
        super().__init__(device_config)
        self.device_id = device_config.get("device_id", "unknown")
        self.socket_config = device_config.get("socket_config")
        if self.socket_config:
            # Handle both dict and Pydantic model
            if hasattr(self.socket_config, 'model_dump'):
                # Pydantic model
                config_dict = self.socket_config.model_dump()
            else:
                # Dictionary
                config_dict = self.socket_config
        else:
            config_dict = {}
            
        self.socket_type = config_dict.get("type", "tcp")
        self.host = config_dict.get("host", "")
        self.port = config_dict.get("port", 0)
        self.mode = config_dict.get("mode", "connect")
        self.timeout = config_dict.get("timeout", 30)
        self.socket = None

    async def connect(self) -> bool:
        """Connect to the device via socket"""
        try:
            logger.info(f"Connecting to device {self.device_id} via {self.socket_type} at {self.host}:{self.port}")
            
            if self.socket_type.lower() == "tcp":
                return await self._connect_tcp()
            elif self.socket_type.lower() == "udp":
                return await self._connect_udp()
            elif self.socket_type.lower() == "multicast":
                return await self._connect_multicast()
            else:
                logger.error(f"Unsupported socket type: {self.socket_type}")
                self.update_status(DeviceStatus.ERROR)
                return False
                
        except Exception as e:
            logger.error(f"Error connecting to device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def _connect_tcp(self) -> bool:
        """Connect via TCP"""
        try:
            import socket
            
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(self.timeout)
            
            # Run in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.socket.connect, (self.host, self.port))
            
            self.update_status(DeviceStatus.CONNECTED)
            logger.info(f"Successfully connected to device {self.device_id} via TCP")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to device {self.device_id} via TCP: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def _connect_udp(self) -> bool:
        """Connect via UDP"""
        try:
            import socket
            
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.socket.settimeout(self.timeout)
            
            # For UDP, we just store the address for sending
            self.socket_address = (self.host, self.port)
            
            self.update_status(DeviceStatus.CONNECTED)
            logger.info(f"Successfully connected to device {self.device_id} via UDP")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to device {self.device_id} via UDP: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def _connect_multicast(self) -> bool:
        """Connect via multicast"""
        try:
            import socket
            
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            if self.mode == "listen":
                # Bind to multicast group
                self.socket.bind(('', self.port))
                mreq = socket.struct.pack("4sl", socket.inet_aton(self.host), socket.INADDR_ANY)
                self.socket.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
            else:
                # Send mode - just store the address
                self.socket_address = (self.host, self.port)
            
            self.update_status(DeviceStatus.CONNECTED)
            logger.info(f"Successfully connected to device {self.device_id} via multicast")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to device {self.device_id} via multicast: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def disconnect(self) -> bool:
        """Disconnect from the device"""
        try:
            if self.socket:
                self.socket.close()
                self.socket = None
            
            self.update_status(DeviceStatus.DISCONNECTED)
            logger.info(f"Successfully disconnected from device {self.device_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error disconnecting from device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def send_data(self, data: bytes) -> bool:
        """Send data to the device via socket"""
        try:
            if not self.socket:
                logger.error(f"Socket not connected for device {self.device_id}")
                return False
            
            # Run in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            
            if self.socket_type.lower() == "tcp":
                await loop.run_in_executor(None, self.socket.send, data)
            elif self.socket_type.lower() in ["udp", "multicast"]:
                address = getattr(self, 'socket_address', (self.host, self.port))
                await loop.run_in_executor(None, self.socket.sendto, data, address)
            
            self.last_activity = datetime.now()
            return True
            
        except Exception as e:
            logger.error(f"Error sending data to device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return False

    async def receive_data(self) -> Optional[bytes]:
        """Receive data from the device via socket"""
        try:
            if not self.socket:
                logger.error(f"Socket not connected for device {self.device_id}")
                return None
            
            # Run in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            
            if self.socket_type.lower() == "tcp":
                data = await loop.run_in_executor(None, self.socket.recv, 4096)
            elif self.socket_type.lower() in ["udp", "multicast"]:
                data, addr = await loop.run_in_executor(None, self.socket.recvfrom, 4096)
            else:
                return None
            
            if data:
                self.last_activity = datetime.now()
                return data
            
            return None
            
        except Exception as e:
            logger.error(f"Error receiving data from device {self.device_id}: {e}")
            self.update_status(DeviceStatus.ERROR)
            return None

    def get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        return {
            "device_id": self.device_id,
            "device_type": self.device_type,
            "status": self.status.value,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "error_count": self.error_count,
            "connection_type": "socket",
            "socket_type": self.socket_type,
            "host": self.host,
            "port": self.port,
            "mode": self.mode
        }

    def get_connection_type(self) -> str:
        """Get connection type"""
        return "socket"

class RealDeviceFactory:
    """Factory for creating real device connections"""
    
    @staticmethod
    def create_device(device_id: str, device_config: Dict[str, Any]) -> Optional[DeviceConnection]:
        """Create real device connection based on configuration"""
        try:
            connection_type = device_config.get("connection_type", "socket")
            
            if connection_type == "sdk":
                # Create SDK-based device
                return RealSDKDeviceConnection(device_config)
            elif connection_type == "socket":
                # Create socket-based device
                return RealSocketDeviceConnection(device_config)
            else:
                logger.error(f"Unsupported connection type: {connection_type}")
                return None
                
        except Exception as e:
            logger.error(f"Failed to create real device {device_id}: {e}")
            return None 