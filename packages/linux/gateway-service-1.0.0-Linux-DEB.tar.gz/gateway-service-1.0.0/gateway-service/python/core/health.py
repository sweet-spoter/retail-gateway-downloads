from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum
import asyncio
import time
from core.logging_config import get_logger

class HealthStatus(Enum):
    """Health status enumeration"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class HealthCheck:
    """Individual health check result"""
    name: str
    status: HealthStatus
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: float = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()

class HealthChecker:
    """Centralized health checking system"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.checks: List[HealthCheck] = []
        self.last_check_time: Optional[float] = None
        self.check_interval: float = 30.0  # seconds
    
    async def run_health_checks(self, app_service) -> Dict[str, Any]:
        """Run all health checks"""
        self.logger.debug("Running health checks")
        
        checks = []
        
        # Service health check
        service_health = await self._check_service_health(app_service)
        checks.append(service_health)
        
        # Connection health check
        if app_service.connection_manager:
            connection_health = await self._check_connection_health(app_service.connection_manager)
            checks.append(connection_health)
        
        # Configuration health check
        config_health = await self._check_configuration_health(app_service)
        checks.append(config_health)
        
        # Memory usage check
        memory_health = await self._check_memory_usage()
        checks.append(memory_health)
        
        self.checks = checks
        self.last_check_time = time.time()
        
        return self._aggregate_health_status(checks)
    
    async def _check_service_health(self, app_service) -> HealthCheck:
        """Check application service health"""
        try:
            if not app_service.running:
                return HealthCheck(
                    name="service_status",
                    status=HealthStatus.UNHEALTHY,
                    message="Application service is not running"
                )
            
            if not app_service.is_healthy():
                return HealthCheck(
                    name="service_status",
                    status=HealthStatus.DEGRADED,
                    message="Application service is running but unhealthy"
                )
            
            return HealthCheck(
                name="service_status",
                status=HealthStatus.HEALTHY,
                message="Application service is healthy",
                details={
                    "uptime": app_service.get_status().get("uptime", 0),
                    "startup_time": app_service.startup_time
                }
            )
        except Exception as e:
            return HealthCheck(
                name="service_status",
                status=HealthStatus.UNHEALTHY,
                message=f"Service health check failed: {e}"
            )
    
    async def _check_connection_health(self, connection_manager) -> HealthCheck:
        """Check connection health"""
        try:
            status = connection_manager.get_connection_status()
            active_connections = sum(1 for is_active in status.values() if is_active)
            total_connections = len(status)
            
            if total_connections == 0:
                return HealthCheck(
                    name="connections",
                    status=HealthStatus.UNKNOWN,
                    message="No connections configured"
                )
            
            if active_connections == 0:
                return HealthCheck(
                    name="connections",
                    status=HealthStatus.UNHEALTHY,
                    message="No active connections",
                    details={"active": 0, "total": total_connections}
                )
            
            if active_connections < total_connections:
                return HealthCheck(
                    name="connections",
                    status=HealthStatus.DEGRADED,
                    message=f"Some connections are inactive",
                    details={"active": active_connections, "total": total_connections}
                )
            
            return HealthCheck(
                name="connections",
                status=HealthStatus.HEALTHY,
                message="All connections are active",
                details={"active": active_connections, "total": total_connections}
            )
        except Exception as e:
            return HealthCheck(
                name="connections",
                status=HealthStatus.UNHEALTHY,
                message=f"Connection health check failed: {e}"
            )
    
    async def _check_configuration_health(self, app_service) -> HealthCheck:
        """Check configuration health"""
        try:
            config = await app_service.get_configuration()
            
            # Basic validation
            if not config.input_configs and not config.output_configs:
                return HealthCheck(
                    name="configuration",
                    status=HealthStatus.DEGRADED,
                    message="No input or output configurations found"
                )
            
            return HealthCheck(
                name="configuration",
                status=HealthStatus.HEALTHY,
                message="Configuration is valid",
                details={
                    "input_configs": len(config.input_configs),
                    "output_configs": len(config.output_configs)
                }
            )
        except Exception as e:
            return HealthCheck(
                name="configuration",
                status=HealthStatus.UNHEALTHY,
                message=f"Configuration health check failed: {e}"
            )
    
    async def _check_memory_usage(self) -> HealthCheck:
        """Check memory usage"""
        try:
            import psutil
            process = psutil.Process()
            memory_info = process.memory_info()
            memory_percent = process.memory_percent()
            
            # Consider unhealthy if using more than 80% of available memory
            if memory_percent > 80:
                status = HealthStatus.UNHEALTHY
                message = f"High memory usage: {memory_percent:.1f}%"
            elif memory_percent > 60:
                status = HealthStatus.DEGRADED
                message = f"Elevated memory usage: {memory_percent:.1f}%"
            else:
                status = HealthStatus.HEALTHY
                message = f"Normal memory usage: {memory_percent:.1f}%"
            
            return HealthCheck(
                name="memory_usage",
                status=status,
                message=message,
                details={
                    "rss_mb": memory_info.rss / 1024 / 1024,
                    "vms_mb": memory_info.vms / 1024 / 1024,
                    "percent": memory_percent
                }
            )
        except ImportError:
            return HealthCheck(
                name="memory_usage",
                status=HealthStatus.UNKNOWN,
                message="psutil not available for memory monitoring"
            )
        except Exception as e:
            return HealthCheck(
                name="memory_usage",
                status=HealthStatus.UNKNOWN,
                message=f"Memory check failed: {e}"
            )
    
    def _aggregate_health_status(self, checks: List[HealthCheck]) -> Dict[str, Any]:
        """Aggregate individual health checks into overall status"""
        if not checks:
            return {
                "status": HealthStatus.UNKNOWN.value,
                "message": "No health checks available",
                "timestamp": time.time(),
                "checks": []
            }
        
        # Determine overall status
        status_counts = {}
        for check in checks:
            status_counts[check.status] = status_counts.get(check.status, 0) + 1
        
        if HealthStatus.UNHEALTHY in status_counts:
            overall_status = HealthStatus.UNHEALTHY
            message = "Service is unhealthy"
        elif HealthStatus.DEGRADED in status_counts:
            overall_status = HealthStatus.DEGRADED
            message = "Service is degraded"
        elif HealthStatus.HEALTHY in status_counts:
            overall_status = HealthStatus.HEALTHY
            message = "Service is healthy"
        else:
            overall_status = HealthStatus.UNKNOWN
            message = "Service status unknown"
        
        return {
            "status": overall_status.value,
            "message": message,
            "timestamp": time.time(),
            "checks": [
                {
                    "name": check.name,
                    "status": check.status.value,
                    "message": check.message,
                    "details": check.details,
                    "timestamp": check.timestamp
                }
                for check in checks
            ]
        }
    
    def get_last_health_status(self) -> Optional[Dict[str, Any]]:
        """Get the last health check results"""
        if not self.checks:
            return None
        
        return self._aggregate_health_status(self.checks) 