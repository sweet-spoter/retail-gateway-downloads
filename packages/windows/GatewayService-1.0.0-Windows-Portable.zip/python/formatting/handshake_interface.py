import asyncio

from formatting.infogenesis import *

async def handshake_data_interface(data):
    if data["device"] == 'infogenesis':
        if data["data"] == "start":
            await start_handshake(data)
        else:
            await manage_handshake_data(data)