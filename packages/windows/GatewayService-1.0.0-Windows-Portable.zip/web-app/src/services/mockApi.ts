// Mock API for testing without backend
import { LoginResponse, HealthStatus, Metrics, Device, Configuration } from './api';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Mock data
const mockUser = {
  id: '1',
  username: 'admin',
  email: 'admin@gateway.com',
  role: 'admin' as 'admin',
  permissions: ['read', 'write', 'admin'],
};

const mockHealthData: HealthStatus = {
  status: 'healthy',
  message: 'Service is healthy',
  timestamp: Date.now(),
  checks: [
    {
      name: 'service_status',
      status: 'healthy',
      message: 'Application service is healthy',
      details: {
        uptime: 3600,
        startup_time: Date.now() - 3600000,
      },
      timestamp: Date.now(),
    },
    {
      name: 'connections',
      status: 'healthy',
      message: 'All connections are active',
      details: {
        active: 3,
        total: 3,
      },
      timestamp: Date.now(),
    },
    {
      name: 'configuration',
      status: 'healthy',
      message: 'Configuration is valid',
      details: {
        input_configs: 2,
        output_configs: 1,
      },
      timestamp: Date.now(),
    },
    {
      name: 'memory_usage',
      status: 'healthy',
      message: 'Normal memory usage: 25.3%',
      details: {
        rss_mb: 128.5,
        vms_mb: 256.0,
        percent: 25.3,
      },
      timestamp: Date.now(),
    },
  ],
};

const mockMetricsData: Metrics = {
  timestamp: Date.now(),
  metrics: {
    connections_active: {
      name: 'connections_active',
      description: 'Number of active connections',
      count: 100,
      min: 0,
      max: 5,
      avg: 2.5,
      latest: 3,
    },
    messages_sent: {
      name: 'messages_sent',
      description: 'Number of messages sent',
      count: 100,
      min: 0,
      max: 1000,
      avg: 450,
      latest: 1250,
    },
    messages_received: {
      name: 'messages_received',
      description: 'Number of messages received',
      count: 100,
      min: 0,
      max: 1000,
      avg: 420,
      latest: 980,
    },
    connections_errors: {
      name: 'connections_errors',
      description: 'Number of connection errors',
      count: 100,
      min: 0,
      max: 10,
      avg: 2,
      latest: 1,
    },
  },
};

const mockServiceStatus = {
  running: true,
  healthy: true,
  uptime: 3600,
  startup_time: Date.now() - 3600000,
  version: '1.0.0',
  last_updated: new Date().toISOString(),
  connections: {
    'connection1': true,
    'connection2': true,
    'connection3': false,
  },
};

export const mockLocation = {
  id: '1',
  name: 'Downtown Casino',
  address: '123 Main Street',
  city: 'Las Vegas',
  state: 'NV',
  country: 'USA',
  timezone: 'America/Los_Angeles',
  coordinates: {
    latitude: 36.1699,
    longitude: -115.1398,
  },
};

export const mockClient = {
  id: '1',
  name: 'Gulfcoast Gaming',
  code: 'GCG001',
  contact: {
    email: 'support@gulfcoast.com',
    phone: '+1-555-0123',
    address: '456 Business Ave, Miami, FL 33101',
  },
  settings: {
    timezone: 'America/New_York',
    currency: 'USD',
    language: 'en',
  },
};

const mockDevices: Device[] = [
  {
    id: '1',
    name: 'Terminal-01',
    type: 'infogenesis',
    status: 'online',
    lastSeen: new Date().toISOString(),
    configuration: {
      host: '192.168.1.100',
      port: 5999,
      register: '101',
      location: mockLocation,
      client: mockClient,
    },
  },
  {
    id: '2',
    name: 'Terminal-02',
    type: 'verifone',
    status: 'online',
    lastSeen: new Date().toISOString(),
    configuration: {
      host: '192.168.1.101',
      port: 5999,
      register: '102',
      location: mockLocation,
      client: mockClient,
    },
  },
  {
    id: '3',
    name: 'API-Endpoint',
    type: 'api',
    status: 'offline',
    lastSeen: new Date(Date.now() - 300000).toISOString(),
    configuration: {
      host: '127.0.0.1',
      port: 5002,
      register: 'api_101',
      location: mockLocation,
      client: mockClient,
    },
  },
];

const mockConfigurations: Configuration[] = [
  {
    id: '1',
    name: 'Input Config 1',
    type: 'input',
    socketType: 'tcp',
    connectionType: 'listen',
    host: '0.0.0.0',
    port: 5999,
    device: {
      name: 'infogenesis',
      type: 'handshake',
      terminals: [
        {
          term_id: 101,
          term_ip: '192.168.1.0/24',
        },
      ],
    },
    filter: {
      date: [0, 8],
      time: [9, 17],
      terminal: [18, 21],
      description: [22, -13],
      quantity: [-12, -9],
      price: [-8, null],
    },
  },
  {
    id: '2',
    name: 'Output Config 1',
    type: 'output',
    socketType: 'tcp',
    connectionType: 'connect',
    host: '127.0.0.1',
    port: 5002,
    device: {
      name: 'api_endpoint',
      type: 'api',
    },
  },
  {
    id: '3',
    name: 'Analytics API Config',
    type: 'analytics',
    socketType: 'http',
    connectionType: 'connect',
    host: 'https://analytics.gulfcoast.com',
    port: 443,
    device: {
      name: 'analytics_api',
      type: 'rest',
    },
    analytics: {
      enabled: true,
      endpoint: '/api/v1/transactions',
      apiKey: 'gc_analytics_key_12345',
      dataMapping: {
        transaction_id: 'terminal',
        amount: 'quantity',
        timestamp: 'date_time',
        location: 'location_name',
        client: 'client_code',
      },
    },
  },
];

// Mock API functions
export const mockAuthAPI = {
  login: async (username: string, password: string): Promise<LoginResponse> => {
    await delay(1000); // Simulate network delay
    
    if (username === 'admin' && password === 'admin123') {
      return {
        user: mockUser,
        token: 'mock-jwt-token-' + Date.now(),
      };
    }
    
    throw new Error('Invalid credentials');
  },

  validateToken: async (token: string) => {
    await delay(500);
    return mockUser;
  },

  logout: async () => {
    await delay(300);
  },
};

export const mockHealthAPI = {
  getHealth: async (): Promise<HealthStatus> => {
    await delay(800);
    return mockHealthData;
  },

  getStatus: async () => {
    await delay(500);
    return mockServiceStatus;
  },

  getInfo: async () => {
    await delay(300);
    return {
      name: 'Gateway Service',
      version: '1.0.0',
      description: 'Gateway service for device communication',
      uptime: 3600,
      startup_time: Date.now() - 3600000,
      running: true,
      healthy: true,
      timestamp: Date.now(),
    };
  },
};

export const mockMetricsAPI = {
  getMetrics: async (): Promise<Metrics> => {
    await delay(600);
    return mockMetricsData;
  },

  getPrometheusMetrics: async (): Promise<string> => {
    await delay(400);
    return `# HELP connections_active Number of active connections
# TYPE connections_active gauge
connections_active 3 ${Date.now()}

# HELP messages_sent Number of messages sent
# TYPE messages_sent counter
messages_sent 1250 ${Date.now()}`;
  },
};

export const mockServiceAPI = {
  startService: async () => {
    await delay(1000);
    return { success: true, message: 'Service started successfully' };
  },

  stopService: async () => {
    await delay(1000);
    return { success: true, message: 'Service stopped successfully' };
  },

  restartService: async () => {
    await delay(1500);
    return { success: true, message: 'Service restarted successfully' };
  },

  getServiceStatus: async () => {
    await delay(500);
    return mockServiceStatus;
  },
};

export const mockDeviceAPI = {
  getDevices: async (): Promise<Device[]> => {
    await delay(800);
    return mockDevices;
  },

  getDevice: async (id: string): Promise<Device> => {
    await delay(500);
    const device = mockDevices.find(d => d.id === id);
    if (!device) throw new Error('Device not found');
    return device;
  },

  createDevice: async (device: Partial<Device>): Promise<Device> => {
    await delay(1000);
    return {
      id: Date.now().toString(),
      name: device.name || 'New Device',
      type: device.type || 'unknown',
      status: 'offline',
      lastSeen: new Date().toISOString(),
      configuration: device.configuration || {},
    };
  },

  updateDevice: async (id: string, device: Partial<Device>): Promise<Device> => {
    await delay(800);
    return {
      id,
      name: device.name || 'Updated Device',
      type: device.type || 'unknown',
      status: device.status || 'offline',
      lastSeen: new Date().toISOString(),
      configuration: device.configuration || {},
    };
  },

  deleteDevice: async (id: string): Promise<void> => {
    await delay(600);
  },

  discoverDevices: async (): Promise<Device[]> => {
    await delay(2000);
    return mockDevices;
  },
};

export const mockGatewayInfo = {
  id: '1',
  name: 'Gateway Service - Downtown Casino',
  version: '1.0.0',
  location: mockLocation,
  client: mockClient,
  status: 'running' as const,
  lastSeen: new Date().toISOString(),
  uptime: 3600,
  configuration: {
    inputDevices: mockDevices.filter(d => d.type !== 'api'),
    outputDevices: mockDevices.filter(d => d.type === 'api'),
    analyticsApi: {
      endpoint: 'https://analytics.gulfcoast.com/api/v1/transactions',
      apiKey: 'gc_analytics_key_12345',
      enabled: true,
    },
  },
};

export const mockConfigAPI = {
  getConfiguration: async (): Promise<Configuration[]> => {
    await delay(800);
    return mockConfigurations;
  },

  getConfigurationById: async (id: string): Promise<Configuration> => {
    await delay(500);
    const config = mockConfigurations.find(c => c.id === id);
    if (!config) throw new Error('Configuration not found');
    return config;
  },

  createConfiguration: async (config: Partial<Configuration>): Promise<Configuration> => {
    await delay(1000);
    return {
      id: Date.now().toString(),
      name: config.name || 'New Configuration',
      type: config.type || 'input',
      socketType: config.socketType || 'tcp',
      connectionType: config.connectionType || 'listen',
      host: config.host || '0.0.0.0',
      port: config.port || 8080,
      device: config.device || {},
    };
  },

  updateConfiguration: async (id: string, config: Partial<Configuration>): Promise<Configuration> => {
    await delay(800);
    return {
      id,
      name: config.name || 'Updated Configuration',
      type: config.type || 'input',
      socketType: config.socketType || 'tcp',
      connectionType: config.connectionType || 'listen',
      host: config.host || '0.0.0.0',
      port: config.port || 8080,
      device: config.device || {},
    };
  },

  deleteConfiguration: async (id: string): Promise<void> => {
    await delay(600);
  },

  testConfiguration: async (config: Partial<Configuration>): Promise<{ success: boolean; message: string }> => {
    await delay(1500);
    return { success: true, message: 'Configuration test successful' };
  },

  exportConfiguration: async (): Promise<Blob> => {
    await delay(1000);
    const configData = JSON.stringify(mockConfigurations, null, 2);
    return new Blob([configData], { type: 'application/json' });
  },

  importConfiguration: async (file: File): Promise<{ success: boolean; message: string }> => {
    await delay(1500);
    return { success: true, message: 'Configuration imported successfully' };
  },
}; 