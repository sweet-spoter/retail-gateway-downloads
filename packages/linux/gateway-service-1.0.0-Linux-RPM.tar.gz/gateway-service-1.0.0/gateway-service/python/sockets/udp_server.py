import asyncio
import time 
from collections import defaultdict, deque
from config.config import logger

class UDPServerProtocol(asyncio.DatagramProtocol):
    connections = {}
    
    def __init__(self, register, direction, device_manager):
        self.transport = None
        self.register = register
        self.direction = direction
        self.device_manager = device_manager
        self.buffers = defaultdict(deque)  # Buffers for each client
        self.last_seen = {}  # Timestamp of last seen packets for each client
        self.clients = {}  # Dictionary to store clients and their addresses

    def connection_made(self, transport):
        self.transport = transport
        UDPServerProtocol.connections[self.direction+self.register] = self
        self.device_manager.set_protocol( self.direction+self.register ,self.direction, self.register)
        self.device_manager.on_connection_made(self.direction+self.register)
        print(f'UDP server is up and listening.')
        logger.info(f'UDP server is up and listening.')
        
    # def datagram_received(self, data, addr):
    #     message = data.decode()
    #     print('Received %r from %s' % (message, addr))
    #     result = {'register': self.register, 'data': message}
    #     self.device_manager.handle_data(self.direction + self.register, message)  
    
    def datagram_received(self, data, addr):
        """Called when a datagram (packet) is received."""
        decoded_data = data.decode()

        print(f"Data received from {addr}: {decoded_data}")
        
        # Handle the received data
        self.handle_message(decoded_data, addr)

    def handle_message(self, message, addr):
        print(f"Received complete message from {addr}: {message}")
        # Store or update the client's address
        self.clients[addr] = True  # You could store more info if needed
        print(f"Current clients: {list(self.clients.keys())}")
        ip_address, port = addr  # Unpack the IP address and port
        self.device_manager.handle_data(self.direction+self.register, message, addr)

    def send_message(self, message, addr):
        if self.transport:
            self.transport.sendto(message.encode(), addr)
            print(f"Sent to {addr}: {message}")
        else:
            print("No transport available to send message.")